import { r as reactExports, j as jsxRuntimeExports, az as MessageCircle, aC as Crown, ba as Bitcoin, b3 as Send } from "./vendor-react-core-dw-u3J8o.js";
import { u as useAuth, C as Card, z as CardHeader, F as CardTitle, E as CardContent, o as Badge, S as ScrollArea, I as Input, B as Button } from "./app-utils-Cjj9E4GC.js";
import { F as FreeUserNavigation } from "./components-ui-BmnsZTWe.js";
import "./vendor-react-dom-4lR9Lo0M.js";
import "./vendor-misc-1EIi_gUb.js";
import "./vendor-database-CiOqrkV0.js";
import "./vendor-utils-CDGg_kJ1.js";
import "./app-services-LZknheK6.js";
import "./vendor-security-LdHy7Pt9.js";
import "./vendor-router-CWDrJeTE.js";
import "./vendor-network-BSBq6A-N.js";
const BasicChatPage = () => {
  const { user } = useAuth();
  const [message, setMessage] = reactExports.useState("");
  const [messages, setMessages] = reactExports.useState([
    {
      id: "1",
      text: "Velkommen til Snakkaz Chat! 🚀",
      user: "Velkommen",
      timestamp: /* @__PURE__ */ new Date(),
      type: "welcome"
    },
    {
      id: "2",
      text: "Del dine tanker, møt nye venner og bygg ekte forbindelser her! 💬",
      user: "Fellesskap",
      timestamp: /* @__PURE__ */ new Date(),
      type: "community"
    }
  ]);
  const sendMessage = () => {
    var _a;
    if (message.trim() && user) {
      const newMessage = {
        id: Date.now().toString(),
        text: message,
        user: ((_a = user.email) == null ? void 0 : _a.split("@")[0]) || "Anonym",
        timestamp: /* @__PURE__ */ new Date(),
        type: "user"
      };
      setMessages((prev) => [...prev, newMessage]);
      setMessage("");
      if (message.toLowerCase().includes("hei") || message.toLowerCase().includes("hallo")) {
        setTimeout(() => {
          const encouragementMessage = {
            id: (Date.now() + 1).toString(),
            text: "👋 Flott at du vil chatte! Inviter venner til å bli med - desto flere, desto morsommere blir det!",
            user: "Fellesskap",
            timestamp: /* @__PURE__ */ new Date(),
            type: "community"
          };
          setMessages((prev) => [...prev, encouragementMessage]);
        }, 1e3);
      }
    }
  };
  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  if (!user) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-gradient-to-br from-cyberdark-900 to-cyberdark-800 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "w-full max-w-md bg-cyberdark-800/50 border-cyberprimary-500/20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-12 w-12 text-cyberprimary-400" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl text-cyberprimary-100", children: "Snakkaz Chat" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300", children: "Logg inn for å begynne å chatte" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-cyberdark-700/30 rounded-lg", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-cyberprimary-200 mb-2", children: "Chat Features:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-sm text-cyberdark-300 space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Chat med andre brukere" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• BTC/NOK diskusjoner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Basis trading-tips" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-gradient-to-r from-cyberprimary-900/20 to-cybersecondary-900/20 rounded-lg border border-cyberprimary-500/20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-4 w-4 text-cyberprimary-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-cyberprimary-200", children: "Avanserte Features:" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-sm text-cyberdark-300 space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Krypterte private meldinger" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Avanserte BTC analyser" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Direktehandel funksjoner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Utvidede trading signaler" })
          ] })
        ] })
      ] }) })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-gradient-to-br from-cyberdark-900 to-cyberdark-800 flex", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(FreeUserNavigation, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 flex flex-col", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-4xl p-4 h-screen flex flex-col", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-3xl font-bold text-cyberprimary-100 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-8 w-8 text-cyberprimary-400" }),
            "Snakkaz Chat"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300", children: "BTC/NOK Trading & Chat Community" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "outline", className: "border-cyberprimary-500/30 text-cyberprimary-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bitcoin, { className: "h-3 w-3 mr-1" }),
          "Chat Medlem"
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-800/50 border-cyberprimary-500/20 h-[600px] flex flex-col", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "pb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cyberprimary-200", children: "Chat Room" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", className: "bg-cyberdark-700 text-cyberdark-300", children: [
            messages.filter((m) => m.type === "user").length,
            " meldinger"
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "flex-1 flex flex-col p-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "flex-1 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: messages.map((msg) => {
            var _a, _b;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `flex flex-col gap-1 ${msg.type === "user" && msg.user === (((_a = user.email) == null ? void 0 : _a.split("@")[0]) || "Anonym") ? "items-end" : "items-start"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-cyberdark-400", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-medium ${msg.type === "welcome" ? "text-cybergold-400" : msg.type === "community" ? "text-green-400" : "text-cyberdark-300"}`, children: msg.user }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: msg.timestamp.toLocaleTimeString() })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `max-w-xs px-4 py-2 rounded-lg ${msg.type === "user" && msg.user === (((_b = user.email) == null ? void 0 : _b.split("@")[0]) || "Anonym") ? "bg-cyberprimary-600 text-white ml-auto" : msg.type === "welcome" ? "bg-cybergold-900/20 text-cybergold-200 border border-cybergold-500/20" : msg.type === "community" ? "bg-green-900/20 text-green-200 border border-green-500/20" : "bg-cyberdark-700 text-cyberdark-200"}`,
                      children: msg.text
                    }
                  )
                ]
              },
              msg.id
            );
          }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-t border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  value: message,
                  onChange: (e) => setMessage(e.target.value),
                  onKeyPress: handleKeyPress,
                  placeholder: "Skriv en melding...",
                  className: "flex-1 bg-cyberdark-700 border-cyberdark-600 text-cyberdark-100 placeholder:text-cyberdark-400"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  onClick: sendMessage,
                  disabled: !message.trim(),
                  className: "bg-cyberprimary-600 hover:bg-cyberprimary-700 text-white",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-4 w-4" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cyberdark-400 mt-2", children: '💡 Tip: Skriv "BTC" for trading-tips! Få utvidet tilgang for avanserte funksjoner.' })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "mt-4 bg-gradient-to-r from-cyberprimary-900/20 to-cybersecondary-900/20 border-cyberprimary-500/30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-cyberprimary-200 mb-1", children: "Få Utvidet Tilgang" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cyberdark-300", children: "Få tilgang til krypterte meldinger, avanserte BTC-analyser og mer!" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "border-cyberprimary-500 text-cyberprimary-300 hover:bg-cyberprimary-500/10", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-4 w-4 mr-2" }),
          "Oppgrader"
        ] })
      ] }) }) })
    ] }) })
  ] });
};
export {
  BasicChatPage as default
};
//# sourceMappingURL=pages-chat-Cf3wvJ_-.js.map
