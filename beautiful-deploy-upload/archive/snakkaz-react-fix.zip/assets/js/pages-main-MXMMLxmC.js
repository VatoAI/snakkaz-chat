import { j as jsxRuntimeExports, aP as Users, bc as Lock, aK as Shield, bo as ArrowRight, aQ as Mail$2, bn as CircleCheckBig, b5 as Star, aC as Crown, r as reactExports, aJ as Globe, aX as LoaderCircle, aM as ArrowLeft, aH as Heart, a_ as UserPlus, aS as Search, aO as MessageSquare, ah as ChevronRight, bp as TrendingUp, aY as Clock, aI as Bot, aB as Settings$2, bq as Terminal, br as Server, b9 as Code, bs as Zap, ax as CircleAlert, bt as Play, bd as Copy, be as ExternalLink, aA as User, bu as Camera, h as Check, bf as Trash2, bv as BellRing, bk as Eye, aT as Info$2, bw as Sun, aW as Moon, bx as Monitor, aD as LogOut, b0 as Bell, by as Volume2, bz as Key, bh as Smartphone, aN as Plus, b2 as Inbox, b3 as Send, b4 as Archive, bA as SquarePen, bB as Reply, bC as Forward, aR as Brain, b6 as Database, b7 as ChartColumn } from "./vendor-react-core-dw-u3J8o.js";
import { B as Button, Z as useGroups, k as useToast, L as Label, I as Input, _ as Textarea, $ as RadioGroup, a0 as RadioGroupItem, a1 as Select, a2 as SelectTrigger, a3 as SelectValue, a4 as SelectContent, a5 as SelectItem, u as useAuth, a as useIsMobile, C as Card, z as CardHeader, F as CardTitle, E as CardContent, a6 as useFriends, G as CardDescription, o as Badge, S as ScrollArea, l as Tabs, m as TabsList, n as TabsTrigger, p as TabsContent, A as Avatar, i as AvatarImage, j as AvatarFallback, K as Separator, a7 as Switch } from "./app-utils-Cjj9E4GC.js";
import { u as useNavigate, O as Outlet, b as useSearchParams, L as Link } from "./vendor-router-CWDrJeTE.js";
import { a as MobileLayout, A as AppHeader, U as UnifiedNavigation, E as EnhancedFriendsList, b as FriendsSearchSection, c as EnhancedFriendRequestHandler, S as SubscriptionPage, C as CommunityEmailManager } from "./components-ui-BmnsZTWe.js";
import { m as memoryService } from "./app-services-LZknheK6.js";
const detectSubdomain = () => {
  const hostname = window.location.hostname;
  const parts = hostname.split(".");
  if (parts.length > 2) {
    const subdomain = parts[0];
    const allowedSubdomains = ["dash", "business", "docs", "analytics", "mcp", "help"];
    if (allowedSubdomains.includes(subdomain)) {
      return subdomain;
    }
  }
  return null;
};
const createSubdomainAwareUrl = (path, preserveSubdomain = true) => {
  const subdomain = detectSubdomain();
  const protocol = window.location.protocol;
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  if (preserveSubdomain && subdomain) {
    return `${protocol}//${subdomain}.snakkaz.com${cleanPath}`;
  } else {
    return `${protocol}//snakkaz.com${cleanPath}`;
  }
};
const navigateWithSubdomain = (path, options = {}) => {
  const {
    preserveSubdomain = true,
    replace = false,
    external = false
  } = options;
  const url = createSubdomainAwareUrl(path, preserveSubdomain);
  if (external || url.includes("://")) {
    if (replace) {
      window.location.replace(url);
    } else {
      window.location.href = url;
    }
  } else {
    if (replace) {
      window.location.replace(url);
    } else {
      window.location.href = url;
    }
  }
};
const useSubdomainNavigation = () => {
  const navigate = (path, options) => {
    navigateWithSubdomain(path, { ...options, external: true });
  };
  const getCurrentSubdomain = () => detectSubdomain();
  const isSubdomainActive = () => !!detectSubdomain();
  return {
    navigate,
    getCurrentSubdomain,
    isSubdomainActive,
    createUrl: createSubdomainAwareUrl
  };
};
const Info = () => {
  useNavigate();
  const subdomainNav = useSubdomainNavigation();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-gradient-to-br from-cyberdark-950 via-cyberdark-900 to-cyberdark-800", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto px-6 py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent", children: "Snakkaz Chat" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xl text-cyberdark-200 max-w-2xl mx-auto leading-relaxed", children: "Koble deg til ekte mennesker. Bygg meningsfulle vennskap. Chat sikkert med venner, familie og nye bekjentskaper med banknivå sikkerhet." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg text-cyberdark-300 mt-4 max-w-xl mx-auto", children: "💫 Inviter venner • 🤝 Bygg nettverk • 🔒 100% privat" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-4 mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center p-4 rounded-xl bg-cyberdark-900/50 border border-green-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "text-green-400 mb-2", size: 32 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-green-300", children: "Venn-system" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-cyberdark-300", children: "Inviter & koble" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center p-4 rounded-xl bg-cyberdark-900/50 border border-cyberblue-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "text-cyberblue-400 mb-2", size: 32 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-cyberblue-300", children: "✅ Privat" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-cyberdark-300", children: "E2E Kryptering" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center p-4 rounded-xl bg-cyberdark-900/50 border border-purple-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "text-purple-400 mb-2", size: 32 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-purple-300", children: "🏆 Sikkert" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-cyberdark-300", children: "Null datamining" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row gap-4 justify-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            onClick: () => subdomainNav.navigate("/register"),
            className: "h-12 px-8 text-lg bg-gradient-to-r from-cybergold-500 to-cybergold-400 hover:from-cybergold-400 hover:to-cybergold-300 text-black font-semibold shadow-lg shadow-cybergold-500/25",
            children: [
              "Start sikker chat",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "ml-2", size: 20 })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            onClick: () => subdomainNav.navigate("/login"),
            variant: "outline",
            className: "h-12 px-8 text-lg border-cyberblue-500/70 text-cyberblue-400 hover:bg-cyberblue-900/30",
            children: "Logg inn"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto px-4 py-12", id: "premium-email", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-cybergold-400 via-orange-400 to-cybergold-300 bg-clip-text text-transparent", children: "Premium E-post med @snakkaz.com" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-200 text-lg max-w-3xl mx-auto", children: "Oppgrader til Premium og få din egen profesjonelle @snakkaz.com e-postadresse som fungerer med alle e-postklienter" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-2xl font-semibold text-cybergold-300 mb-6", children: "Hva får du med Premium E-post?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4 p-4 rounded-lg bg-cyberdark-900/50 border border-cybergold-500/20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "text-cybergold-400 mt-1 flex-shrink-0", size: 24 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-cybergold-200 mb-2", children: "Din egen @snakkaz.com adresse" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300 text-sm", children: "Få en profesjonell e-postadresse som delnavn@snakkaz.com - perfekt for jobb og personlig bruk" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4 p-4 rounded-lg bg-cyberdark-900/50 border border-green-500/20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "text-green-400 mt-1 flex-shrink-0", size: 24 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-green-200 mb-2", children: "Fungerer med alle e-postklienter" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300 text-sm", children: "Bruk Gmail, Outlook, Apple Mail eller hvilken som helst annen e-postklient via IMAP/SMTP" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4 p-4 rounded-lg bg-cyberdark-900/50 border border-cyberblue-500/20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "text-cyberblue-400 mt-1 flex-shrink-0", size: 24 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-cyberblue-200 mb-2", children: "Sikker webmail-tilgang" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300 text-sm", children: "Tilgang til e-post via webmail på mail.snakkaz.com med SSL-kryptering" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4 p-4 rounded-lg bg-cyberdark-900/50 border border-purple-500/20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "text-purple-400 mt-1 flex-shrink-0", size: 24 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-purple-200 mb-2", children: "Profesjonell og pålitelig" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300 text-sm", children: "99.9% oppetid, spam-beskyttelse og daglige sikkerhetskopier" })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-2xl font-semibold text-cybergold-300 mb-6", children: "Sikker konfigurering" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-lg bg-cyberdark-800/50 border border-amber-500/30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 mb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "text-amber-400 mt-1", size: 20 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-amber-200 mb-2", children: "Beskyttet informasjon" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300 text-sm", children: "E-postkonfigurasjonsdetaljer er nå beskyttet og vises kun til verifiserte Premium-brukere." })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-amber-900/20 p-3 rounded border border-amber-500/30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-amber-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Sikkerhet:" }),
                " For å beskytte mot misbruk vises server-detaljer kun etter innlogging og identitetsverifisering."
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  onClick: () => subdomainNav.navigate("/login"),
                  className: "w-full bg-cyberblue-600 hover:bg-cyberblue-500 text-white font-medium",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "mr-2", size: 16 }),
                    "Logg inn for konfigurasjonsdetaljer"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                onClick: () => subdomainNav.navigate("/premium"),
                className: "h-12 px-8 bg-gradient-to-r from-cybergold-600 to-orange-500 hover:from-cybergold-500 hover:to-orange-400 text-black font-semibold",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "mr-2", size: 20 }),
                  "Oppgrader til Premium"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cyberdark-400 mt-2", children: "Kun 99 kr/måned • Kan kanselleres når som helst" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border border-cyberdark-700 rounded-lg overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-cyberdark-800/50 p-4 border-b border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-semibold text-cyberdark-100", children: "E-post funksjoner sammenligning" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-cyberdark-300 mb-3", children: "Snakkaz Chat" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-sm text-cyberdark-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Sikker chat i appen" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Grunnleggende funksjoner" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Standard lagring" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center border border-cybergold-500/30 rounded-lg p-4 bg-cybergold-900/10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-semibold text-cybergold-300 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "inline mr-1", size: 16 }),
              "Premium Snakkaz"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-sm text-cybergold-200", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "✅ @snakkaz.com e-post" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "✅ Webmail tilgang" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "✅ IMAP/SMTP støtte" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "✅ Ubegrenset lagring" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "✅ Spam beskyttelse" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-cyberdark-300 mb-3", children: "Vanlige e-post tjenester" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-sm text-cyberdark-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Kostbar domene" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Komplisert oppsett" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Mangler integrering" })
            ] })
          ] })
        ] }) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 py-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-2xl md:text-3xl font-bold mb-4 text-cyberdark-100", children: "Ny her? Les hvorfor SnakkaZ er ditt beste valg" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300 text-lg max-w-3xl mx-auto", children: "Oppdag hvorfor tusenvis av brukere stoler på SnakkaZ for sin daglige kommunikasjon" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-xl bg-cyberdark-900/50 border border-green-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xl font-bold text-green-400 mb-4", children: "🛡️ Militær-grad Sikkerhet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-200", children: "End-to-end kryptering, zero-knowledge arkitektur og åpen kildekode sikkerhet." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-xl bg-cyberdark-900/50 border border-cyberblue-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xl font-bold text-cyberblue-400 mb-4", children: "⚡ Lynrask Ytelse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-200", children: "Optimalisert for hastighet med moderne teknologi og effektiv datahåndtering." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-xl bg-cyberdark-900/50 border border-purple-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xl font-bold text-purple-400 mb-4", children: "🎨 Tilpassbar Opplevelse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-200", children: "Egendefinerte emojis, temaer og grensesnitt som tilpasser seg dine behov." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-xl bg-cyberdark-900/50 border border-orange-500/20 backdrop-blur-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xl font-bold text-orange-400 mb-4", children: "🌐 Global Tilgjengelighet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-200", children: "Tilgjengelig på alle enheter med støtte for flere språk og tidssoner." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-cyberdark-700/50 mt-12", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto px-4 py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-400 text-sm", children: "© 2025 Snakkaz Chat. Alle rettigheter reservert." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-500 text-xs mt-2", children: "End-to-end kryptering • Zero-knowledge arkitektur • Open source sikkerhet" })
    ] }) }) })
  ] });
};
const Info$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Info,
  default: Info
}, Symbol.toStringTag, { value: "Module" }));
const CreateGroup = ({ onSuccess, onCancel }) => {
  const [name, setName] = reactExports.useState("");
  const [description, setDescription] = reactExports.useState("");
  const [visibility, setVisibility] = reactExports.useState("private");
  const [securityLevel, setSecurityLevel] = reactExports.useState("standard");
  const [isSubmitting, setIsSubmitting] = reactExports.useState(false);
  const { handleCreateGroup } = useGroups();
  const { toast } = useToast();
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    setIsSubmitting(true);
    try {
      const newGroup = await handleCreateGroup(
        name.trim(),
        description.trim(),
        visibility,
        securityLevel
      );
      if (newGroup && onSuccess) {
        onSuccess(newGroup.id);
      }
    } catch (error) {
      console.error("Error creating group:", error);
      toast({
        title: "Kunne ikke opprette gruppe",
        description: "Det oppstod en feil ved opprettelse av gruppen. Vennligst prøv igjen.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const getSecurityLevelDescription = (level) => {
    switch (level) {
      case "low":
        return "Enkel kryptering. Best for uformelle grupper der ytelse er viktigere enn sikkerhet.";
      case "standard":
        return "Balansert kryptering for de fleste grupper. Anbefalt for vanlig bruk.";
      case "high":
        return "Avansert ende-til-ende kryptering. Ideell for sensitive samtaler og forretningsbruk.";
      case "maximum":
        return "Maksimal sikkerhet med militærgradert kryptering. Kan påvirke ytelsen.";
      default:
        return "";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "name", children: "Gruppenavn" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Input,
        {
          id: "name",
          placeholder: "Skriv inn et gruppenavn",
          value: name,
          onChange: (e) => setName(e.target.value),
          required: true,
          maxLength: 50,
          className: "dark:bg-cyberdark-800 dark:border-cybergold-500/30"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "description", children: "Beskrivelse (valgfri)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Textarea,
        {
          id: "description",
          placeholder: "Legg til en beskrivelse av gruppen",
          value: description,
          onChange: (e) => setDescription(e.target.value),
          maxLength: 200,
          className: "dark:bg-cyberdark-800 dark:border-cybergold-500/30 h-20"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Personvern" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        RadioGroup,
        {
          value: visibility,
          onValueChange: (val) => setVisibility(val),
          className: "space-y-2",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 rounded-md border dark:border-cybergold-500/30 p-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "private", id: "private" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { htmlFor: "private", className: "flex items-center gap-2 font-normal cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-4 w-4 dark:text-cyberred-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block", children: "Privat" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs dark:text-gray-400 light:text-gray-600", children: "Kun inviterte personer kan bli med" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 rounded-md border dark:border-cybergold-500/30 p-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RadioGroupItem, { value: "public", id: "public" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { htmlFor: "public", className: "flex items-center gap-2 font-normal cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "h-4 w-4 dark:text-cyberblue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block", children: "Offentlig" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs dark:text-gray-400 light:text-gray-600", children: "Alle kan finne og delta i gruppen" })
                ] })
              ] })
            ] })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { htmlFor: "securityLevel", className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 dark:text-cybergold-400" }),
        "Sikkerhetsnivå"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Select,
        {
          value: securityLevel,
          onValueChange: (value) => setSecurityLevel(value),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-full dark:bg-cyberdark-800 dark:border-cybergold-500/30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Velg sikkerhetsnivå" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { className: "dark:bg-cyberdark-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "low", children: "Lav" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "standard", children: "Standard" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "high", children: "Høy" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "maximum", children: "Maksimal" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs dark:text-gray-400 light:text-gray-500 mt-1", children: getSecurityLevelDescription(securityLevel) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 pt-3", children: [
      onCancel && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", onClick: onCancel, children: "Avbryt" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          type: "submit",
          disabled: isSubmitting || !name.trim(),
          className: "dark:bg-gradient-to-r dark:from-cyberblue-600 dark:to-cyberblue-800",
          children: isSubmitting ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
            "Oppretter..."
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "mr-2 h-4 w-4" }),
            "Opprett gruppe"
          ] })
        }
      )
    ] })
  ] });
};
const CreateGroupPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isCreated, setIsCreated] = reactExports.useState(false);
  if (!user) {
    navigate("/login", { state: { returnUrl: "/create-group" } });
    return null;
  }
  const handleGroupCreated = (groupId) => {
    setIsCreated(true);
    setTimeout(() => {
      navigate(`/group-chat/${groupId}`);
    }, 1500);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container max-w-5xl mx-auto py-8 px-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "ghost",
          size: "sm",
          onClick: () => navigate(-1),
          className: "mr-2",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4 mr-1" }),
            " Tilbake"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold dark:text-cybergold-300", children: "Opprett ny gruppe" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "dark:text-cybergold-400 mb-4", children: "Opprett en gruppe for å starte samtaler med venner, familie eller kolleger. Du kan invitere medlemmer etter at gruppen er opprettet." }),
      isCreated ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 bg-green-100 dark:bg-cybergreen-900/30 border border-green-200 dark:border-cybergreen-800/50 rounded-md mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-green-800 dark:text-cybergreen-400", children: "Gruppen er opprettet! Du blir omdirigert til gruppen..." }) }) : null
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CreateGroup, { onSuccess: handleGroupCreated })
  ] });
};
const CreateGroupPage$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  CreateGroupPage,
  default: CreateGroupPage
}, Symbol.toStringTag, { value: "Module" }));
const Layout = () => {
  const { user } = useAuth();
  useNavigate();
  const isMobile = useIsMobile();
  if (isMobile && user) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(MobileLayout, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-cyberdark-950 flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AppHeader,
      {
        variant: "default",
        context: "direct-message",
        title: "SnakkaZ",
        showNavigation: false,
        showLogo: true,
        showUserNav: !!user,
        showThemeToggle: true,
        showDownloadButton: true,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden lg:block", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          UnifiedNavigation,
          {
            variant: "horizontal",
            activeIndicator: true,
            compact: false
          }
        ) })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-cyberdark-800 bg-cyberdark-900 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container text-center text-xs text-cyberdark-400", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " SnakkaZ — Sikker kommunikasjon"
    ] }) })
  ] });
};
const Friends = () => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const content = /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 py-6 max-w-6xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 bg-cybergold-500/20 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-8 w-8 text-cybergold-400" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-bold text-cybergold-100", children: "Mine Venner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300", children: "Administrer dine vennskap og forbindelser" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "outline",
            className: "border-cybergold-500/30 text-cybergold-400 hover:bg-cybergold-500/10",
            onClick: () => navigate("/find-friends"),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 mr-2" }),
              "Finn Venner"
            ]
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px bg-gradient-to-r from-transparent via-cybergold-500/30 to-transparent" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2 text-cybergold-200", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-5 w-5" }),
          "Venneliste"
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: (user == null ? void 0 : user.id) ? /* @__PURE__ */ jsxRuntimeExports.jsx(EnhancedFriendsList, { currentUserId: user.id }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-400", children: "Du må være logget inn for å se venner" }) }) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-200", children: "Hurtighandlinger" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                className: "w-full bg-cybergold-500 hover:bg-cybergold-600 text-black",
                onClick: () => navigate("/find-friends"),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 mr-2" }),
                  "Finn Nye Venner"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                variant: "outline",
                className: "w-full border-cybergold-500/30 text-cybergold-400 hover:bg-cybergold-500/10",
                onClick: () => navigate("/chat"),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-4 w-4 mr-2" }),
                  "Start Chat"
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-200", children: "Tips for Å Koble Seg Til" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3 text-sm text-cyberdark-300", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Bruk søkefunksjonen for å finne venner ved brukernavn" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Send venneforespørsler til folk du kjenner" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: 'Administrer forespørsler i "Pending" fanen' })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Start private samtaler direkte fra vennelisten" })
            ] })
          ] })
        ] })
      ] })
    ] })
  ] }) });
  if (isMobile) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(MobileLayout, { children: content });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Layout, { children: content });
};
const Friends$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Friends
}, Symbol.toStringTag, { value: "Module" }));
const FindFriends = () => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const { friends, handleSendFriendRequest } = useFriends();
  const existingFriendIds = friends.map((friend) => friend.user_id);
  const content = /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 py-6 max-w-6xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 bg-cybergold-500/20 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-8 w-8 text-cybergold-400" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-bold text-cybergold-100", children: "Finn Venner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-300", children: "Søk etter nye venner og administrer forespørsler" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "outline",
            className: "border-cybergold-500/30 text-cybergold-400 hover:bg-cybergold-500/10",
            onClick: () => navigate("/friends"),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-4 w-4 mr-2" }),
              "Mine Venner"
            ]
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px bg-gradient-to-r from-transparent via-cybergold-500/30 to-transparent" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2 text-cybergold-200", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-5 w-5" }),
            "Søk Etter Venner"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: (user == null ? void 0 : user.id) ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            FriendsSearchSection,
            {
              currentUserId: user.id,
              onSendFriendRequest: handleSendFriendRequest,
              existingFriends: existingFriendIds
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-400", children: "Du må være logget inn for å søke etter venner" }) }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2 text-cybergold-200", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-5 w-5" }),
            "Venneforespørsler"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: (user == null ? void 0 : user.id) ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            EnhancedFriendRequestHandler,
            {
              currentUserId: user.id,
              onRequestAccepted: (userId) => {
                console.log("Friend request accepted:", userId);
              },
              onRequestRejected: (userId) => {
                console.log("Friend request rejected:", userId);
              },
              onRequestCancelled: (userId) => {
                console.log("Friend request cancelled:", userId);
              }
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-400", children: "Du må være logget inn for å se forespørsler" }) }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-200", children: "Søketips" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3 text-sm text-cyberdark-300", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Søk etter eksakt brukernavn for beste resultater" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Brukernavnet må være minst 3 tegn langt" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-cybergold-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Du kan ikke sende forespørsler til eksisterende venner" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-200", children: "Personvern" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3 text-sm text-cyberdark-300", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Kun brukernavn vises i søkeresultater" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Du kan alltid blokkere uønskede forespørsler" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Venneforespørsler kan trekkes tilbake" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900/50 border-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-200", children: "Hurtighandlinger" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                className: "w-full bg-cybergold-500 hover:bg-cybergold-600 text-black",
                onClick: () => navigate("/friends"),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4 mr-2" }),
                  "Se Mine Venner"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                variant: "outline",
                className: "w-full border-cybergold-500/30 text-cybergold-400 hover:bg-cybergold-500/10",
                onClick: () => navigate("/chat"),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-4 w-4 mr-2" }),
                  "Start Chat"
                ]
              }
            )
          ] })
        ] })
      ] })
    ] })
  ] }) });
  if (isMobile) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(MobileLayout, { children: content });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Layout, { children: content });
};
const FindFriends$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: FindFriends
}, Symbol.toStringTag, { value: "Module" }));
const Dashboard = () => {
  var _a, _b, _c, _d;
  const { user } = useAuth();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [timeOfDay, setTimeOfDay] = reactExports.useState("");
  reactExports.useEffect(() => {
    const hour = (/* @__PURE__ */ new Date()).getHours();
    if (hour < 12) setTimeOfDay("God morgen");
    else if (hour < 18) setTimeOfDay("God dag");
    else setTimeOfDay("God kveld");
  }, []);
  const quickActions = [
    {
      title: "Start Chat",
      description: "Begynn en ny samtale",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-6 w-6" }),
      action: () => navigate("/basic-chat"),
      color: "bg-blue-500/10 text-blue-400 border-blue-500/20"
    },
    {
      title: "Finn Venner",
      description: "Utvid nettverket ditt",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-6 w-6" }),
      action: () => navigate("/find-friends"),
      color: "bg-green-500/10 text-green-400 border-green-500/20"
    },
    {
      title: "AI Assistent",
      description: "Chat med AI",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { className: "h-6 w-6" }),
      action: () => navigate("/ai-chat"),
      color: "bg-purple-500/10 text-purple-400 border-purple-500/20"
    },
    {
      title: "Grupper",
      description: "Bli med i grupper",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "h-6 w-6" }),
      action: () => navigate("/group-chat"),
      color: "bg-orange-500/10 text-orange-400 border-orange-500/20"
    }
  ];
  const recentActivity = [
    { type: "message", title: "Ny melding i Teknologi-gruppen", time: "5 min siden" },
    { type: "friend", title: "Du har en ny venneforespørsel", time: "10 min siden" },
    { type: "ai", title: "AI-assistent svarte på spørsmålet ditt", time: "1 time siden" }
  ];
  const chatHubItems = [
    {
      title: "Private Samtaler",
      description: "En-til-en chat",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-5 w-5" }),
      path: "/basic-chat",
      count: 3
    },
    {
      title: "Venner",
      description: "Dine forbindelser",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-5 w-5" }),
      path: "/friends",
      count: 12
    },
    {
      title: "Grupper",
      description: "Felleskap og team",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-5 w-5" }),
      path: "/group-chat",
      count: 5
    },
    {
      title: "AI Chat",
      description: "Intelligent assistent",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { className: "h-5 w-5" }),
      path: "/ai-chat",
      badge: "BETA"
    }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 p-4 md:p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-gradient-to-r from-cybergold-600/20 to-cybergold-400/20 border border-cybergold-500/30 rounded-xl p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-2xl md:text-3xl font-bold text-cybergold-400", children: [
          timeOfDay,
          ", ",
          ((_a = user == null ? void 0 : user.user_metadata) == null ? void 0 : _a.username) || "Bruker",
          "!"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 mt-1", children: "Velkommen til Snakkaz Chat - din sikre kommunikasjonsplattform" })
      ] }),
      !isMobile && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-cybergold-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-5 w-5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: "Premium" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            onClick: () => navigate("/subscription"),
            size: "sm",
            className: "mt-2 bg-cybergold-600 text-black hover:bg-cybergold-500",
            children: "Oppgrader"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-cybergold-400 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-5 w-5" }),
              "Chat Hub"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-cybergold-600", children: "Alt chat-relatert samlet på ett sted" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: chatHubItems.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            Card,
            {
              className: "bg-cyberdark-800/50 border-cyberdark-600 hover:bg-cyberdark-800 transition-colors cursor-pointer",
              onClick: () => navigate(item.path),
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-cybergold-500/20 rounded-lg text-cybergold-400", children: item.icon }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-cybergold-300", children: item.title }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: item.description })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  item.count && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", className: "bg-cybergold-500/20 text-cybergold-400", children: item.count }),
                  item.badge && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-blue-500/20 text-blue-400", children: item.badge }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4 text-cybergold-500" })
                ] })
              ] }) })
            },
            index
          )) }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-cybergold-400 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-5 w-5" }),
            "Hurtighandlinger"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: quickActions.map((action, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "outline",
              className: `h-auto p-4 flex flex-col items-center gap-2 ${action.color}`,
              onClick: action.action,
              children: [
                action.icon,
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium text-sm", children: action.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-70", children: action.description })
                ] })
              ]
            },
            index
          )) }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-cybergold-400 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-5 w-5" }),
            "Nylig aktivitet"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-48", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: recentActivity.map((activity, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 p-2 hover:bg-cyberdark-800/50 rounded-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-1 bg-cybergold-500/20 rounded", children: [
              activity.type === "message" && /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-3 w-3 text-cybergold-400" }),
              activity.type === "friend" && /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-3 w-3 text-cybergold-400" }),
              activity.type === "ai" && /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { className: "h-3 w-3 text-cybergold-400" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-300 truncate", children: activity.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-600", children: activity.time })
            ] })
          ] }, index)) }) }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Din profil" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 bg-cybergold-500/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-400 font-medium", children: ((_c = (_b = user == null ? void 0 : user.user_metadata) == null ? void 0 : _b.username) == null ? void 0 : _c.charAt(0).toUpperCase()) || "U" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-cybergold-300", children: ((_d = user == null ? void 0 : user.user_metadata) == null ? void 0 : _d.username) || "Brukernavn" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600 truncate", children: user == null ? void 0 : user.email })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  onClick: () => navigate("/profile"),
                  size: "sm",
                  variant: "outline",
                  className: "flex-1 border-cybergold-600 text-cybergold-400",
                  children: "Rediger profil"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  onClick: () => navigate("/settings"),
                  size: "sm",
                  variant: "outline",
                  className: "border-cyberdark-600 text-cyberdark-400",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Settings$2, { className: "h-4 w-4" })
                }
              )
            ] })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-cybergold-400 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "h-5 w-5" }),
            "Dine tall"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600 text-sm", children: "Meldinger sendt" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-400 font-medium", children: "248" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600 text-sm", children: "Venner" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-400 font-medium", children: "12" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600 text-sm", children: "Grupper" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-400 font-medium", children: "5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600 text-sm", children: "Trust Score" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-green-500/20 text-green-400", children: "Verifisert ✅" })
            ] })
          ] }) })
        ] })
      ] })
    ] })
  ] }) });
};
const Dashboard$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Dashboard,
  default: Dashboard
}, Symbol.toStringTag, { value: "Module" }));
const MCPDashboard = () => {
  const { user, isPremium } = useAuth();
  const { toast } = useToast();
  const [servers, setServers] = reactExports.useState([
    {
      id: "1",
      name: "Snakkaz AI Tools",
      url: "mcp://localhost:3001",
      status: "online",
      description: "Main AI assistant tools and utilities",
      version: "1.0.0",
      tools: ["semantic_search", "code_analysis", "data_processing"],
      lastChecked: /* @__PURE__ */ new Date()
    },
    {
      id: "2",
      name: "Developer Tools",
      url: "mcp://dev.snakkaz.chat:3002",
      status: "offline",
      description: "Development and debugging utilities",
      version: "0.9.0",
      tools: ["git_operations", "file_system", "terminal_access"],
      lastChecked: new Date(Date.now() - 3e5)
      // 5 minutes ago
    }
  ]);
  const [isCreatingServer, setIsCreatingServer] = reactExports.useState(false);
  const [newServer, setNewServer] = reactExports.useState({
    name: "",
    url: "",
    description: ""
  });
  const [activeTab, setActiveTab] = reactExports.useState("overview");
  const [selectedServer, setSelectedServer] = reactExports.useState(null);
  const handleCreateServer = () => {
    if (!newServer.name || !newServer.url) {
      toast({
        title: "Feil",
        description: "Vennligst fyll ut navn og URL.",
        variant: "destructive"
      });
      return;
    }
    const server = {
      id: Date.now().toString(),
      name: newServer.name,
      url: newServer.url,
      status: "offline",
      description: newServer.description,
      version: "1.0.0",
      tools: [],
      lastChecked: /* @__PURE__ */ new Date()
    };
    setServers((prev) => [...prev, server]);
    setNewServer({ name: "", url: "", description: "" });
    setIsCreatingServer(false);
    toast({
      title: "MCP Server opprettet",
      description: `${newServer.name} er lagt til i dashboardet.`
    });
  };
  const handleTestConnection = (serverId) => {
    setServers((prev) => prev.map(
      (server) => server.id === serverId ? { ...server, status: Math.random() > 0.5 ? "online" : "error", lastChecked: /* @__PURE__ */ new Date() } : server
    ));
    toast({
      title: "Tilkobling testet",
      description: "Serverstatus oppdatert."
    });
  };
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Kopiert",
      description: "Tekst kopiert til utklippstavlen."
    });
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "online":
        return "text-green-400";
      case "offline":
        return "text-yellow-400";
      case "error":
        return "text-red-400";
      default:
        return "text-cybergold-400";
    }
  };
  const getStatusIcon = (status) => {
    switch (status) {
      case "online":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "h-4 w-4" });
      case "offline":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" });
      case "error":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" });
      default:
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Server, { className: "h-4 w-4" });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-cyberdark-950 text-cybergold-300", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "bg-cyberdark-900 border-b border-cyberdark-700 px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Terminal, { className: "h-6 w-6 text-cybergold-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-cybergold-400", children: "MCP Dashboard" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "border-cybergold-600 text-cybergold-400", children: "mcp.snakkaz.chat" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "bg-gradient-to-r from-green-600 to-green-400 text-black", children: [
          servers.filter((s) => s.status === "online").length,
          " Online"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            onClick: () => setIsCreatingServer(true),
            className: "bg-cybergold-600 hover:bg-cybergold-500 text-black",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Server, { className: "h-4 w-4 mr-2" }),
              "Ny Server"
            ]
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container max-w-7xl py-8 px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Server, { className: "h-5 w-5 text-cybergold-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Totale Servere" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: servers.length })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "h-5 w-5 text-green-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Online" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-green-400", children: servers.filter((s) => s.status === "online").length })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Code, { className: "h-5 w-5 text-cybergold-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Totale Tools" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: servers.reduce((acc, server) => acc + server.tools.length, 0) })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "h-5 w-5 text-yellow-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Aktive Sessioner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-yellow-400", children: "3" })
          ] })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, className: "w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-3 mb-6 bg-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            TabsTrigger,
            {
              value: "overview",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: "Oversikt"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            TabsTrigger,
            {
              value: "servers",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: "Servere"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            TabsTrigger,
            {
              value: "tools",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: "Tools"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "overview", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-cybergold-400 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "h-5 w-5" }),
              "Systemstatus"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-300", children: "MCP Protocol" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-green-900/20 text-green-400 border-green-600", children: "v2.0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-300", children: "API Gateway" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-green-900/20 text-green-400 border-green-600", children: "Online" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-300", children: "Load Balancer" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-green-900/20 text-green-400 border-green-600", children: "Healthy" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-300", children: "Monitoring" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-green-900/20 text-green-400 border-green-600", children: "Active" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Nylig Aktivitet" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-2 bg-cyberdark-800 rounded", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "h-4 w-4 text-green-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-300", children: "Snakkaz AI Tools tilkoblet" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-600", children: "2 minutter siden" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-2 bg-cyberdark-800 rounded", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Code, { className: "h-4 w-4 text-cybergold-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-300", children: "Tool 'semantic_search' brukt" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-600", children: "5 minutter siden" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-2 bg-cyberdark-800 rounded", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4 text-yellow-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-300", children: "Developer Tools frakoblet" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-600", children: "12 minutter siden" })
                ] })
              ] })
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "servers", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          servers.map((server) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            Card,
            {
              className: "bg-cyberdark-900 border-cyberdark-700 hover:border-cybergold-600/50 transition-colors cursor-pointer",
              onClick: () => setSelectedServer(server),
              children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "p-6", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-2 ${getStatusColor(server.status)}`, children: [
                      getStatusIcon(server.status),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-medium text-cybergold-400", children: server.name })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Badge,
                      {
                        variant: "outline",
                        className: `border-current ${getStatusColor(server.status)}`,
                        children: server.status
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      Button,
                      {
                        size: "sm",
                        variant: "outline",
                        onClick: (e) => {
                          e.stopPropagation();
                          handleTestConnection(server.id);
                        },
                        className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "h-4 w-4 mr-2" }),
                          "Test"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Button,
                      {
                        size: "sm",
                        variant: "outline",
                        onClick: (e) => {
                          e.stopPropagation();
                          copyToClipboard(server.url);
                        },
                        className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "h-4 w-4" })
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 text-sm", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 mb-1", children: "URL" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 font-mono text-xs", children: server.url })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 mb-1", children: "Versjon" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300", children: server.version })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 mb-1", children: "Tools" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-300", children: [
                      server.tools.length,
                      " tilgjengelige"
                    ] })
                  ] })
                ] }),
                server.description && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm mb-1", children: "Beskrivelse" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 text-sm", children: server.description })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 flex flex-wrap gap-2", children: server.tools.map((tool, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Badge,
                  {
                    variant: "outline",
                    className: "border-cybergold-600 text-cybergold-400 text-xs",
                    children: tool
                  },
                  index
                )) })
              ] })
            },
            server.id
          )),
          isCreatingServer && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cybergold-600", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Opprett Ny MCP Server" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "name", children: "Server Navn" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Input,
                  {
                    id: "name",
                    placeholder: "Min MCP Server",
                    value: newServer.name,
                    onChange: (e) => setNewServer((prev) => ({ ...prev, name: e.target.value })),
                    className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "url", children: "MCP URL" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Input,
                  {
                    id: "url",
                    placeholder: "mcp://localhost:3000 eller wss://your-server.com",
                    value: newServer.url,
                    onChange: (e) => setNewServer((prev) => ({ ...prev, url: e.target.value })),
                    className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "description", children: "Beskrivelse (valgfritt)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Textarea,
                  {
                    id: "description",
                    placeholder: "Beskriv hva denne serveren gjør...",
                    value: newServer.description,
                    onChange: (e) => setNewServer((prev) => ({ ...prev, description: e.target.value })),
                    className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 pt-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    onClick: handleCreateServer,
                    className: "bg-cybergold-600 hover:bg-cybergold-500 text-black",
                    children: "Opprett Server"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    variant: "outline",
                    onClick: () => setIsCreatingServer(false),
                    className: "border-cyberdark-600 text-cybergold-400 hover:bg-cyberdark-800",
                    children: "Avbryt"
                  }
                )
              ] })
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "tools", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: servers.flatMap(
          (server) => server.tools.map((tool, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-cybergold-400", children: tool }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Badge,
                {
                  variant: "outline",
                  className: `border-current ${getStatusColor(server.status)}`,
                  children: server.status
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-cybergold-600 mb-2", children: [
              "Fra: ",
              server.name
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  size: "sm",
                  variant: "outline",
                  className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-3 w-3 mr-1" }),
                    "Bruk"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  size: "sm",
                  variant: "outline",
                  className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Code, { className: "h-3 w-3 mr-1" }),
                    "Docs"
                  ]
                }
              )
            ] })
          ] }) }, `${server.id}-${index}`))
        ) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "mt-8 bg-gradient-to-r from-cybergold-900/20 to-cyberdark-800 border-cybergold-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Terminal, { className: "h-8 w-8 text-cybergold-400 mt-1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-medium text-cybergold-400 mb-2", children: "Model Context Protocol (MCP)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 mb-4", children: "MCP muliggjør sikker kommunikasjon mellom AI-modeller og eksterne tjenester. Dette dashboardet lar deg administrere og overvåke dine MCP-servere." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                variant: "outline",
                className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-4 w-4 mr-2" }),
                  "Dokumentasjon"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                variant: "outline",
                className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Code, { className: "h-4 w-4 mr-2" }),
                  "API Reference"
                ]
              }
            )
          ] })
        ] })
      ] }) }) })
    ] })
  ] });
};
const MCPDashboard$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: MCPDashboard
}, Symbol.toStringTag, { value: "Module" }));
const Subscription = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(SubscriptionPage, {});
};
const Subscription$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Subscription
}, Symbol.toStringTag, { value: "Module" }));
const AdminSecurityPanel = () => {
  const [accessGranted, setAccessGranted] = reactExports.useState(false);
  const [accessCode, setAccessCode] = reactExports.useState("");
  const handleAccess = () => {
    if (accessCode === "SNAKKAZ_ADMIN_2025") {
      setAccessGranted(true);
    } else {
      alert("Ugyldig tilgangskode");
    }
  };
  if (!accessGranted) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-900 p-8 rounded-lg border border-red-500/20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-red-400 mb-4", children: "Begrenset tilgang" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          value: accessCode,
          onChange: (e) => setAccessCode(e.target.value),
          placeholder: "Tilgangskode",
          className: "w-full p-2 mb-4 bg-cyberdark-800 border border-red-500/30 rounded text-red-300"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleAccess,
          className: "w-full bg-red-600 text-white p-2 rounded hover:bg-red-700",
          children: "Få tilgang"
        }
      )
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-red-400 mb-6", children: "🔒 Sikkerhetssystem - Skjult Panel" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-900 p-6 rounded-lg border border-red-500/20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-red-300 mb-4", children: "Sikkerhetssystemer Tilgjengelig" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-red-200", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• SecurityMonitoringSystem - Sporing av mistenkelig aktivitet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Politirapportering kun ved alvorlige forbrytelser" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Automatisk logging av sikkerhetsrelaterte hendelser" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Trust-system integrering" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-900 p-6 rounded-lg border border-amber-500/20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-amber-300 mb-4", children: "⚠️ Viktig Informasjon" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-amber-200 space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Dette systemet er skjult fra offentlige brukere" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Kun tilgjengelig via direkte URL: /admin/security" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Systemet samler IKKE persondata fra vanlige brukere" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Aktiveres kun ved mistanke om alvorlige forbrytelser" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-900 p-6 rounded-lg border border-green-500/20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-green-300 mb-4", children: "✅ STEG 3 - UX Forbedringer" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-green-200 space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Fjernet synlig referanse til politisamarbeid fra brukergrensesnitt" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Systemet fortsatt tilgjengelig for autorisert personell" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Appen fremstår nå som mer inkluderende og brukervennlig" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• Sikkerhetsfunksjonalitet bevart i bakgrunnen" })
        ] })
      ] })
    ] })
  ] }) });
};
const AdminSecurityPanel$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AdminSecurityPanel
}, Symbol.toStringTag, { value: "Module" }));
const Profile = () => {
  const { user, isPremium } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isFirstTime = searchParams.get("firstTime") === "true";
  const [profile, setProfile] = reactExports.useState({
    username: "brukernavn",
    // Default placeholder
    displayName: "",
    bio: "",
    avatarUrl: "",
    status: "online",
    publicProfile: true
  });
  const [isEditing, setIsEditing] = reactExports.useState(isFirstTime);
  const [editedProfile, setEditedProfile] = reactExports.useState({ ...profile });
  const [activeTab, setActiveTab] = reactExports.useState("profile");
  reactExports.useEffect(() => {
    if (isFirstTime) {
      toast({
        title: "Velkommen til Snakkaz Chat! 🎉",
        description: "La oss sette opp profilen din for å komme i gang."
      });
    }
  }, [isFirstTime, toast]);
  const handleEditToggle = () => {
    if (isEditing) {
      setProfile(editedProfile);
      toast({
        title: "Profil oppdatert",
        description: "Profilendringene dine har blitt lagret."
      });
      if (isFirstTime) {
        setTimeout(() => {
          toast({
            title: "Profil fullført! ✅",
            description: "Du blir nå sendt til hovedsiden."
          });
          navigate("/dashboard");
        }, 1500);
      }
    }
    setIsEditing(!isEditing);
  };
  const handleSkipProfile = () => {
    if (isFirstTime) {
      navigate("/dashboard");
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedProfile((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handleSwitchChange = (checked) => {
    setEditedProfile((prev) => ({
      ...prev,
      publicProfile: checked
    }));
  };
  const handleAvatarUpload = () => {
    toast({
      title: "Bilde-opplasting",
      description: "Funksjon for å laste opp profilbilde er under utvikling."
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-cyberdark-950 text-cybergold-300 pb-16 md:pb-0 md:pt-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(UnifiedNavigation, { variant: "horizontal" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container max-w-4xl py-8 px-4", children: [
      isFirstTime && /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "mb-6 bg-gradient-to-r from-cybergold-900/20 to-cyberdark-800 border-cybergold-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-cybergold-400 mb-2", children: "Velkommen til Snakkaz Chat! 🎉" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 mb-4", children: "La oss sette opp profilen din for å komme i gang med å chatte." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "outline",
            onClick: handleSkipProfile,
            className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
            children: [
              "Hopp over ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "ml-2 h-4 w-4" })
            ]
          }
        )
      ] }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-cybergold-400", children: isFirstTime ? "Sett opp profilen din" : "Min profil" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          isPremium && /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "bg-gradient-to-r from-cybergold-600 to-cybergold-400 text-cyberdark-900 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-3 w-3" }),
            " Premium"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "border-cybergold-600 text-cybergold-400", children: user == null ? void 0 : user.email })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, className: "w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-2 mb-6 bg-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "profile", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: "Profildetaljer" }),
          isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "email", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: "Premium E-post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "profile", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700 md:col-span-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "pb-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Profilbilde" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "flex flex-col items-center pt-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mb-6", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Avatar, { className: "w-32 h-32 border-4 border-cybergold-600", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarImage, { src: profile.avatarUrl }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarFallback, { className: "bg-cyberdark-800 text-cybergold-500 text-4xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, {}) })
                ] }),
                isEditing && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    size: "icon",
                    className: "absolute bottom-0 right-0 bg-cybergold-600 hover:bg-cybergold-500 text-black rounded-full h-10 w-10",
                    onClick: handleAvatarUpload,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-5 w-5" })
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center w-full", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-cybergold-400 mb-1", children: isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Input,
                  {
                    name: "displayName",
                    value: editedProfile.displayName,
                    onChange: handleInputChange,
                    placeholder: "Visningsnavn",
                    className: "bg-cyberdark-800 border-cyberdark-700 text-center"
                  }
                ) : profile.displayName || "Legg til visningsnavn" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-600 mb-3", children: [
                  "@",
                  isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Input,
                    {
                      name: "username",
                      value: editedProfile.username,
                      onChange: handleInputChange,
                      placeholder: "brukernavn",
                      className: "bg-cyberdark-800 border-cyberdark-700 text-center mt-2"
                    }
                  ) : profile.username
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center space-x-2 mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-2 w-2 rounded-full ${profile.status === "online" ? "bg-green-500" : profile.status === "away" ? "bg-amber-500" : "bg-red-500"}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-cybergold-500 capitalize", children: profile.status })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    variant: isEditing ? "default" : "outline",
                    className: isEditing ? "bg-cybergold-600 hover:bg-cybergold-500 text-black w-full" : "bg-cyberdark-800 border-cyberdark-700 hover:bg-cyberdark-700 w-full",
                    onClick: handleEditToggle,
                    children: isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4 mr-2" }),
                      isFirstTime ? "Fullfør oppsettet" : "Lagre endringer"
                    ] }) : "Rediger profil"
                  }
                ),
                isEditing && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  Button,
                  {
                    variant: "outline",
                    className: "bg-red-900/20 border-red-900/50 hover:bg-red-900/30 text-red-400 mt-2 w-full",
                    onClick: () => {
                      setEditedProfile({ ...profile });
                      setIsEditing(false);
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4 mr-2" }),
                      "Avbryt"
                    ]
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700 md:col-span-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Profildetaljer" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "bio", className: "text-sm text-cybergold-500", children: "Bio" }),
                isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Textarea,
                  {
                    id: "bio",
                    name: "bio",
                    placeholder: "Skriv litt om deg selv...",
                    value: editedProfile.bio,
                    onChange: handleInputChange,
                    className: "mt-2 bg-cyberdark-800 border-cyberdark-700 min-h-[120px]"
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 p-3 bg-cyberdark-800 rounded-md min-h-[80px]", children: profile.bio || /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600 italic", children: "Ingen biografi enda" }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-cybergold-400", children: "Offentlig profil" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-600", children: "Tillat andre å se profilen din" })
                ] }),
                isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Switch,
                  {
                    checked: editedProfile.publicProfile,
                    onCheckedChange: handleSwitchChange,
                    className: "data-[state=checked]:bg-cybergold-500"
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Badge,
                  {
                    variant: "outline",
                    className: profile.publicProfile ? "border-green-600 text-green-400" : "border-red-600 text-red-400",
                    children: profile.publicProfile ? "Synlig" : "Privat"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-cybergold-400 mb-4", children: "Kontoinformasjon" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 items-center text-sm", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600", children: "E-post" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "col-span-2 text-cybergold-300", children: user == null ? void 0 : user.email })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 items-center text-sm", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600", children: "Medlem siden" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "col-span-2 text-cybergold-300", children: "Mai 2025" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 items-center text-sm", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600", children: "Abonnement" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "col-span-2 text-cybergold-300", children: isPremium ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-gradient-to-r from-cybergold-600 to-cybergold-400 text-cyberdark-900", children: "Premium" }) : "Standard" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 items-center text-sm", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-600", children: "ID" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "col-span-2 text-cybergold-300 break-all", children: (user == null ? void 0 : user.id) || "Ikke tilgjengelig" })
                  ] })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700 md:col-span-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Aktivitet" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-800 p-4 rounded-lg text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-cybergold-600 text-sm mb-1", children: "Meldinger" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: "0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-800 p-4 rounded-lg text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-cybergold-600 text-sm mb-1", children: "Grupper" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: "0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-800 p-4 rounded-lg text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-cybergold-600 text-sm mb-1", children: "Kontakter" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: "0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-800 p-4 rounded-lg text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-cybergold-600 text-sm mb-1", children: "Delte filer" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: "0" })
              ] })
            ] }) })
          ] })
        ] }) }),
        isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "email", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CommunityEmailManager, {}) })
      ] })
    ] })
  ] });
};
const Profile$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Profile
}, Symbol.toStringTag, { value: "Module" }));
const Settings = () => {
  const { user, signOut, isPremium } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = reactExports.useState("general");
  const [settings, setSettings] = reactExports.useState({
    theme: "dark",
    language: "no",
    notifications: {
      enabled: true,
      sound: true,
      email: false,
      push: true
    },
    privacy: {
      profileVisibility: "all",
      lastSeen: true,
      readReceipts: true
    },
    security: {
      twoFactorAuth: false
    }
  });
  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Logget ut",
        description: "Du har blitt logget ut av Snakkaz Chat."
      });
    } catch (error) {
      console.error("Logout error:", error);
      toast({
        variant: "destructive",
        title: "Feil ved utlogging",
        description: "Kunne ikke logge ut. Vennligst prøv igjen."
      });
    }
  };
  const updateSetting = (category, setting, value) => {
    setSettings((prev) => {
      if (category === "notifications" || category === "privacy" || category === "security") {
        return {
          ...prev,
          [category]: {
            ...prev[category],
            [setting]: value
          }
        };
      }
      return prev;
    });
    toast({
      title: "Innstilling oppdatert",
      description: `${setting} innstillingen har blitt oppdatert.`
    });
  };
  const updateTheme = (theme) => {
    setSettings((prev) => ({
      ...prev,
      theme
    }));
    toast({
      title: "Tema endret",
      description: `Tema er satt til ${theme === "dark" ? "mørkt" : theme === "light" ? "lyst" : "system"}.`
    });
  };
  const updateLanguage = (language) => {
    setSettings((prev) => ({
      ...prev,
      language
    }));
    toast({
      title: "Språk endret",
      description: `Språk er satt til ${language === "no" ? "norsk" : "engelsk"}.`
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-cyberdark-950 text-cybergold-300 pb-16 md:pb-0 md:pt-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(UnifiedNavigation, { variant: "horizontal" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container max-w-4xl py-8 px-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-cybergold-400", children: "Innstillinger" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          isPremium && /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "bg-gradient-to-r from-cybergold-600 to-cybergold-400 text-cyberdark-900 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-3 w-3" }),
            " Premium"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "border-cybergold-600 text-cybergold-400", children: user == null ? void 0 : user.email })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, className: "w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-5 bg-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "general", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Settings$2, { className: "h-4 w-4 mr-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Generelt" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "notifications", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BellRing, { className: "h-4 w-4 mr-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Varsler" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "privacy", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4 mr-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Personvern" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "security", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 mr-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Sikkerhet" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "about", className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Info$2, { className: "h-4 w-4 mr-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Om" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "general", className: "p-4 space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300 mb-4", children: "Tema" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  variant: "outline",
                  className: `flex flex-col items-center justify-center h-24 ${settings.theme === "light" ? "bg-cybergold-600/20 border-cybergold-500" : "bg-cyberdark-800"}`,
                  onClick: () => updateTheme("light"),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "h-8 w-8 mb-2" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Lyst" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  variant: "outline",
                  className: `flex flex-col items-center justify-center h-24 ${settings.theme === "dark" ? "bg-cybergold-600/20 border-cybergold-500" : "bg-cyberdark-800"}`,
                  onClick: () => updateTheme("dark"),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "h-8 w-8 mb-2" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Mørkt" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  variant: "outline",
                  className: `flex flex-col items-center justify-center h-24 ${settings.theme === "system" ? "bg-cybergold-600/20 border-cybergold-500" : "bg-cyberdark-800"}`,
                  onClick: () => updateTheme("system"),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Monitor, { className: "h-8 w-8 mb-2" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "System" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300 mb-4", children: "Språk" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: settings.language, onValueChange: updateLanguage, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "bg-cyberdark-800 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Velg språk" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "no", children: "Norsk" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "en", children: "English" })
              ] })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300 mb-4", children: "Profil og E-post" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-500", children: "Administrer profilen din og e-postinnstillinger fra profilsiden din." }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                isPremium && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cybergold-600/10 border border-cybergold-600/20 rounded-md p-4 mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-5 w-5 text-cybergold-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-md font-medium text-cybergold-400", children: "Premium E-post" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-500 mb-3", children: "Som premium-bruker har du tilgang til @snakkaz.com e-postadresser. Du kan administrere dine e-postadresser fra profilsiden din." }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", className: "bg-cyberdark-800 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/profile", children: [
                    "Administrer e-postadresser",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "ml-2 h-4 w-4" })
                  ] }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", className: "bg-cyberdark-800 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/profile", children: "Gå til profilside" }) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300 mb-4", children: "Konto" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                variant: "destructive",
                className: "bg-red-900/20 hover:bg-red-900/40 border-red-900/50 text-red-400",
                onClick: handleSignOut,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4 mr-2" }),
                  "Logg ut"
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "notifications", className: "p-4 space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mb-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300", children: "Varsler" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Switch,
              {
                id: "notifications-toggle",
                checked: settings.notifications.enabled,
                onCheckedChange: (checked) => updateSetting("notifications", "enabled", checked),
                className: "data-[state=checked]:bg-cybergold-500"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 ml-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-5 w-5 text-cybergold-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Label,
                  {
                    htmlFor: "app-notifications",
                    className: settings.notifications.enabled ? "text-cybergold-300" : "text-cybergold-600",
                    children: "App-varsler"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Switch,
                {
                  id: "app-notifications",
                  checked: settings.notifications.push && settings.notifications.enabled,
                  disabled: !settings.notifications.enabled,
                  onCheckedChange: (checked) => updateSetting("notifications", "push", checked),
                  className: "data-[state=checked]:bg-cybergold-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "h-5 w-5 text-cybergold-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Label,
                  {
                    htmlFor: "sound-notifications",
                    className: settings.notifications.enabled ? "text-cybergold-300" : "text-cybergold-600",
                    children: "Lydvarsler"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Switch,
                {
                  id: "sound-notifications",
                  checked: settings.notifications.sound && settings.notifications.enabled,
                  disabled: !settings.notifications.enabled,
                  onCheckedChange: (checked) => updateSetting("notifications", "sound", checked),
                  className: "data-[state=checked]:bg-cybergold-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "h-5 w-5 text-cybergold-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Label,
                  {
                    htmlFor: "email-notifications",
                    className: settings.notifications.enabled ? "text-cybergold-300" : "text-cybergold-600",
                    children: "E-postvarsler"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Switch,
                {
                  id: "email-notifications",
                  checked: settings.notifications.email && settings.notifications.enabled,
                  disabled: !settings.notifications.enabled,
                  onCheckedChange: (checked) => updateSetting("notifications", "email", checked),
                  className: "data-[state=checked]:bg-cybergold-500"
                }
              )
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "privacy", className: "p-4 space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300 mb-4", children: "Profilsynlighet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Select,
              {
                value: settings.privacy.profileVisibility,
                onValueChange: (value) => updateSetting("privacy", "profileVisibility", value),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-full sm:w-1/2 bg-cyberdark-800 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Velg hvem som kan se profilen din" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { className: "bg-cyberdark-800 border-cyberdark-700", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "all", children: "Alle" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "contacts", children: "Bare kontakter" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "none", children: "Ingen (privat)" })
                  ] })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Label,
                  {
                    htmlFor: "last-seen",
                    className: "text-cybergold-300 block mb-1",
                    children: "Vis sist sett"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "La andre se når du sist var aktiv" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Switch,
                {
                  id: "last-seen",
                  checked: settings.privacy.lastSeen,
                  onCheckedChange: (checked) => updateSetting("privacy", "lastSeen", checked),
                  className: "data-[state=checked]:bg-cybergold-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Label,
                  {
                    htmlFor: "read-receipts",
                    className: "text-cybergold-300 block mb-1",
                    children: "Lesebekreftelser"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "La andre se når du har lest meldingene deres" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Switch,
                {
                  id: "read-receipts",
                  checked: settings.privacy.readReceipts,
                  onCheckedChange: (checked) => updateSetting("privacy", "readReceipts", checked),
                  className: "data-[state=checked]:bg-cybergold-500"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "security", className: "p-4 space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-medium text-cybergold-300 mb-4", children: "Kontosikerhet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "outline",
              className: "bg-cyberdark-800 border-cyberdark-700 mb-4",
              onClick: () => toast({
                title: "Endre passord",
                description: "Funksjonen for å endre passord direkte er under utvikling."
              }),
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-4 w-4 mr-2" }),
                "Endre passord"
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mt-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Label,
                {
                  htmlFor: "two-factor-auth",
                  className: "text-cybergold-300 block mb-1",
                  children: "To-faktor autentisering"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "Legg til et ekstra sikkerhetslag for kontoen din" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Switch,
              {
                id: "two-factor-auth",
                checked: settings.security.twoFactorAuth,
                onCheckedChange: (checked) => updateSetting("security", "twoFactorAuth", checked),
                className: "data-[state=checked]:bg-cybergold-500"
              }
            )
          ] }),
          settings.security.twoFactorAuth && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 bg-cyberdark-800 p-4 rounded-lg border border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-cybergold-400 mb-2", children: "Konfigurer to-faktor autentisering" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm mb-4", children: "For å fullføre oppsett, skann QR-koden med en autentiserings-app som Google Authenticator eller Authy." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white p-4 rounded-md w-48 h-48 mx-auto mb-4 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-black text-xs", children: "QR-kode placeholder" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "bg-cybergold-600 text-black hover:bg-cybergold-500", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Key, { className: "h-4 w-4 mr-2" }),
              "Fullfør oppsett"
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-md font-medium text-cybergold-300 mb-3", children: "Innloggingsøkter" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-800 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Smartphone, { className: "h-10 w-10 text-cybergold-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 font-medium", children: "Denne enheten" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-xs", children: "Sist aktiv: Nå" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-green-600/20 text-green-400 border-green-700", children: "Aktiv" })
            ] }) }) })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "about", className: "p-4 space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: "/logos/snakkaz-gold.svg",
                alt: "Snakkaz Logo",
                className: "h-20 w-auto mx-auto mb-3",
                onError: (e) => {
                  const target = e.target;
                  target.onerror = null;
                  target.src = "/logos/snakkaz-gold.png";
                }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold text-cybergold-400", children: "Snakkaz Chat" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Versjon 1.0.0" }),
            isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "mt-2 bg-gradient-to-r from-cybergold-600 to-cybergold-400 text-cyberdark-900", children: "Premium abonnement aktivt" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl mx-auto", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 text-center", children: "Snakkaz Chat er en sikker, ende-til-ende-kryptert meldingstjeneste som prioriterer brukerens personvern og datasikkerhet." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
            isPremium && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cybergold-600/10 border border-cybergold-600/20 rounded-md p-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-lg font-medium text-cybergold-400 flex items-center gap-2 mb-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-5 w-5" }),
                  " Premium Funksjoner"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-cybergold-500", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "h-4 w-4 text-cybergold-400 flex-shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "@snakkaz.com e-postadresser" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-4 w-4 text-cybergold-400 flex-shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Forbedret ende-til-ende-kryptering" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 text-cybergold-400 flex-shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Premium grupper med utvidede sikkerhetsfunksjoner" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", className: "bg-cyberdark-800 border-cyberdark-700", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/profile", children: "Administrer premium-funksjoner" }) }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-medium text-cybergold-300 mb-2", children: "Kontakt" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-500", children: [
                "E-post: support@snakkaz.no",
                /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
                "Nettside: snakkaz.no"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-cyberdark-700" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-medium text-cybergold-300 mb-2", children: "Juridisk" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "link", className: "text-cybergold-400 hover:text-cybergold-300 p-0 h-auto", children: "Personvernserklæring" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "link", className: "text-cybergold-400 hover:text-cybergold-300 p-0 h-auto", children: "Brukervilkår" })
              ] })
            ] })
          ] })
        ] })
      ] }) })
    ] })
  ] });
};
const Settings$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Settings
}, Symbol.toStringTag, { value: "Module" }));
const Mail = () => {
  const { user, isPremium } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = reactExports.useState("inbox");
  const [selectedMessage, setSelectedMessage] = reactExports.useState(null);
  const [isComposing, setIsComposing] = reactExports.useState(false);
  const [searchTerm, setSearchTerm] = reactExports.useState("");
  const [messages, setMessages] = reactExports.useState([
    {
      id: "1",
      from: "admin@snakkaz.chat",
      to: (user == null ? void 0 : user.email) || "",
      subject: "Velkommen til Snakkaz Chat Mail",
      content: "Velkommen til det nye mail-systemet! Her kan du sende og motta meldinger fra andre brukere.",
      timestamp: /* @__PURE__ */ new Date("2025-06-01T10:00:00"),
      read: false,
      starred: false,
      folder: "inbox"
    },
    {
      id: "2",
      from: "system@snakkaz.chat",
      to: (user == null ? void 0 : user.email) || "",
      subject: "Ditt Premium-abonnement",
      content: `Hei! ${isPremium ? "Takk for at du bruker Snakkaz Premium!" : "Oppgrader til Premium for flere funksjoner."}`,
      timestamp: /* @__PURE__ */ new Date("2025-06-01T09:30:00"),
      read: true,
      starred: true,
      folder: "inbox"
    }
  ]);
  const [newMessage, setNewMessage] = reactExports.useState({
    to: "",
    subject: "",
    content: ""
  });
  const filteredMessages = messages.filter((msg) => {
    const matchesFolder = msg.folder === activeTab;
    const matchesSearch = !searchTerm || msg.subject.toLowerCase().includes(searchTerm.toLowerCase()) || msg.from.toLowerCase().includes(searchTerm.toLowerCase()) || msg.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFolder && matchesSearch;
  });
  const handleSendMessage = () => {
    if (!newMessage.to || !newMessage.subject || !newMessage.content) {
      toast({
        title: "Feil",
        description: "Vennligst fyll ut alle feltene.",
        variant: "destructive"
      });
      return;
    }
    const message = {
      id: Date.now().toString(),
      from: (user == null ? void 0 : user.email) || "",
      to: newMessage.to,
      subject: newMessage.subject,
      content: newMessage.content,
      timestamp: /* @__PURE__ */ new Date(),
      read: true,
      starred: false,
      folder: "sent"
    };
    setMessages((prev) => [...prev, message]);
    setNewMessage({ to: "", subject: "", content: "" });
    setIsComposing(false);
    toast({
      title: "Melding sendt",
      description: `Din melding til ${newMessage.to} er sendt!`
    });
  };
  const handleMarkAsRead = (messageId) => {
    setMessages((prev) => prev.map(
      (msg) => msg.id === messageId ? { ...msg, read: true } : msg
    ));
  };
  const handleToggleStar = (messageId) => {
    setMessages((prev) => prev.map(
      (msg) => msg.id === messageId ? { ...msg, starred: !msg.starred } : msg
    ));
  };
  const handleDeleteMessage = (messageId) => {
    setMessages((prev) => prev.map(
      (msg) => msg.id === messageId ? { ...msg, folder: "trash" } : msg
    ));
    setSelectedMessage(null);
    toast({
      title: "Melding slettet",
      description: "Meldingen er flyttet til papirkurven."
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-cyberdark-950 text-cybergold-300 pb-16 md:pb-0 md:pt-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(UnifiedNavigation, { variant: "horizontal" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container max-w-7xl py-8 px-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "h-6 w-6 text-cybergold-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-cybergold-400", children: "Snakkaz Mail" }),
          isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "bg-gradient-to-r from-cybergold-600 to-cybergold-400 text-cyberdark-900", children: "Premium" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            onClick: () => setIsComposing(true),
            className: "bg-cybergold-600 hover:bg-cybergold-500 text-black",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
              "Ny melding"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "mb-6 bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-cybergold-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Input,
          {
            placeholder: "Søk i meldinger...",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            className: "pl-10 bg-cyberdark-800 border-cyberdark-700"
          }
        )
      ] }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Mapper" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Tabs, { value: activeTab, onValueChange: setActiveTab, orientation: "vertical", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-1 gap-2 bg-cyberdark-800 p-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                TabsTrigger,
                {
                  value: "inbox",
                  className: "flex items-center gap-2 data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Inbox, { className: "h-4 w-4" }),
                    "Innboks (",
                    messages.filter((m) => m.folder === "inbox").length,
                    ")"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                TabsTrigger,
                {
                  value: "sent",
                  className: "flex items-center gap-2 data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-4 w-4" }),
                    "Sendt (",
                    messages.filter((m) => m.folder === "sent").length,
                    ")"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                TabsTrigger,
                {
                  value: "archive",
                  className: "flex items-center gap-2 data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Archive, { className: "h-4 w-4" }),
                    "Arkiv (",
                    messages.filter((m) => m.folder === "archive").length,
                    ")"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                TabsTrigger,
                {
                  value: "trash",
                  className: "flex items-center gap-2 data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }),
                    "Papirkurv (",
                    messages.filter((m) => m.folder === "trash").length,
                    ")"
                  ]
                }
              )
            ] }) }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "mt-4 bg-cyberdark-900 border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Meldinger" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-96 overflow-y-auto", children: filteredMessages.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 text-center text-cybergold-600", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "h-12 w-12 mx-auto mb-2 opacity-50" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Ingen meldinger i denne mappen" })
            ] }) : filteredMessages.map((message) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `p-4 border-b border-cyberdark-700 cursor-pointer hover:bg-cyberdark-800/50 transition-colors ${(selectedMessage == null ? void 0 : selectedMessage.id) === message.id ? "bg-cyberdark-800" : ""}`,
                onClick: () => {
                  setSelectedMessage(message);
                  if (!message.read) {
                    handleMarkAsRead(message.id);
                  }
                },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarFallback, { className: "bg-cyberdark-700 text-cybergold-400 text-xs", children: message.from.charAt(0).toUpperCase() }) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-medium ${!message.read ? "text-cybergold-400" : "text-cybergold-500"}`, children: activeTab === "sent" ? `Til: ${message.to}` : message.from })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                      message.starred && /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "h-4 w-4 text-yellow-400 fill-current" }),
                      !message.read && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 w-2 bg-cybergold-400 rounded-full" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-medium mb-1 ${!message.read ? "text-cybergold-300" : "text-cybergold-500"}`, children: message.subject }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600 truncate", children: message.content }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-cybergold-700 mt-2", children: [
                    message.timestamp.toLocaleDateString("nb-NO"),
                    " ",
                    message.timestamp.toLocaleTimeString("nb-NO", { hour: "2-digit", minute: "2-digit" })
                  ] })
                ]
              },
              message.id
            )) }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-2", children: isComposing ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-cybergold-400 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "h-5 w-5" }),
            "Ny melding"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "to", children: "Til" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "to",
                  type: "email",
                  placeholder: "mottaker@snakkaz.chat",
                  value: newMessage.to,
                  onChange: (e) => setNewMessage((prev) => ({ ...prev, to: e.target.value })),
                  className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "subject", children: "Emne" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "subject",
                  placeholder: "Skriv emnet her...",
                  value: newMessage.subject,
                  onChange: (e) => setNewMessage((prev) => ({ ...prev, subject: e.target.value })),
                  className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "content", children: "Melding" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Textarea,
                {
                  id: "content",
                  placeholder: "Skriv meldingen din her...",
                  value: newMessage.content,
                  onChange: (e) => setNewMessage((prev) => ({ ...prev, content: e.target.value })),
                  className: "mt-1 bg-cyberdark-800 border-cyberdark-700 min-h-[200px]"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  onClick: handleSendMessage,
                  className: "bg-cybergold-600 hover:bg-cybergold-500 text-black",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-4 w-4 mr-2" }),
                    "Send melding"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  variant: "outline",
                  onClick: () => setIsComposing(false),
                  className: "border-cyberdark-600 text-cybergold-400 hover:bg-cyberdark-800",
                  children: "Avbryt"
                }
              )
            ] })
          ] })
        ] }) : selectedMessage ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: selectedMessage.subject }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarFallback, { className: "bg-cyberdark-700 text-cybergold-400 text-xs", children: selectedMessage.from.charAt(0).toUpperCase() }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-cybergold-400", children: [
                    "Fra: ",
                    selectedMessage.from
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-cybergold-600", children: [
                    selectedMessage.timestamp.toLocaleDateString("nb-NO"),
                    " ",
                    selectedMessage.timestamp.toLocaleTimeString("nb-NO")
                  ] })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  size: "icon",
                  variant: "outline",
                  onClick: () => handleToggleStar(selectedMessage.id),
                  className: `border-cyberdark-600 ${selectedMessage.starred ? "text-yellow-400" : "text-cybergold-600"} hover:bg-cyberdark-800`,
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: `h-4 w-4 ${selectedMessage.starred ? "fill-current" : ""}` })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  size: "icon",
                  variant: "outline",
                  onClick: () => handleDeleteMessage(selectedMessage.id),
                  className: "border-red-600 text-red-400 hover:bg-red-900/20",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" })
                }
              )
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "prose prose-invert max-w-none", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 whitespace-pre-wrap", children: selectedMessage.content }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "my-6 bg-cyberdark-700" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  onClick: () => {
                    setNewMessage({
                      to: selectedMessage.from,
                      subject: `Re: ${selectedMessage.subject}`,
                      content: `

--- Original melding ---
Fra: ${selectedMessage.from}
Emne: ${selectedMessage.subject}

${selectedMessage.content}`
                    });
                    setIsComposing(true);
                  },
                  variant: "outline",
                  className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Reply, { className: "h-4 w-4 mr-2" }),
                    "Svar"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  onClick: () => {
                    setNewMessage({
                      to: "",
                      subject: `Fwd: ${selectedMessage.subject}`,
                      content: `

--- Videresendt melding ---
Fra: ${selectedMessage.from}
Emne: ${selectedMessage.subject}

${selectedMessage.content}`
                    });
                    setIsComposing(true);
                  },
                  variant: "outline",
                  className: "border-cybergold-600 text-cybergold-400 hover:bg-cybergold-600/20",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Forward, { className: "h-4 w-4 mr-2" }),
                    "Videresend"
                  ]
                }
              )
            ] })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "p-12 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$2, { className: "h-16 w-16 mx-auto mb-4 text-cybergold-600 opacity-50" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-medium text-cybergold-400 mb-2", children: "Velg en melding" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Klikk på en melding fra listen for å lese den, eller opprett en ny melding." })
        ] }) }) })
      ] }),
      !isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "mt-6 bg-gradient-to-r from-cybergold-900/20 to-cyberdark-800 border-cybergold-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-6 w-6 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-cybergold-400", children: "Oppgrader til Premium" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 text-sm", children: "Få tilgang til avanserte mail-funksjoner som filvedlegg, e-post-viderekobling og mer lagringsplass." })
        ] })
      ] }) }) })
    ] })
  ] });
};
const Mail$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Mail
}, Symbol.toStringTag, { value: "Module" }));
const MemoryDashboard = () => {
  const { user, isPremium } = useAuth();
  const { toast } = useToast();
  const [memories, setMemories] = reactExports.useState([]);
  const [stats, setStats] = reactExports.useState(null);
  const [adminOverview, setAdminOverview] = reactExports.useState(null);
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [selectedType, setSelectedType] = reactExports.useState("all");
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [activeTab, setActiveTab] = reactExports.useState("memories");
  const [newMemory, setNewMemory] = reactExports.useState({
    type: "user_preference",
    key: "",
    value: "",
    context: ""
  });
  const memoryTypes = [
    { value: "user_preference", label: "Brukerpreferanse", color: "bg-blue-500" },
    { value: "conversation_context", label: "Samtale-kontekst", color: "bg-green-500" },
    { value: "learned_fact", label: "Lært faktum", color: "bg-purple-500" },
    { value: "emotional_state", label: "Følelsestilstand", color: "bg-pink-500" },
    { value: "task_context", label: "Oppgave-kontekst", color: "bg-orange-500" },
    { value: "user_relationship", label: "Brukerforhold", color: "bg-red-500" },
    { value: "interaction_pattern", label: "Interaksjonsmønster", color: "bg-indigo-500" }
  ];
  const getTypeInfo = (type) => {
    return memoryTypes.find((t) => t.value === type) || memoryTypes[0];
  };
  const loadMemories = reactExports.useCallback(async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const memoryTypes2 = selectedType === "all" ? void 0 : [selectedType];
      const result = await memoryService.retrieveMemories(
        user.id,
        searchQuery || void 0,
        { memoryTypes: memoryTypes2, limit: 50 }
      );
      setMemories(result);
    } catch (error) {
      toast({
        title: "Feil",
        description: "Kunne ikke laste minner",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [user, selectedType, searchQuery, toast]);
  const loadStats = reactExports.useCallback(async () => {
    if (!user) return;
    try {
      const result = await memoryService.analyzeMemoryPatterns(user.id);
      setStats(result);
    } catch (error) {
      console.error("Feil ved lasting av statistikk:", error);
    }
  }, [user]);
  const loadAdminOverview = reactExports.useCallback(async () => {
    try {
      const result = await memoryService.getAdminOverview();
      setAdminOverview(result);
    } catch (error) {
      console.error("Feil ved lasting av admin oversikt:", error);
    }
  }, []);
  reactExports.useEffect(() => {
    if (user) {
      loadMemories();
      loadStats();
      if (isPremium) {
        loadAdminOverview();
      }
    }
  }, [user, isPremium, loadMemories, loadStats, loadAdminOverview]);
  const handleCreateMemory = async () => {
    if (!user || !newMemory.key || !newMemory.value) {
      toast({
        title: "Feil",
        description: "Vennligst fyll ut nøkkel og verdi",
        variant: "destructive"
      });
      return;
    }
    try {
      const result = await memoryService.storeMemory(
        user.id,
        newMemory.type,
        newMemory.key,
        newMemory.value,
        {
          context: newMemory.context,
          source: "manual_dashboard"
        }
      );
      if (result.success) {
        toast({
          title: "Minne lagret",
          description: `Minne ID: ${result.memory_id || "Ukjent"}`
        });
        setNewMemory({
          type: "user_preference",
          key: "",
          value: "",
          context: ""
        });
        loadMemories();
        loadStats();
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      toast({
        title: "Feil",
        description: "Kunne ikke lagre minne",
        variant: "destructive"
      });
    }
  };
  const handleDeleteMemory = async (key) => {
    if (!user) return;
    try {
      const result = await memoryService.forgetMemories(user.id, { key });
      if (result.success) {
        toast({
          title: "Minne slettet",
          description: `${result.deleted_count} minne(r) ble slettet`
        });
        loadMemories();
        loadStats();
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      toast({
        title: "Feil",
        description: "Kunne ikke slette minne",
        variant: "destructive"
      });
    }
  };
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString("nb-NO");
  };
  if (!user) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-400", children: "Du må være logget inn for å bruke minnesystemet." }) }) }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-cyberdark-950 text-cybergold-300", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "bg-cyberdark-900 border-b border-cyberdark-700 px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "h-6 w-6 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-cybergold-400", children: "Minnesjstem" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "AI-drevet langtidsminne for personalisering" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "bg-gradient-to-r from-cybergold-600 to-cybergold-400 text-black", children: [
          memories.length,
          " Minner"
        ] }),
        isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "border-cybergold-600 text-cybergold-400", children: "Admin Tilgang" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container max-w-7xl py-8 px-6", children: [
      stats && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "h-5 w-5 text-cybergold-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Totale Minner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: stats.total_memories })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "h-5 w-5 text-yellow-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Gj.snitt Viktighet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-2xl font-bold text-yellow-400", children: [
              (stats.avg_importance * 100).toFixed(0),
              "%"
            ] })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-5 w-5 text-green-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Maks Tilgang" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-green-400", children: stats.max_access_count })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-5 w-5 text-purple-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600", children: "Minnetyper" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-purple-400", children: stats.unique_types })
          ] })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, className: "w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-4 mb-6 bg-cyberdark-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TabsTrigger,
            {
              value: "memories",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "h-4 w-4 mr-2" }),
                "Minner"
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TabsTrigger,
            {
              value: "create",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
                "Opprett"
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TabsTrigger,
            {
              value: "analytics",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-4 w-4 mr-2" }),
                "Analyse"
              ]
            }
          ),
          isPremium && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TabsTrigger,
            {
              value: "admin",
              className: "data-[state=active]:bg-cybergold-600/20 data-[state=active]:text-cybergold-400",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4 mr-2" }),
                "Admin"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "memories", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-3 h-4 w-4 text-cybergold-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  placeholder: "Søk i minner...",
                  value: searchQuery,
                  onChange: (e) => setSearchQuery(e.target.value),
                  className: "pl-10 bg-cyberdark-800 border-cyberdark-700"
                }
              )
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-48", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: selectedType,
                onChange: (e) => setSelectedType(e.target.value),
                className: "w-full p-2 bg-cyberdark-800 border border-cyberdark-700 rounded text-cybergold-300",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "Alle typer" }),
                  memoryTypes.map((type) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: type.value, children: type.label }, type.value))
                ]
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                onClick: loadMemories,
                className: "bg-cybergold-600 hover:bg-cybergold-500 text-black",
                disabled: isLoading,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-4 w-4 mr-2" }),
                  "Søk"
                ]
              }
            )
          ] }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            memories.map((memory) => {
              const typeInfo = getTypeInfo(memory.memory_type);
              return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "p-6", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-3 h-3 rounded-full ${typeInfo.color}` }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-cybergold-400", children: memory.key }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "mt-1 border-current text-xs", children: typeInfo.label })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right text-sm", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Viktighet" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-400 font-mono", children: [
                        (memory.importance * 100).toFixed(0),
                        "%"
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Button,
                      {
                        size: "sm",
                        variant: "outline",
                        onClick: () => handleDeleteMemory(memory.key),
                        className: "border-red-600 text-red-400 hover:bg-red-600/20",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" })
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300 mb-4", children: memory.value }),
                memory.context && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm mb-1", children: "Kontekst" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-400 text-sm", children: memory.context })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 text-sm", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Tilgang" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-300", children: [
                      memory.access_count,
                      "x"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Opprettet" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300", children: formatDate(memory.created_at) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Sist brukt" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300", children: formatDate(memory.last_accessed) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600", children: "Kilde" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-300", children: memory.source || "Ukjent" })
                  ] })
                ] })
              ] }) }, memory.id);
            }),
            memories.length === 0 && !isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "p-8 text-center", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "h-12 w-12 text-cybergold-600 mx-auto mb-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-400", children: "Ingen minner funnet" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm mt-2", children: "Prøv å endre søkekriterier eller opprett ditt første minne." })
            ] }) })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "create", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Opprett Nytt Minne" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "type", children: "Minnetype" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "select",
                {
                  value: newMemory.type,
                  onChange: (e) => setNewMemory((prev) => ({ ...prev, type: e.target.value })),
                  className: "w-full p-2 mt-1 bg-cyberdark-800 border border-cyberdark-700 rounded text-cybergold-300",
                  children: memoryTypes.map((type) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: type.value, children: type.label }, type.value))
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "key", children: "Nøkkel" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "key",
                  placeholder: "f.eks. 'favoritt_farge' eller 'musikk_preferanse'",
                  value: newMemory.key,
                  onChange: (e) => setNewMemory((prev) => ({ ...prev, key: e.target.value })),
                  className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "value", children: "Verdi" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Textarea,
                {
                  id: "value",
                  placeholder: "Skriv minneinnholdet her...",
                  value: newMemory.value,
                  onChange: (e) => setNewMemory((prev) => ({ ...prev, value: e.target.value })),
                  className: "mt-1 bg-cyberdark-800 border-cyberdark-700",
                  rows: 3
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "context", children: "Kontekst (valgfritt)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "context",
                  placeholder: "f.eks. 'Fra samtale om musikk'",
                  value: newMemory.context,
                  onChange: (e) => setNewMemory((prev) => ({ ...prev, context: e.target.value })),
                  className: "mt-1 bg-cyberdark-800 border-cyberdark-700"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                onClick: handleCreateMemory,
                className: "w-full bg-cybergold-600 hover:bg-cybergold-500 text-black",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
                  "Lagre Minne"
                ]
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "analytics", children: stats && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Minnefordeling etter Type" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: stats.type_distribution.map((type) => {
            const typeInfo = getTypeInfo(type.memory_type);
            const percentage = type.count / stats.total_memories * 100;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-3 h-3 rounded-full ${typeInfo.color}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-300", children: typeInfo.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-400 text-sm", children: type.count })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full bg-cyberdark-800 rounded-full h-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `h-2 rounded-full ${typeInfo.color} opacity-70`,
                    style: { width: `${percentage}%` }
                  }
                ) })
              ] })
            ] }, type.memory_type);
          }) }) })
        ] }) }) }),
        isPremium && adminOverview && /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "admin", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Admin Oversikt" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "Totale Brukere" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: adminOverview.total_statistics.total_users })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "Totale Minner" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-cybergold-400", children: adminOverview.total_statistics.total_memories })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "Total Størrelse" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-2xl font-bold text-cybergold-400", children: [
                  (adminOverview.total_statistics.total_size_bytes / 1024 / 1024).toFixed(1),
                  " MB"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-600 text-sm", children: "Gj.snitt Viktighet" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-2xl font-bold text-cybergold-400", children: [
                  (adminOverview.total_statistics.avg_importance * 100).toFixed(0),
                  "%"
                ] })
              ] })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-cybergold-400", children: "Top Brukere (Minnebruk)" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: adminOverview.top_users.slice(0, 10).map((user2, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between p-3 bg-cyberdark-800 rounded", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "outline", className: "border-cybergold-600 text-cybergold-400", children: [
                  "#",
                  index + 1
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-cybergold-300 font-mono", children: [
                  user2.user_id.slice(0, 8),
                  "..."
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-400", children: [
                  user2.total_memories,
                  " minner"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-cybergold-600 text-sm", children: [
                  (user2.total_size_bytes / 1024).toFixed(1),
                  " KB"
                ] })
              ] })
            ] }, user2.user_id)) }) })
          ] })
        ] }) })
      ] })
    ] })
  ] });
};
const MemoryDashboard$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: MemoryDashboard
}, Symbol.toStringTag, { value: "Module" }));
export {
  AdminSecurityPanel$1 as A,
  CreateGroupPage$1 as C,
  Dashboard$1 as D,
  Friends$1 as F,
  Info$1 as I,
  MCPDashboard$1 as M,
  Profile$1 as P,
  Subscription$1 as S,
  FindFriends$1 as a,
  Settings$1 as b,
  Mail$1 as c,
  MemoryDashboard$1 as d
};
//# sourceMappingURL=pages-main-MXMMLxmC.js.map
