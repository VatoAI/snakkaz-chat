const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/js/pages-main-MXMMLxmC.js","assets/js/vendor-react-core-dw-u3J8o.js","assets/js/vendor-react-dom-4lR9Lo0M.js","assets/js/vendor-misc-1EIi_gUb.js","assets/js/vendor-database-CiOqrkV0.js","assets/js/app-utils-Cjj9E4GC.js","assets/js/vendor-utils-CDGg_kJ1.js","assets/js/app-services-LZknheK6.js","assets/js/vendor-security-LdHy7Pt9.js","assets/js/vendor-router-CWDrJeTE.js"])))=>i.map(i=>d[i]);
import { r as reactExports, j as jsxRuntimeExports, ax as CircleAlert, ay as RefreshCw, az as MessageCircle, aA as User, aB as Settings, aC as Crown, aD as LogOut, aE as AnimatePresence, aF as motion, aG as House, aH as Heart, aI as Bot, aJ as Globe, aK as Shield, aL as Menu, aM as ArrowLeft, aN as Plus, aO as MessageSquare, aP as Users, aQ as Mail$1, aR as Brain, aS as Search, aT as Info, aU as ShieldCheck, aV as EyeOff, a3 as Circle, aW as Moon, aX as LoaderCircle, aY as Clock, aZ as dist, a_ as UserPlus, a$ as UserRoundX, h as Check, X, b0 as Bell, b1 as Palette, b2 as Inbox, b3 as Send, b4 as Archive, b5 as Star, b6 as Database, b7 as ChartColumn, b8 as QRCodeSVG, b9 as Code, ba as Bitcoin, bb as React, bc as Lock, bd as Copy, be as ExternalLink, bf as Trash2, bg as ShieldAlert } from "./vendor-react-core-dw-u3J8o.js";
import { L as Label, I as Input, u as useAuth, B as Button, C as Card, a as useIsMobile, b as useIsAdmin, c as cn, d as useDeviceDetection, e as useMobilePinSecurity, T as TooltipProvider, f as Tooltip, g as TooltipTrigger, h as TooltipContent, A as Avatar, i as AvatarImage, j as AvatarFallback, k as useToast, l as Tabs, m as TabsList, n as TabsTrigger, o as Badge, p as TabsContent, S as ScrollArea, D as Dialog, q as DialogContent, r as DialogHeader, t as DialogTitle, v as DialogFooter, w as useToast$1, x as supabase, y as Skeleton, z as CardHeader, E as CardContent, F as CardTitle, G as CardDescription, H as CardFooter, J as DialogDescription, K as Separator, M as Alert, N as AlertTitle, O as AlertDescription, P as DialogTrigger } from "./app-utils-Cjj9E4GC.js";
import "./vendor-database-CiOqrkV0.js";
import { a as useLocation, L as Link, u as useNavigate } from "./vendor-router-CWDrJeTE.js";
import { a as axios } from "./vendor-network-BSBq6A-N.js";
import { s as subscriptionService, P as PremiumFeature } from "./app-services-LZknheK6.js";
import { p as passwordStrength } from "./vendor-misc-1EIi_gUb.js";
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
const PreviewBanner = () => {
  {
    return null;
  }
};
const DeveloperTools = () => {
  const [isOpen, setIsOpen] = reactExports.useState(false);
  {
    return null;
  }
};
const MathCaptcha = ({
  onVerificationChange,
  isLoading = false,
  error
}) => {
  const [num1, setNum1] = reactExports.useState(0);
  const [num2, setNum2] = reactExports.useState(0);
  const [userAnswer, setUserAnswer] = reactExports.useState("");
  const [isCorrect, setIsCorrect] = reactExports.useState(false);
  const [attempts, setAttempts] = reactExports.useState(0);
  const [isLocked, setIsLocked] = reactExports.useState(false);
  const onVerificationChangeRef = reactExports.useRef(onVerificationChange);
  onVerificationChangeRef.current = onVerificationChange;
  const generateNewProblem = reactExports.useCallback(() => {
    const newNum1 = Math.floor(Math.random() * 10) + 1;
    const newNum2 = Math.floor(Math.random() * 10) + 1;
    setNum1(newNum1);
    setNum2(newNum2);
    setUserAnswer("");
    setIsCorrect(false);
    setAttempts(0);
    onVerificationChangeRef.current(false, "");
  }, []);
  reactExports.useEffect(() => {
    const newNum1 = Math.floor(Math.random() * 10) + 1;
    const newNum2 = Math.floor(Math.random() * 10) + 1;
    setNum1(newNum1);
    setNum2(newNum2);
    setUserAnswer("");
    setIsCorrect(false);
    setAttempts(0);
    onVerificationChangeRef.current(false, "");
  }, []);
  reactExports.useEffect(() => {
    if (!userAnswer) {
      setIsCorrect(false);
      onVerificationChangeRef.current(false, "");
      return;
    }
    const correct = parseInt(userAnswer) === num1 + num2;
    setIsCorrect(correct);
    if (correct) {
      const token = btoa(`${num1}-${num2}-${userAnswer}-${Date.now()}`);
      onVerificationChangeRef.current(true, token);
      setAttempts(0);
    } else {
      onVerificationChangeRef.current(false, "");
      if (userAnswer.length >= 1) {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        if (newAttempts >= 3) {
          setIsLocked(true);
          setTimeout(() => {
            setIsLocked(false);
            setAttempts(0);
            const newNum1 = Math.floor(Math.random() * 10) + 1;
            const newNum2 = Math.floor(Math.random() * 10) + 1;
            setNum1(newNum1);
            setNum2(newNum2);
            setUserAnswer("");
            setIsCorrect(false);
            onVerificationChangeRef.current(false, "");
          }, 3e4);
        }
      }
    }
  }, [userAnswer, num1, num2, attempts]);
  const handleRefresh = reactExports.useCallback(() => {
    generateNewProblem();
  }, [generateNewProblem]);
  const handleAnswerChange = (value) => {
    if (isLocked) return;
    const numericValue = value.replace(/[^0-9]/g, "");
    setUserAnswer(numericValue);
  };
  const getStatusColor = () => {
    if (isLocked) return "text-red-500";
    if (userAnswer && isCorrect) return "text-green-500";
    if (userAnswer && !isCorrect) return "text-red-500";
    return "text-cybergold-500";
  };
  const getStatusText = () => {
    if (isLocked) return "🔒 Låst i 30 sekunder";
    if (userAnswer && isCorrect) return "✓ Riktig!";
    if (userAnswer && !isCorrect) return `✗ Feil (${3 - attempts} forsøk igjen)`;
    return "";
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-cybergold-300 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" }),
      "Verifisering - Løs regnestykket:"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-cybergold-200 font-mono text-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bg-cyberdark-800 px-3 py-2 rounded border border-cybergold-500/30", children: num1 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "+" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bg-cyberdark-800 px-3 py-2 rounded border border-cybergold-500/30", children: num2 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "=" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Input,
        {
          type: "text",
          value: userAnswer,
          onChange: (e) => handleAnswerChange(e.target.value),
          placeholder: "?",
          className: `w-20 text-center bg-cyberdark-800 border-cybergold-500/30 text-cybergold-200 ${isCorrect ? "border-green-500" : ""} ${isLocked ? "opacity-50 cursor-not-allowed" : ""}`,
          disabled: isLoading || isLocked,
          maxLength: 3
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handleRefresh,
          disabled: isLoading || isLocked,
          className: "p-2 text-cybergold-500 hover:text-cybergold-400 transition-colors disabled:opacity-50",
          title: "Ny oppgave",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-4 w-4" })
        }
      )
    ] }),
    (userAnswer || isLocked) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-sm ${getStatusColor()} flex items-center gap-1`, children: getStatusText() }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-red-400 flex items-center gap-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-3 w-3" }),
      error
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-cyberdark-400", children: "Dette beskytter mot automatiserte angrep" })
  ] });
};
const FreeUserNavigation = () => {
  var _a;
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigationItems = [
    {
      path: "/basic-chat",
      label: "Chat",
      icon: MessageCircle,
      description: "Gratis chat for alle"
    },
    {
      path: "/profile",
      label: "Profil",
      icon: User,
      description: "Din profil"
    },
    {
      path: "/settings",
      label: "Innstillinger",
      icon: Settings,
      description: "Appinnstillinger"
    }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-cyberdark-900 border-r border-cyberdark-700 w-64 h-screen flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-b border-cyberdark-700", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-bold text-cyberprimary-100 mb-1", children: "Snakkaz" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cyberdark-300", children: "Velkommen!" }),
      user && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cyberdark-400 mt-1", children: (_a = user.email) == null ? void 0 : _a.split("@")[0] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "flex-1 p-4 space-y-2", children: navigationItems.map((item) => {
      const Icon = item.icon;
      const isActive = location.pathname === item.path;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: item.path, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: isActive ? "default" : "ghost",
          className: `w-full justify-start gap-3 h-auto p-3 ${isActive ? "bg-cyberprimary-600 hover:bg-cyberprimary-700 text-white" : "text-cyberdark-200 hover:text-cyberprimary-200 hover:bg-cyberdark-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: item.label }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-70", children: item.description })
            ] })
          ]
        }
      ) }, item.path);
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 border-t border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-gradient-to-r from-cyberprimary-900/20 to-cybersecondary-900/20 border-cyberprimary-500/30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-4 w-4 text-cyberprimary-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-cyberprimary-200", children: "Premium" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cyberdark-300 mb-3", children: "Få tilgang til krypterte meldinger, avanserte BTC-analyser og mer!" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/subscription", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          size: "sm",
          className: "w-full bg-cyberprimary-600 hover:bg-cyberprimary-700 text-white",
          children: "Oppgrader"
        }
      ) })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 border-t border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        onClick: () => signOut(),
        variant: "ghost",
        className: "w-full justify-start gap-2 text-cyberdark-300 hover:text-cyberdark-100 hover:bg-cyberdark-800",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
          "Logg ut"
        ]
      }
    ) })
  ] });
};
const MobileMenu = ({ isOpen, setIsOpen }) => {
  var _a;
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const { signOut, user } = useAuth();
  const navigationItems = [
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(House, { size: 24 }),
      label: "Hjem",
      action: () => {
        navigate("/");
        setIsOpen(false);
      },
      color: "text-cybergold-400"
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { size: 24 }),
      label: "Chat",
      action: () => {
        navigate("/basic-chat");
        setIsOpen(false);
      },
      color: "text-cyberblue-400"
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { size: 24 }),
      label: "Venner",
      action: () => {
        navigate("/friends");
        setIsOpen(false);
      },
      color: "text-cyberred-400",
      authRequired: true
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { size: 24 }),
      label: "AI Assistent",
      action: () => {
        navigate("/ai-chat");
        setIsOpen(false);
      },
      color: "text-cyberprimary-400",
      authRequired: true
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { size: 24 }),
      label: "Grupper",
      action: () => {
        navigate("/group-chat");
        setIsOpen(false);
      },
      color: "text-cybergreen-400",
      authRequired: true
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { size: 24 }),
      label: "Profil",
      action: () => {
        navigate("/profile");
        setIsOpen(false);
      },
      color: "text-cybergold-400",
      authRequired: true
    }
  ];
  const settingsItems = [
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { size: 24 }),
      label: "Sikkerhet",
      action: () => {
        navigate("/settings");
        setIsOpen(false);
      },
      color: "text-cybergreen-400",
      authRequired: true
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { size: 24 }),
      label: "Innstillinger",
      action: () => {
        navigate("/settings");
        setIsOpen(false);
      },
      color: "text-cyberdark-400"
    },
    {
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { size: 24 }),
      label: "Logg ut",
      action: () => {
        signOut();
        setIsOpen(false);
      },
      color: "text-cyberred-400",
      authRequired: true
    }
  ];
  const filteredNavItems = navigationItems.filter((item) => !item.authRequired || user);
  const filteredSettingsItems = settingsItems.filter((item) => !item.authRequired || user);
  if (!isMobile) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: isOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.div,
      {
        className: "fixed inset-0 bg-black/50 z-40",
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        onClick: () => setIsOpen(false)
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        className: "fixed bottom-0 left-0 right-0 bg-cyberdark-900 rounded-t-2xl z-50 px-4 py-6 shadow-lg border-t border-cyberdark-700 max-h-[80vh] overflow-y-auto",
        initial: { y: "100%" },
        animate: { y: 0 },
        exit: { y: "100%" },
        transition: { type: "spring", damping: 25, stiffness: 200 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-1 rounded-full bg-cyberdark-600 mx-auto mb-6" }),
          user && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-6 p-3 bg-cyberdark-800 rounded-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-cybergold-600 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { size: 20, className: "text-black" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-400 font-medium", children: ((_a = user.user_metadata) == null ? void 0 : _a.username) || "Bruker" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cyberdark-400 text-sm truncate", children: user.email })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-cybergold-400 font-medium mb-3 px-2", children: "Navigasjon" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-3", children: filteredNavItems.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "flex flex-col items-center justify-center p-3 rounded-lg bg-cyberdark-800/50 hover:bg-cyberdark-800 transition-colors cursor-pointer",
                onClick: item.action,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-12 h-12 rounded-full bg-cyberdark-700 flex items-center justify-center mb-2 ${item.color}`, children: item.icon }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-cybergold-300 text-center", children: item.label })
                ]
              },
              index
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-cybergold-400 font-medium mb-3 px-2", children: "Innstillinger" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: filteredSettingsItems.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                className: `w-full flex items-center gap-3 p-3 rounded-lg bg-cyberdark-800/50 hover:bg-cyberdark-800 transition-colors text-left ${item.color}`,
                onClick: item.action,
                children: [
                  item.icon,
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-300", children: item.label })
                ]
              },
              index
            )) })
          ] })
        ]
      }
    )
  ] }) });
};
const AppHeader = ({
  variant = "default",
  context,
  title,
  subtitle,
  avatar,
  actions,
  onBackClick,
  onMenuClick,
  onAddClick,
  children,
  className
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: `bg-cyberdark-900 border-b border-cyberdark-700 p-3 flex items-center ${className || ""}`, children: [
    onMenuClick && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "ghost",
        size: "icon",
        className: "mr-2 rounded-full h-9 w-9 text-cybergold-400 hover:text-cybergold-300 hover:bg-cyberdark-800",
        onClick: onMenuClick,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Meny" })
        ]
      }
    ),
    onBackClick && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "ghost",
        size: "icon",
        className: "mr-2 rounded-full h-9 w-9 text-cybergold-400 hover:text-cybergold-300 hover:bg-cyberdark-800 lg:hidden",
        onClick: onBackClick,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-5 w-5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Tilbake" })
        ]
      }
    ),
    avatar && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mr-3", children: avatar }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold text-cybergold-400 truncate", children: title }),
      subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-cybergold-600 truncate", children: subtitle })
    ] }),
    onAddClick && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "ghost",
        size: "icon",
        className: "mr-2 rounded-full h-9 w-9 text-cybergold-400 hover:text-cybergold-300 hover:bg-cyberdark-800",
        onClick: onAddClick,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-5 w-5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Legg til" })
        ]
      }
    ),
    actions && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center space-x-1", children: actions }),
    children && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-auto", children })
  ] });
};
const UnifiedNavigation = ({
  variant = "horizontal",
  className,
  activeIndicator = true,
  compact = false,
  showLabels = true,
  onItemSelect
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const isAdmin = useIsAdmin();
  const [hoveredItem, setHoveredItem] = reactExports.useState(null);
  const navRef = reactExports.useRef(null);
  const activeIndicatorRef = reactExports.useRef(null);
  const navItems = [
    {
      path: "/dashboard",
      label: "Dashboard",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/basic-chat",
      label: "Chat Hub",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/ai-chat",
      label: "AI Assistent",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/group-chat",
      label: "Grupper",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/friends",
      label: "Venner",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/mail",
      label: "Mail",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$1, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/memory",
      label: "Memory",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "h-5 w-5" }),
      authRequired: true,
      hideOnMobile: true
    },
    {
      path: "/find-friends",
      label: "Finn Venner",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-5 w-5" }),
      authRequired: true,
      hideOnMobile: true
    },
    {
      path: "/profile",
      label: "Profil",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5" }),
      authRequired: true
    },
    {
      path: "/settings",
      label: "Innstillinger",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "h-5 w-5" }),
      authRequired: true,
      hideOnMobile: true
    },
    {
      path: "/info",
      label: "Info",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-5 w-5" })
    },
    {
      path: "/admin",
      label: "Admin",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-5 w-5" }),
      adminRequired: true
    }
  ];
  const filteredNavItems = navItems.filter((item) => {
    if (item.authRequired && !user) return false;
    if (item.adminRequired && !isAdmin) return false;
    if (item.hideOnMobile && isMobile) return false;
    return true;
  });
  const isActive = (path) => {
    if (path === "/dashboard") {
      return location.pathname === "/" || location.pathname === "/dashboard";
    } else if (path === "/basic-chat" && (location.pathname.startsWith("/basic-chat") || location.pathname.startsWith("/chat"))) {
      return true;
    } else if (path === "/messages" && location.pathname.startsWith("/messages")) {
      return true;
    } else {
      return location.pathname.startsWith(path);
    }
  };
  const updateActiveIndicator = reactExports.useCallback(() => {
    if (!navRef.current || !activeIndicatorRef.current) return;
    const activeButton = navRef.current.querySelector(".nav-active");
    if (activeButton) {
      const rect = activeButton.getBoundingClientRect();
      const navRect = navRef.current.getBoundingClientRect();
      if (variant === "horizontal") {
        activeIndicatorRef.current.style.width = `${rect.width}px`;
        activeIndicatorRef.current.style.height = "2px";
        activeIndicatorRef.current.style.left = `${rect.left - navRect.left}px`;
        activeIndicatorRef.current.style.top = "auto";
        activeIndicatorRef.current.style.bottom = "0";
      } else if (variant === "vertical") {
        activeIndicatorRef.current.style.width = "2px";
        activeIndicatorRef.current.style.height = `${rect.height}px`;
        activeIndicatorRef.current.style.left = "0";
        activeIndicatorRef.current.style.top = `${rect.top - navRect.top}px`;
      } else {
        activeIndicatorRef.current.style.width = `${rect.width}px`;
        activeIndicatorRef.current.style.height = "2px";
        activeIndicatorRef.current.style.left = `${rect.left - navRect.left}px`;
        activeIndicatorRef.current.style.top = "0";
        activeIndicatorRef.current.style.bottom = "auto";
      }
      activeIndicatorRef.current.style.opacity = "1";
    } else {
      activeIndicatorRef.current.style.opacity = "0";
    }
  }, [variant]);
  reactExports.useEffect(() => {
    if (activeIndicator) {
      updateActiveIndicator();
    }
  }, [location.pathname, activeIndicator, updateActiveIndicator]);
  const handleNavItemHover = (path) => {
    setHoveredItem(path);
  };
  const handleNavItemLeave = () => {
    setHoveredItem(null);
  };
  const handleItemClick = (path) => {
    navigate(path);
    if (onItemSelect) {
      onItemSelect();
    }
  };
  const containerClasses = cn(
    "relative",
    variant === "horizontal" && "flex items-center gap-1 p-0.5",
    variant === "vertical" && "flex flex-col gap-2 p-0.5",
    variant === "bottom" && "fixed bottom-0 left-0 right-0 bg-cyberdark-900 border-t border-cyberdark-700 p-2 flex items-center justify-around",
    variant === "mobile" && "fixed bottom-0 left-0 right-0 bg-cyberdark-900 border-t border-cyberdark-700 px-2 pt-3 pb-4 mobile-bottom-safe flex items-center justify-around z-50 shadow-lg backdrop-blur-sm",
    // Enhanced mobile touch targets
    (variant === "mobile" || variant === "bottom") && "min-h-[60px]",
    className
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "nav",
    {
      ref: navRef,
      className: containerClasses,
      "aria-label": "Main Navigation",
      children: [
        filteredNavItems.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          NavButton,
          {
            path: item.path,
            icon: item.icon,
            label: item.label,
            isActive: isActive(item.path),
            onHover: handleNavItemHover,
            onLeave: handleNavItemLeave,
            isHovered: hoveredItem === item.path,
            onClick: () => handleItemClick(item.path),
            adminButton: item.adminRequired,
            variant,
            compact,
            showLabel: showLabels
          },
          item.path
        )),
        activeIndicator && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            ref: activeIndicatorRef,
            className: "absolute bg-gradient-to-r from-cybergold-400 to-cybergold-500 rounded-full transition-all duration-300 ease-in-out shadow-[0_0_5px_rgba(218,188,69,0.5)]"
          }
        )
      ]
    }
  );
};
const NavButton = ({
  path,
  icon,
  label,
  isActive,
  onHover,
  onLeave,
  isHovered,
  onClick,
  adminButton = false,
  variant,
  compact = false,
  showLabel = true
}) => {
  const buttonClasses = cn(
    "group transition-all duration-200 relative flex items-center",
    isActive ? "nav-active" : "",
    // Horizontal variant styling
    variant === "horizontal" && "px-3 py-2 rounded-md gap-2",
    variant === "horizontal" && isActive && "bg-gradient-to-b from-cyberdark-800 to-cyberdark-850",
    variant === "horizontal" && !isActive && "hover:bg-cyberdark-800/40",
    // Vertical variant styling
    variant === "vertical" && "px-3 py-2 rounded-md w-full gap-3 justify-start",
    variant === "vertical" && isActive && "bg-gradient-to-r from-cyberdark-800 to-cyberdark-850",
    variant === "vertical" && !isActive && "hover:bg-cyberdark-800/40",
    // Bottom/Mobile variant styling - Enhanced for better touch UX
    (variant === "bottom" || variant === "mobile") && "flex-col items-center p-3 gap-1 w-full min-h-[48px] touch-manipulation",
    (variant === "bottom" || variant === "mobile") && "active:scale-95 transition-transform duration-150",
    // Compact mode
    compact && "p-1.5",
    // Text colors
    isActive ? adminButton ? "text-emerald-400" : "text-cybergold-400" : adminButton ? "text-emerald-600 hover:text-emerald-400" : "text-cybergold-600 hover:text-cybergold-400"
  );
  const iconClasses = cn(
    "transition-transform",
    variant !== "bottom" && variant !== "mobile" && "group-hover:scale-110",
    compact ? "h-4 w-4" : "h-5 w-5",
    isActive ? adminButton ? "text-emerald-400" : "text-cybergold-400" : adminButton ? "text-emerald-600" : "text-cybergold-600",
    (variant === "mobile" || variant === "bottom") && isActive && "animate-pulse-subtle"
  );
  const labelClasses = cn(
    "font-medium transition-all",
    compact ? "text-xs" : "text-sm",
    isActive ? adminButton ? "text-emerald-400" : "text-cybergold-400" : adminButton ? "text-emerald-600" : "text-cybergold-600",
    variant === "bottom" || variant === "mobile" ? "text-xs mt-1" : "",
    variant === "horizontal" && !showLabel && "hidden",
    variant === "horizontal" && showLabel && "hidden sm:block"
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      className: buttonClasses,
      onClick,
      onMouseEnter: () => onHover(path),
      onMouseLeave: onLeave,
      "aria-label": label,
      "aria-current": isActive ? "page" : void 0,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: iconClasses, children: icon }),
        showLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: labelClasses, children: label }),
        isActive && (variant !== "bottom" && variant !== "mobile") && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-0.5 left-1/2 transform -translate-x-1/2 w-1 h-1 rounded-full bg-cybergold-400 shadow-[0_0_5px_rgba(218,188,69,0.8)]" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn(
          "absolute inset-0 rounded-md opacity-0 transition-opacity duration-300",
          isHovered && !isActive ? "opacity-10" : "",
          adminButton ? "bg-emerald-500" : "bg-cybergold-400"
        ) })
      ]
    }
  );
};
const MobileLayout = ({ children }) => {
  const isMobile = useIsMobile();
  useDeviceDetection();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = reactExports.useState(false);
  const [title, setTitle] = reactExports.useState("SnakkaZ");
  const { isLocked, verifyPin } = useMobilePinSecurity();
  const [pinInput, setPinInput] = reactExports.useState("");
  reactExports.useEffect(() => {
    const path = location.pathname;
    if (path.includes("/basic-chat") || path.includes("/chat")) {
      setTitle("Chat");
    } else if (path.includes("/friends")) {
      setTitle("Venner");
    } else if (path.includes("/ai-chat")) {
      setTitle("AI Assistent");
    } else if (path.includes("/global-chat")) {
      setTitle("Global Chat");
    } else if (path.includes("/settings")) {
      setTitle("Innstillinger");
    } else if (path.includes("/security")) {
      setTitle("Sikkerhet");
    } else if (path.includes("/profile")) {
      setTitle("Profil");
    } else {
      setTitle("SnakkaZ");
    }
  }, [location]);
  const handlePinSubmit = () => {
    if (pinInput.length === 4) {
      if (verifyPin(pinInput)) {
        setPinInput("");
      } else {
        setPinInput("");
      }
    }
  };
  const handlePinDigit = (digit) => {
    if (pinInput.length < 4) {
      const newPin = pinInput + digit;
      setPinInput(newPin);
      if (newPin.length === 4) {
        setTimeout(() => {
          handlePinSubmit();
        }, 200);
      }
    }
  };
  const handlePinDelete = () => {
    setPinInput((prev) => prev.slice(0, -1));
  };
  if (!isMobile) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children });
  }
  if (isLocked) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-[100svh] bg-background p-6 mobile-safe-padding", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold mb-8", children: "Lås opp SnakkaZ" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-3 mb-8", children: [0, 1, 2, 3].map((i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: `w-4 h-4 rounded-full ${i < pinInput.length ? "bg-primary" : "bg-muted"}`
        },
        i
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-4 w-full max-w-xs", children: [
        [1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center text-2xl font-medium mobile-touch-target",
            onClick: () => handlePinDigit(num.toString()),
            children: num
          },
          num
        )),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16" }),
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center text-2xl font-medium mobile-touch-target",
            onClick: () => handlePinDigit("0"),
            children: "0"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mobile-touch-target",
            onClick: handlePinDelete,
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M12 19l-7-7 7-7" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M19 12H5" })
            ] })
          }
        )
      ] })
    ] });
  }
  const handleMenuOpen = () => setMenuOpen(true);
  const handleAddNew = () => {
    const path = location.pathname;
    if (path.includes("/basic-chat") || path.includes("/chat")) {
      navigate("/friends");
    } else if (path.includes("/friends")) {
      navigate("/basic-chat");
    }
  };
  const hideNavigation = location.pathname.includes("/chat/") || location.pathname.includes("/conversation/");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-[100svh] bg-cyberdark-950 mobile-dynamic-height", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AppHeader,
      {
        variant: "default",
        title,
        onMenuClick: handleMenuOpen,
        onAddClick: location.pathname === "/messages" || location.pathname === "/basic-chat" ? handleAddNew : void 0,
        className: "mobile-top-safe border-b border-cyberdark-700 bg-cyberdark-900"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex-1 overflow-hidden ${!hideNavigation ? "pb-16" : ""}`, children }),
    !hideNavigation && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-0 left-0 right-0 z-50 bg-cyberdark-900 border-t border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(UnifiedNavigation, { variant: "mobile" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(MobileMenu, { isOpen: menuOpen, setIsOpen: setMenuOpen })
  ] });
};
function getInitials(name) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return name.charAt(0).toUpperCase();
  }
  if (parts.length >= 2) {
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  }
  return "?";
}
const statusColors = {
  online: {
    primary: "text-emerald-500",
    bg: "bg-emerald-500",
    border: "border-emerald-500",
    glow: "shadow-[0_0_10px_theme(colors.emerald.500)]"
  },
  busy: {
    primary: "text-amber-500",
    bg: "bg-amber-500",
    border: "border-amber-500",
    glow: "shadow-[0_0_10px_theme(colors.amber.500)]"
  },
  brb: {
    primary: "text-blue-500",
    bg: "bg-blue-500",
    border: "border-blue-500",
    glow: "shadow-[0_0_10px_theme(colors.blue.500)]"
  },
  away: {
    primary: "text-purple-500",
    bg: "bg-purple-500",
    border: "border-purple-500",
    glow: "shadow-[0_0_10px_theme(colors.purple.500)]"
  },
  offline: {
    primary: "text-gray-500",
    bg: "bg-gray-500",
    border: "border-gray-500",
    glow: "shadow-[0_0_10px_theme(colors.gray.500)]"
  },
  invisible: {
    primary: "text-gray-400",
    bg: "bg-gray-400",
    border: "border-gray-400",
    glow: "shadow-[0_0_10px_theme(colors.gray.400)]"
  }
};
const securityColors = {
  p2p_e2ee: {
    primary: "text-emerald-500",
    bg: "bg-emerald-500/20",
    border: "border-emerald-500",
    glow: "shadow-[0_0_10px_theme(colors.emerald.500)]"
  },
  server_e2ee: {
    primary: "text-blue-500",
    bg: "bg-blue-500/20",
    border: "border-blue-500",
    glow: "shadow-[0_0_10px_theme(colors.blue.500)]"
  },
  standard: {
    primary: "text-amber-500",
    bg: "bg-amber-500/20",
    border: "border-amber-500",
    glow: "shadow-[0_0_10px_theme(colors.amber.500)]"
  }
};
const statusIcons = {
  online: Circle,
  busy: Clock,
  brb: LoaderCircle,
  away: Moon,
  offline: Circle,
  invisible: EyeOff
};
const statusLabels = {
  online: "Online",
  busy: "Opptatt",
  brb: "BRB",
  away: "Borte",
  offline: "Offline",
  invisible: "Usynlig"
};
const StatusIcon = ({ status, className, size = 4, pulseEffect = false }) => {
  const Icon = statusIcons[status] || statusIcons.offline;
  const statusColor = statusColors[status] || statusColors.offline;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: cn(
    `w-${size} h-${size}`,
    statusColor.primary,
    pulseEffect && "animate-pulse",
    className
  ) });
};
function StatusIndicator({
  status,
  size = "md",
  className,
  showLabel = false,
  animated = true,
  lastActive
}) {
  const [timeAgo, setTimeAgo] = reactExports.useState("");
  const sizeMap = {
    sm: 3,
    md: 4,
    lg: 5
  };
  reactExports.useEffect(() => {
    if (!lastActive || status === "online") return;
    const updateTimeAgo = () => {
      if (!lastActive) return "";
      const now = /* @__PURE__ */ new Date();
      const activeTime = typeof lastActive === "string" ? new Date(lastActive) : lastActive;
      const diffMs = now.getTime() - activeTime.getTime();
      const diffMins = Math.floor(diffMs / 6e4);
      if (diffMins < 1) return "nå nettopp";
      if (diffMins < 60) return `${diffMins} min siden`;
      const diffHrs = Math.floor(diffMins / 60);
      if (diffHrs < 24) return `${diffHrs} t siden`;
      const diffDays = Math.floor(diffHrs / 24);
      return `${diffDays} d siden`;
    };
    setTimeAgo(updateTimeAgo());
    const interval = setInterval(() => {
      setTimeAgo(updateTimeAgo());
    }, 6e4);
    return () => clearInterval(interval);
  }, [lastActive, status]);
  const label = statusLabels[status] || "Offline";
  const tooltipContent = status === "offline" && timeAgo ? `${label} · Sist aktiv ${timeAgo}` : label;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Tooltip, { delayDuration: 300, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn(
      "flex items-center",
      className
    ), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        StatusIcon,
        {
          status,
          size: sizeMap[size],
          pulseEffect: animated && status === "online",
          className: "mr-1.5"
        }
      ),
      showLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium", children: label })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs", children: tooltipContent }) })
  ] }) });
}
const UserAvatar = ({
  src,
  avatarUrl,
  // Added alternative prop for avatar URL
  alt = "User",
  fallback,
  size = 40,
  status,
  className,
  fallbackClassName,
  isGroup = false
  // Default to false
}) => {
  const imageUrl = src || avatarUrl;
  const initials = fallback || getInitials(alt);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Avatar,
      {
        className: cn(
          "border-2",
          isGroup ? "border-cybergold-700" : "border-cyberdark-700",
          className
        ),
        style: { width: size, height: size },
        children: imageUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarImage, { src: imageUrl, alt }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          AvatarFallback,
          {
            className: cn(
              "bg-cyberdark-700 text-cybergold-300",
              fallbackClassName
            ),
            children: initials
          }
        )
      }
    ),
    status && !isGroup && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-0 right-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      StatusIndicator,
      {
        status,
        size: "sm",
        className: "rounded-full border-2 border-cyberdark-900 bg-cyberdark-900 p-0.5"
      }
    ) })
  ] });
};
const EnhancedFriendsList = ({ currentUserId }) => {
  dist.useSupabaseClient();
  const { toast } = useToast();
  const [friends, setFriends] = reactExports.useState([]);
  const [incomingRequests, setIncomingRequests] = reactExports.useState([]);
  const [outgoingRequests, setOutgoingRequests] = reactExports.useState([]);
  const [isAddFriendDialogOpen, setIsAddFriendDialogOpen] = reactExports.useState(false);
  const [searchUsername, setSearchUsername] = reactExports.useState("");
  const [searchResults, setSearchResults] = reactExports.useState([]);
  const [isSearching, setIsSearching] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!currentUserId) return;
    fetchFriendsAndRequests();
  }, [currentUserId]);
  const fetchFriendsAndRequests = async () => {
    try {
      setFriends([
        {
          id: "1",
          username: "alex_tech",
          avatar_url: "/avatars/alex.png",
          status: "online",
          lastActive: /* @__PURE__ */ new Date()
        },
        {
          id: "2",
          username: "sarah_design",
          avatar_url: "/avatars/sarah.png",
          status: "offline",
          lastActive: new Date(Date.now() - 8 * 60 * 60 * 1e3)
        },
        {
          id: "3",
          username: "mike_dev",
          avatar_url: "/avatars/mike.png",
          status: "away",
          lastActive: new Date(Date.now() - 30 * 60 * 1e3)
        }
      ]);
      setIncomingRequests([
        {
          id: "4",
          username: "emma_newuser",
          avatar_url: "/avatars/emma.png",
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1e3)
        }
      ]);
      setOutgoingRequests([
        {
          id: "5",
          username: "david_code",
          avatar_url: "/avatars/david.png",
          createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1e3)
        }
      ]);
    } catch (error) {
      console.error("Error fetching friends data:", error);
      toast({
        title: "Error",
        description: "Failed to load friends list. Please try again.",
        variant: "destructive"
      });
    }
  };
  const searchUsers = async () => {
    if (!searchUsername.trim()) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    try {
      setTimeout(() => {
        setSearchResults([
          {
            id: "6",
            username: `${searchUsername}_matched`,
            avatar_url: "/avatars/user1.png"
          },
          {
            id: "7",
            username: `user_${searchUsername}`,
            avatar_url: "/avatars/user2.png"
          }
        ]);
        setIsSearching(false);
      }, 500);
    } catch (error) {
      console.error("Error searching users:", error);
      toast({
        title: "Search Error",
        description: "Failed to search for users. Please try again.",
        variant: "destructive"
      });
      setIsSearching(false);
    }
  };
  const sendFriendRequest = async (userId) => {
    try {
      const user = searchResults.find((user2) => user2.id === userId);
      setOutgoingRequests((prev) => [...prev, {
        id: user.id,
        username: user.username,
        avatar_url: user.avatar_url,
        createdAt: /* @__PURE__ */ new Date()
      }]);
      setSearchResults((prev) => prev.filter((user2) => user2.id !== userId));
      toast({
        title: "Friend Request Sent",
        description: `Friend request sent to ${user.username}`
      });
    } catch (error) {
      console.error("Error sending friend request:", error);
      toast({
        title: "Error",
        description: "Failed to send friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const acceptFriendRequest = async (requestId) => {
    try {
      const request = incomingRequests.find((req) => req.id === requestId);
      setFriends((prev) => [...prev, {
        id: request.id,
        username: request.username,
        avatar_url: request.avatar_url,
        status: "offline",
        lastActive: /* @__PURE__ */ new Date()
      }]);
      setIncomingRequests((prev) => prev.filter((req) => req.id !== requestId));
      toast({
        title: "Friend Request Accepted",
        description: `You are now friends with ${request.username}`
      });
    } catch (error) {
      console.error("Error accepting friend request:", error);
      toast({
        title: "Error",
        description: "Failed to accept friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const rejectFriendRequest = async (requestId) => {
    try {
      const request = incomingRequests.find((req) => req.id === requestId);
      setIncomingRequests((prev) => prev.filter((req) => req.id !== requestId));
      toast({
        title: "Friend Request Rejected",
        description: `Rejected friend request from ${request.username}`
      });
    } catch (error) {
      console.error("Error rejecting friend request:", error);
      toast({
        title: "Error",
        description: "Failed to reject friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const cancelFriendRequest = async (requestId) => {
    try {
      const request = outgoingRequests.find((req) => req.id === requestId);
      setOutgoingRequests((prev) => prev.filter((req) => req.id !== requestId));
      toast({
        title: "Request Cancelled",
        description: `Cancelled friend request to ${request.username}`
      });
    } catch (error) {
      console.error("Error cancelling friend request:", error);
      toast({
        title: "Error",
        description: "Failed to cancel friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const removeFriend = async (friendId) => {
    try {
      const friend = friends.find((f) => f.id === friendId);
      setFriends((prev) => prev.filter((f) => f.id !== friendId));
      toast({
        title: "Friend Removed",
        description: `${friend.username} has been removed from your friends`
      });
    } catch (error) {
      console.error("Error removing friend:", error);
      toast({
        title: "Error",
        description: "Failed to remove friend. Please try again.",
        variant: "destructive"
      });
    }
  };
  const formatTimeAgo = (date) => {
    const now = /* @__PURE__ */ new Date();
    const past = new Date(date);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / (60 * 1e3));
    const diffHours = Math.floor(diffMs / (60 * 60 * 1e3));
    const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1e3));
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "online":
        return "bg-green-500";
      case "away":
        return "bg-yellow-500";
      case "dnd":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold text-cybergold-200", children: "Friends" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "outline",
          size: "sm",
          className: "flex items-center gap-1",
          onClick: () => setIsAddFriendDialogOpen(true),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { defaultValue: "all", className: "w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid grid-cols-3 mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "all", children: [
          "All",
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "ml-2", children: friends.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "online", children: [
          "Online",
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "ml-2", children: friends.filter((f) => f.status === "online").length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "pending", children: [
          "Pending",
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "ml-2", children: incomingRequests.length + outgoingRequests.length })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "all", className: "space-y-4", children: friends.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-6 text-sm text-cybergold-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Your friends list is empty" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Add friends to start chatting" })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[400px] pr-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: friends.map((friend) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "flex items-center justify-between rounded-md p-2 hover:bg-cyberdark-800/50 transition-colors",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UserAvatar,
                  {
                    src: friend.avatar_url,
                    alt: friend.username,
                    className: "h-10 w-10"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${getStatusColor(friend.status)}`
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-cybergold-200", children: friend.username }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-500", children: friend.status === "online" ? "Online" : `Last seen ${formatTimeAgo(friend.lastActive)}` })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", className: "h-8 px-2", children: "Message" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  variant: "ghost",
                  size: "icon",
                  className: "h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-900/20",
                  onClick: () => removeFriend(friend.id),
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserRoundX, { className: "h-4 w-4" })
                }
              )
            ] })
          ]
        },
        friend.id
      )) }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "online", className: "space-y-4", children: friends.filter((f) => f.status === "online").length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-6 text-sm text-cybergold-500", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No friends are currently online" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[400px] pr-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: friends.filter((f) => f.status === "online").map((friend) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "flex items-center justify-between rounded-md p-2 hover:bg-cyberdark-800/50 transition-colors",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UserAvatar,
                  {
                    src: friend.avatar_url,
                    alt: friend.username,
                    className: "h-10 w-10"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: "absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background bg-green-500"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-cybergold-200", children: friend.username }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-cybergold-500", children: "Online" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", className: "h-8 px-2", children: "Message" })
          ]
        },
        friend.id
      )) }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "pending", className: "space-y-6", children: incomingRequests.length === 0 && outgoingRequests.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-6 text-sm text-cybergold-500", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No pending friend requests" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        incomingRequests.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-cybergold-300", children: "Incoming Requests" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[150px] pr-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: incomingRequests.map((request) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "flex items-center justify-between rounded-md p-2 bg-cyberdark-800/30",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    UserAvatar,
                    {
                      src: request.avatar_url,
                      alt: request.username,
                      className: "h-10 w-10"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-cybergold-200", children: request.username }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-cybergold-500", children: [
                      "Requested ",
                      formatTimeAgo(request.createdAt)
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Button,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-8 w-8 text-green-400 hover:text-green-300 hover:bg-green-900/20",
                      onClick: () => acceptFriendRequest(request.id),
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Button,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-900/20",
                      onClick: () => rejectFriendRequest(request.id),
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
                    }
                  )
                ] })
              ]
            },
            request.id
          )) }) })
        ] }),
        outgoingRequests.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-cybergold-300", children: "Outgoing Requests" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[150px] pr-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: outgoingRequests.map((request) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "flex items-center justify-between rounded-md p-2 bg-cyberdark-800/30",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    UserAvatar,
                    {
                      src: request.avatar_url,
                      alt: request.username,
                      className: "h-10 w-10"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-cybergold-200", children: request.username }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-cybergold-500", children: [
                      "Sent ",
                      formatTimeAgo(request.createdAt)
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Button,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-8 w-8 text-gray-400 hover:text-gray-300",
                      onClick: () => cancelFriendRequest(request.id),
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    Button,
                    {
                      variant: "ghost",
                      size: "sm",
                      className: "h-8 px-2 flex items-center gap-1",
                      disabled: true,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3 w-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pending" })
                      ]
                    }
                  )
                ] })
              ]
            },
            request.id
          )) }) })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: isAddFriendDialogOpen, onOpenChange: setIsAddFriendDialogOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Add Friend" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 py-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              placeholder: "Search by username",
              value: searchUsername,
              onChange: (e) => setSearchUsername(e.target.value),
              onKeyDown: (e) => {
                if (e.key === "Enter") searchUsers();
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "default",
              onClick: searchUsers,
              disabled: isSearching,
              children: isSearching ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "animate-pulse", children: "Searching..." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-4 w-4 mr-1" }),
                "Search"
              ] })
            }
          )
        ] }),
        searchResults.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[200px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: searchResults.map((user) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "flex items-center justify-between p-2 rounded-md hover:bg-cyberdark-800/50",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UserAvatar,
                  {
                    src: user.avatar_url,
                    alt: user.username,
                    className: "h-10 w-10"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: user.username })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  variant: "outline",
                  size: "sm",
                  onClick: () => sendFriendRequest(user.id),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 mr-1" }),
                    "Send Request"
                  ]
                }
              )
            ]
          },
          user.id
        )) }) }) : searchUsername && !isSearching ? /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-center text-sm text-cybergold-500 py-6", children: [
          "No users found matching '",
          searchUsername,
          "'"
        ] }) : null
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setIsAddFriendDialogOpen(false), children: "Close" }) })
    ] }) })
  ] });
};
const FriendSearch = ({
  searchUsername,
  setSearchUsername,
  onSearch,
  searchResults,
  onSendFriendRequest
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: searchUsername,
            onChange: (e) => setSearchUsername(e.target.value),
            placeholder: "Søk etter brukernavn",
            className: "w-full px-3 py-2 bg-cyberdark-800 border border-cybergold-500/30 rounded-md text-cybergold-200 placeholder:text-cyberdark-400"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute right-3 top-2.5 h-4 w-4 text-cyberdark-400" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          onClick: onSearch,
          variant: "outline",
          className: "border-cybergold-500/30 text-cybergold-400 hover:bg-cybergold-500/10",
          children: "Søk"
        }
      )
    ] }),
    searchResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute z-10 w-full mt-1 bg-cyberdark-800 border border-cybergold-500/30 rounded-md shadow-lg", children: searchResults.map((user) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "flex items-center justify-between p-2 hover:bg-cyberdark-700",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-200", children: user.username || user.full_name || "Ukjent bruker" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              onClick: () => onSendFriendRequest(user.id),
              size: "sm",
              variant: "outline",
              className: "border-cybergold-500/30 text-cybergold-400 hover:bg-cybergold-500/10",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-4 h-4" })
            }
          )
        ]
      },
      user.id
    )) })
  ] });
};
const FriendsSearchSection = ({
  currentUserId,
  onSendFriendRequest,
  existingFriends = []
}) => {
  const [searchUsername, setSearchUsername] = reactExports.useState("");
  const [searchResults, setSearchResults] = reactExports.useState([]);
  const { toast } = useToast$1();
  const handleSearch = async () => {
    if (!searchUsername.trim()) {
      setSearchResults([]);
      return;
    }
    try {
      const { data, error } = await supabase.from("profiles").select("id, username, full_name").ilike("username", `%${searchUsername}%`).limit(5);
      if (error) throw error;
      const filteredResults = (data == null ? void 0 : data.filter(
        (profile) => profile.id !== currentUserId && !existingFriends.includes(profile.id)
      )) || [];
      setSearchResults(filteredResults);
    } catch (error) {
      console.error("Error searching users:", error);
      toast({
        title: "Søkefeil",
        description: "Kunne ikke søke etter brukere",
        variant: "destructive"
      });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    FriendSearch,
    {
      searchUsername,
      setSearchUsername,
      onSearch: handleSearch,
      searchResults,
      onSendFriendRequest
    }
  );
};
const EnhancedFriendRequestHandler = ({
  currentUserId,
  onRequestAccepted,
  onRequestRejected,
  onRequestCancelled
}) => {
  dist.useSupabaseClient();
  const { toast } = useToast();
  const [incomingRequests, setIncomingRequests] = reactExports.useState([]);
  const [outgoingRequests, setOutgoingRequests] = reactExports.useState([]);
  const [isLoading, setIsLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    if (currentUserId) {
      fetchFriendRequests();
    }
  }, [currentUserId]);
  const fetchFriendRequests = async () => {
    setIsLoading(true);
    try {
      const incomingResponse = {
        data: [
          {
            id: "req_in1",
            sender_id: "user1",
            recipient_id: currentUserId,
            status: "pending",
            created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1e3).toISOString(),
            sender: {
              id: "user1",
              username: "emma_newuser",
              avatar_url: "/avatars/emma.png"
            }
          },
          {
            id: "req_in2",
            sender_id: "user2",
            recipient_id: currentUserId,
            status: "pending",
            created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1e3).toISOString(),
            sender: {
              id: "user2",
              username: "jake_smith",
              avatar_url: "/avatars/jake.png"
            }
          }
        ],
        error: null
      };
      const outgoingResponse = {
        data: [
          {
            id: "req_out1",
            sender_id: currentUserId,
            recipient_id: "user3",
            status: "pending",
            created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1e3).toISOString(),
            recipient: {
              id: "user3",
              username: "david_code",
              avatar_url: "/avatars/david.png"
            }
          }
        ],
        error: null
      };
      if (incomingResponse.error) ;
      if (outgoingResponse.error) ;
      setIncomingRequests(incomingResponse.data);
      setOutgoingRequests(outgoingResponse.data);
    } catch (error) {
      console.error("Error fetching friend requests:", error);
      toast({
        title: "Error",
        description: "Failed to load friend requests. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  const acceptFriendRequest = async (requestId, senderId) => {
    try {
      setIncomingRequests((prev) => prev.filter((req) => req.id !== requestId));
      toast({
        title: "Request Accepted",
        description: "Friend request accepted successfully!"
      });
      if (onRequestAccepted) {
        onRequestAccepted(senderId);
      }
    } catch (error) {
      console.error("Error accepting friend request:", error);
      toast({
        title: "Error",
        description: "Failed to accept friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const rejectFriendRequest = async (requestId, senderId) => {
    try {
      setIncomingRequests((prev) => prev.filter((req) => req.id !== requestId));
      toast({
        title: "Request Rejected",
        description: "Friend request rejected."
      });
      if (onRequestRejected) {
        onRequestRejected(senderId);
      }
    } catch (error) {
      console.error("Error rejecting friend request:", error);
      toast({
        title: "Error",
        description: "Failed to reject friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const cancelFriendRequest = async (requestId, recipientId) => {
    try {
      setOutgoingRequests((prev) => prev.filter((req) => req.id !== requestId));
      toast({
        title: "Request Cancelled",
        description: "Friend request cancelled."
      });
      if (onRequestCancelled) {
        onRequestCancelled(recipientId);
      }
    } catch (error) {
      console.error("Error cancelling friend request:", error);
      toast({
        title: "Error",
        description: "Failed to cancel friend request. Please try again.",
        variant: "destructive"
      });
    }
  };
  const formatTimeAgo = (dateString) => {
    const now = /* @__PURE__ */ new Date();
    const past = new Date(dateString);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / (60 * 1e3));
    const diffHours = Math.floor(diffMs / (60 * 60 * 1e3));
    const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1e3));
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-4", children: "Loading requests..." });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 text-cybergold-200" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-cybergold-100", children: "Incoming Requests" }),
        incomingRequests.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "default", className: "bg-cybergold-500 text-black", children: incomingRequests.length })
      ] }),
      incomingRequests.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground p-2", children: "No incoming friend requests" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[150px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: incomingRequests.map((request) => {
        var _a, _b, _c, _d;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "flex items-center justify-between p-2 rounded-md bg-background/50 hover:bg-background/70",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UserAvatar,
                  {
                    src: (_a = request.sender) == null ? void 0 : _a.avatar_url,
                    fallback: ((_c = (_b = request.sender) == null ? void 0 : _b.username) == null ? void 0 : _c[0]) || "?",
                    className: "h-8 w-8"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: (_d = request.sender) == null ? void 0 : _d.username }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: formatTimeAgo(request.created_at) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    variant: "ghost",
                    size: "icon",
                    className: "h-7 w-7 text-green-500 hover:text-green-600 hover:bg-green-200/10",
                    onClick: () => acceptFriendRequest(request.id, request.sender_id),
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    variant: "ghost",
                    size: "icon",
                    className: "h-7 w-7 text-red-500 hover:text-red-600 hover:bg-red-200/10",
                    onClick: () => rejectFriendRequest(request.id, request.sender_id),
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
                  }
                )
              ] })
            ]
          },
          request.id
        );
      }) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4 text-cybergold-200" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-cybergold-100", children: "Pending Sent" }),
        outgoingRequests.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "text-cybergold-200 border-cybergold-200", children: outgoingRequests.length })
      ] }),
      outgoingRequests.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground p-2", children: "No pending sent requests" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "h-[100px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: outgoingRequests.map((request) => {
        var _a, _b, _c, _d;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "flex items-center justify-between p-2 rounded-md bg-background/50 hover:bg-background/70",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UserAvatar,
                  {
                    src: (_a = request.recipient) == null ? void 0 : _a.avatar_url,
                    fallback: ((_c = (_b = request.recipient) == null ? void 0 : _b.username) == null ? void 0 : _c[0]) || "?",
                    className: "h-8 w-8"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: (_d = request.recipient) == null ? void 0 : _d.username }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: formatTimeAgo(request.created_at) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  variant: "ghost",
                  size: "icon",
                  className: "h-7 w-7 text-amber-500 hover:text-amber-600 hover:bg-amber-200/10",
                  onClick: () => cancelFriendRequest(request.id, request.recipient_id),
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserRoundX, { className: "h-4 w-4" })
                }
              )
            ]
          },
          request.id
        );
      }) }) })
    ] })
  ] });
};
const Profile = reactExports.lazy(() => __vitePreload(() => import("./pages-main-MXMMLxmC.js").then((n) => n.P), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]) : void 0));
const ProfileLoadingSkeleton = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-16 w-full bg-cyberdark-800" }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "mb-6 bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "pb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { className: "h-20 w-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarFallback, { className: "bg-cyberdark-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-8 w-8 text-cybergold-400" }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 flex-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-48 bg-cyberdark-700" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-32 bg-cyberdark-700" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-16 bg-cyberdark-700 rounded-full" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-5 w-5 text-cybergold-400" })
      ] })
    ] })
  ] }) }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-1 bg-cyberdark-900 p-1 rounded-lg border border-cyberdark-700", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-24 bg-cyberdark-700 rounded-md" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-28 bg-cyberdark-800 rounded-md" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-20 bg-cyberdark-800 rounded-md" })
  ] }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-20 bg-cyberdark-700" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cyberdark-800" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-16 bg-cyberdark-700" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cyberdark-800" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-12 bg-cyberdark-700" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-24 w-full bg-cyberdark-800" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-3 pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-24 bg-cybergold-600/20" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-20 bg-cyberdark-700" })
    ] })
  ] }) }) })
] }) });
const DynamicProfile = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ProfileLoadingSkeleton, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Profile, {}) });
};
const DynamicProfile$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DynamicProfile,
  default: DynamicProfile
}, Symbol.toStringTag, { value: "Module" }));
const SettingsComponent = reactExports.lazy(() => __vitePreload(() => import("./pages-main-MXMMLxmC.js").then((n) => n.b), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]) : void 0));
const SettingsLoadingSkeleton = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-16 w-full bg-cyberdark-800" }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3 mb-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "h-8 w-8 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-32 bg-cyberdark-700" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-64 bg-cyberdark-700" })
  ] }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-1 bg-cyberdark-900 p-1 rounded-lg border border-cyberdark-700", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 px-3 py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-16 bg-cyberdark-700" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 px-3 py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-20 bg-cyberdark-800" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 px-3 py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-4 w-4 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-24 bg-cyberdark-800" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 px-3 py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "h-4 w-4 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-12 bg-cyberdark-800" })
    ] })
  ] }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-32 bg-cyberdark-700" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-20 bg-cyberdark-700" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cyberdark-800" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-16 bg-cyberdark-700" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cyberdark-800" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center py-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-24 bg-cyberdark-700" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-48 bg-cyberdark-800" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-12 bg-cyberdark-700 rounded-full" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-5 w-5 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-28 bg-cyberdark-700" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "space-y-4", children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center py-3 border-b border-cyberdark-700 last:border-b-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-32 bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-56 bg-cyberdark-800" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-12 bg-cyberdark-700 rounded-full" })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-5 w-5 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-28 bg-cyberdark-700" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "space-y-4", children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center py-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-28 bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-40 bg-cyberdark-800" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-12 bg-cyberdark-700 rounded-full" })
      ] }, i)) })
    ] })
  ] }),
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex justify-end space-x-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-20 bg-cyberdark-700" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-32 bg-cybergold-600/20" })
  ] })
] }) });
const DynamicSettings = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(SettingsLoadingSkeleton, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsx(SettingsComponent, {}) });
};
const DynamicSettings$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DynamicSettings,
  default: DynamicSettings
}, Symbol.toStringTag, { value: "Module" }));
const Mail = reactExports.lazy(() => __vitePreload(() => import("./pages-main-MXMMLxmC.js").then((n) => n.c), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]) : void 0));
const MailLoadingSkeleton = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-screen", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-64 bg-cyberdark-900 border-r border-cyberdark-700 p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2 mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-6 w-6 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-20 bg-cyberdark-700" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cybergold-600/20 rounded-md" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: [
      { icon: Inbox, label: "Innboks" },
      { icon: Send, label: "Sendt" },
      { icon: Archive, label: "Arkiv" },
      { icon: Star, label: "Stjernert" }
    ].map((item, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3 p-2 rounded-md bg-cyberdark-800", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(item.icon, { className: "h-4 w-4 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-16 bg-cyberdark-700" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-6 bg-cyberdark-700 ml-auto rounded-full" })
    ] }, i)) })
  ] }),
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-b border-cyberdark-700 bg-cyberdark-900", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-32 bg-cyberdark-700" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-8 bg-cyberdark-700 rounded" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-8 bg-cyberdark-700 rounded" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-8 bg-cyberdark-700 rounded" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-cybergold-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cyberdark-800 pl-10" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700 hover:bg-cyberdark-800/50 transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-10 bg-cyberdark-700 rounded-full" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-32 bg-cyberdark-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-16 bg-cyberdark-800" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-48 bg-cyberdark-700" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-3/4 bg-cyberdark-800" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "h-4 w-4 text-cyberdark-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-4 bg-cyberdark-700 rounded" })
      ] })
    ] }) }) }, i)) }) })
  ] })
] }) });
const DynamicMail = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(MailLoadingSkeleton, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, {}) });
};
const DynamicMail$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DynamicMail,
  default: DynamicMail
}, Symbol.toStringTag, { value: "Module" }));
const MemoryDashboard = reactExports.lazy(() => __vitePreload(() => import("./pages-main-MXMMLxmC.js").then((n) => n.d), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]) : void 0));
const MemoryDashboardLoadingSkeleton = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-cyberdark-950 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-16 w-full bg-cyberdark-800" }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "h-10 w-10 text-cybergold-400" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-48 bg-cyberdark-700" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-72 bg-cyberdark-800" })
    ] })
  ] }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8", children: [
    { icon: Database, label: "Total Memories" },
    { icon: Star, label: "Favorites" },
    { icon: Clock, label: "Recent" },
    { icon: ChartColumn, label: "Analytics" }
  ].map((item, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(item.icon, { className: "h-8 w-8 text-cybergold-400" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-6 w-12 bg-cyberdark-700" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-16 bg-cyberdark-800" })
    ] })
  ] }) }) }, i)) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-1 bg-cyberdark-900 p-1 rounded-lg border border-cyberdark-700", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-24 bg-cyberdark-700 rounded-md" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-20 bg-cyberdark-800 rounded-md" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-28 bg-cyberdark-800 rounded-md" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-24 bg-cyberdark-800 rounded-md" })
  ] }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row gap-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-full bg-cyberdark-800 pl-10" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-24 bg-cyberdark-800" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-10 w-20 bg-cyberdark-800" })
    ] })
  ] }) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4", children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-900 border-cyberdark-700", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "pb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-5 w-3/4 bg-cyberdark-700" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-16 bg-cyberdark-800 rounded-full" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-20 bg-cyberdark-800 rounded-full" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-8 bg-cyberdark-700 rounded" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-8 w-8 bg-cyberdark-700 rounded" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "pt-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-full bg-cyberdark-800" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-5/6 bg-cyberdark-800" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-4 w-4/6 bg-cyberdark-800" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mt-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-24 bg-cyberdark-800" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-3 w-16 bg-cyberdark-800" })
      ] })
    ] })
  ] }, i)) }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-6 right-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { className: "h-14 w-14 bg-cybergold-600/20 rounded-full" }) })
] }) });
const DynamicMemoryDashboard = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(MemoryDashboardLoadingSkeleton, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsx(MemoryDashboard, {}) });
};
const DynamicMemoryDashboard$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DynamicMemoryDashboard,
  default: DynamicMemoryDashboard
}, Symbol.toStringTag, { value: "Module" }));
function BitcoinPayment({
  amount,
  productId,
  productType,
  onSuccess,
  onError
}) {
  const { toast } = useToast();
  const [loading, setLoading] = reactExports.useState(false);
  const [paymentData, setPaymentData] = reactExports.useState(null);
  const [timeLeft, setTimeLeft] = reactExports.useState(null);
  const [statusChecking, setStatusChecking] = reactExports.useState(false);
  reactExports.useEffect(() => {
    createPaymentRequest();
  }, []);
  reactExports.useEffect(() => {
    if (!(paymentData == null ? void 0 : paymentData.expires_at)) return;
    const calculateTimeLeft = () => {
      const expiresAt = new Date(paymentData.expires_at).getTime();
      const now = (/* @__PURE__ */ new Date()).getTime();
      const difference = expiresAt - now;
      if (difference <= 0) {
        return 0;
      }
      return Math.floor(difference / 1e3);
    };
    setTimeLeft(calculateTimeLeft());
    const timer = setInterval(() => {
      const newTimeLeft = calculateTimeLeft();
      setTimeLeft(newTimeLeft);
      if (newTimeLeft <= 0) {
        clearInterval(timer);
      }
    }, 1e3);
    return () => clearInterval(timer);
  }, [paymentData == null ? void 0 : paymentData.expires_at]);
  reactExports.useEffect(() => {
    if (!(paymentData == null ? void 0 : paymentData.id)) return;
    const subscription = supabase.channel(`payment-${paymentData.id}`).on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "payments",
        filter: `id=eq.${paymentData.id}`
      },
      (payload) => {
        const updatedPayment = payload.new;
        setPaymentData(updatedPayment);
        if (updatedPayment.status === "confirmed" || updatedPayment.status === "completed") {
          toast({
            title: "Payment confirmed!",
            description: "Your Bitcoin payment has been confirmed."
          });
          handlePaymentSuccess();
        } else if (updatedPayment.status === "failed") {
          toast({
            variant: "destructive",
            title: "Payment failed",
            description: "Your Bitcoin payment has failed."
          });
        }
      }
    ).subscribe();
    const statusCheckInterval = setInterval(() => {
      checkPaymentStatus();
    }, 3e4);
    return () => {
      supabase.removeChannel(subscription);
      clearInterval(statusCheckInterval);
    };
  }, [paymentData == null ? void 0 : paymentData.id]);
  const createPaymentRequest = async () => {
    try {
      setLoading(true);
      const response = await axios.post("/api/payments", {
        amount,
        currency: "NOK",
        productType,
        productId
      });
      if (response.data.success && response.data.payment) {
        setPaymentData(response.data.payment);
      } else {
        throw new Error("Failed to create payment request");
      }
    } catch (error) {
      console.error("Payment creation error:", error);
      onError(error instanceof Error ? error.message : "Failed to create payment request");
    } finally {
      setLoading(false);
    }
  };
  const checkPaymentStatus = async () => {
    if (!(paymentData == null ? void 0 : paymentData.id) || paymentData.status !== "pending") return;
    try {
      setStatusChecking(true);
      const response = await axios.get(`/api/payments/${paymentData.id}`);
      if (response.data.success && response.data.payment) {
        setPaymentData(response.data.payment);
        if (["confirmed", "completed"].includes(response.data.payment.status)) {
          handlePaymentSuccess();
        }
      }
    } catch (error) {
      console.error("Error checking payment status:", error);
    } finally {
      setStatusChecking(false);
    }
  };
  const handlePaymentSuccess = async () => {
    try {
      await onSuccess();
    } catch (error) {
      console.error("Error in onSuccess callback:", error);
    }
  };
  const formatTimeLeft = (seconds) => {
    if (seconds === null || seconds <= 0) return "00:00:00";
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor(seconds % 3600 / 60);
    const remainingSeconds = seconds % 60;
    return [
      hours.toString().padStart(2, "0"),
      minutes.toString().padStart(2, "0"),
      remainingSeconds.toString().padStart(2, "0")
    ].join(":");
  };
  const copyAddressToClipboard = () => {
    if (!(paymentData == null ? void 0 : paymentData.bitcoin_address)) return;
    navigator.clipboard.writeText(paymentData.bitcoin_address).then(() => {
      toast({
        title: "Address copied",
        description: "Bitcoin address copied to clipboard"
      });
    }).catch((err) => {
      console.error("Failed to copy address:", err);
    });
  };
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 p-4 flex flex-col items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-12 w-12 animate-spin text-cybergold-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center text-sm", children: "Creating your Bitcoin payment..." })
    ] });
  }
  if (paymentData && ["confirmed", "completed"].includes(paymentData.status)) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 p-4 border border-green-600/30 rounded-lg bg-green-900/20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-3 mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-8 w-8 text-green-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-medium text-green-400", children: "Payment Successful" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2", children: "Your payment has been confirmed." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-gray-400", children: [
          "Transaction ID: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono text-xs", children: [
            paymentData.id.substring(0, 8),
            "..."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 p-3 bg-green-900/30 rounded-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-gray-300", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-green-300", children: "Visste du?" }),
        " Snakkaz Chat tilbyr også integrering med Electrum Bitcoin Wallet. Som premium bruker, kan du opprette og administrere din Bitcoin-lommebok direkte i appen."
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          className: "w-full bg-green-700 hover:bg-green-600 text-white",
          onClick: () => onSuccess(),
          children: "Continue"
        }
      )
    ] });
  }
  if (paymentData && timeLeft === 0) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 p-4 border border-red-600/30 rounded-lg bg-red-900/20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-3 mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-8 w-8 text-red-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-medium text-red-400", children: "Payment Expired" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2", children: "This payment request has expired." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400", children: "Please create a new payment request to continue." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          className: "w-full bg-cybergold-600 hover:bg-cybergold-500 text-black",
          onClick: createPaymentRequest,
          children: "Create New Payment"
        }
      )
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border border-cyberdark-700 rounded-lg bg-cyberdark-800", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-cybergold-400", children: "Amount" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-lg font-semibold text-cybergold-200", children: [
          amount,
          " kr"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-cybergold-400", children: "Product" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-cybergold-300", children: productType || "Premium Membership" })
      ] }),
      paymentData && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-center text-cybergold-500 mb-1", children: [
            "Time remaining: ",
            formatTimeLeft(timeLeft)
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full bg-cyberdark-700 h-2 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "h-full bg-cybergold-500",
              style: {
                width: `${timeLeft && timeLeft > 0 ? timeLeft / (24 * 60 * 60) * 100 : 0}%`
              }
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center rounded-md p-4 bg-cyberdark-700 mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white p-3 rounded-md", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            QRCodeSVG,
            {
              value: `bitcoin:${paymentData.bitcoin_address}?amount=${paymentData.btc_amount}`,
              size: 150
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-white mb-1", children: "Send exactly:" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-mono font-bold text-cybergold-400", children: [
              paymentData.btc_amount,
              " BTC"
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 bg-cyberdark-900 rounded-md font-mono text-xs break-all text-center text-gray-300", children: paymentData.bitcoin_address }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "ghost",
              size: "sm",
              className: "absolute right-1 top-1/2 -translate-y-1/2 h-7 px-2",
              onClick: copyAddressToClipboard,
              children: "Copy"
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Button,
      {
        onClick: checkPaymentStatus,
        className: "w-full bg-cyberdark-700 hover:bg-cyberdark-600",
        disabled: statusChecking || !paymentData || paymentData.status !== "pending",
        children: statusChecking ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
          "Checking..."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "mr-2 h-4 w-4" }),
          "Check Payment Status"
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-center text-gray-500 space-y-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Send the exact amount of Bitcoin to the address above." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "The payment will be automatically confirmed after transaction is detected." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Payment will expire in 24 hours if not completed." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 p-4 bg-cyberdark-900 border border-cyberdark-700 rounded-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-medium text-cybergold-400 mb-2 flex items-center justify-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-4 w-4 text-red-400" }),
        "Din støtte betyr mye for oss"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 text-xs text-gray-300", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Ved å bli premium bruker støtter du Snakkaz Chat med å:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 shrink-0 mt-0.5 text-cyberblue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Forbedre sikkerheten og personvernet for alle brukere" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Code, { className: "h-4 w-4 shrink-0 mt-0.5 text-cyberblue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Utvikle nye funksjoner og forbedringer av plattformen" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bitcoin, { className: "h-4 w-4 shrink-0 mt-0.5 text-cybergold-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Holde tjenesten uavhengig og reklamefri" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "pt-2", children: [
          "Vi tar også gjerne imot donasjoner for å støtte videre utvikling. For donasjoner, send valgfritt beløp til vår Bitcoin-adresse: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-cybergold-400 font-mono", children: "bc1qz7q6hxlevr8y9kgff2p6m2c9t95x85h2knz0wz" })
        ] })
      ] })
    ] })
  ] });
}
const SubscriptionTiers = () => {
  const [plans, setPlans] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [selectedPlan, setSelectedPlan] = reactExports.useState(null);
  const [paymentOpen, setPaymentOpen] = reactExports.useState(false);
  const { user, subscription, refreshSubscription, isPremium } = useAuth();
  const { toast } = useToast();
  reactExports.useEffect(() => {
    const fetchPlans = async () => {
      try {
        const plansData = await subscriptionService.getSubscriptionPlans();
        setPlans(plansData);
      } catch (error) {
        console.error("Failed to load subscription plans", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPlans();
  }, []);
  const handleSelectPlan = (plan) => {
    setSelectedPlan(plan);
    setPaymentOpen(true);
  };
  const handleSupportSuccess = async () => {
    if (!user || !selectedPlan) return;
    try {
      await subscriptionService.createSubscription(user.id, selectedPlan.id);
      await refreshSubscription();
      toast({
        title: "Takk for din støtte!",
        description: `Du støtter nå fellesskapet med ${selectedPlan.name}!`,
        variant: "default"
      });
      setPaymentOpen(false);
    } catch (error) {
      console.error("Failed to create subscription", error);
      toast({
        title: "Støtte Error",
        description: "Kunne ikke aktivere din støtte. Prøv igjen.",
        variant: "destructive"
      });
    }
  };
  const handleSupportError = (errorMessage) => {
    toast({
      title: "Støtte mislyktes",
      description: errorMessage,
      variant: "destructive"
    });
  };
  const handleStartSupport = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const success = await subscriptionService.createTrialSubscription(user.id);
      if (success) {
        await refreshSubscription();
        toast({
          title: "Velkommen til fellesskapet!",
          description: "Du har nå tilgang til alle funksjonene våre!",
          variant: "default"
        });
      } else {
        throw new Error("Failed to start trial");
      }
    } catch (error) {
      console.error("Failed to start trial", error);
      toast({
        title: "Oppstart feilet",
        description: "Kunne ikke starte din tilgang. Prøv igjen.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-green-500" }) });
  }
  if (isPremium && subscription) {
    const expiryDate = subscription.current_period_end ? new Date(subscription.current_period_end).toLocaleDateString() : "Unknown";
    const currentPlan = plans.find((p) => p.id === subscription.plan_id);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-green-500 bg-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center justify-between", children: [
            "Aktiv fellesskapsstøtte",
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "bg-green-700 text-green-100", children: subscription.status === "trial" ? "GRATIS TILGANG" : "SUPPORTER" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardDescription, { children: [
            "Takk for at du støtter ",
            (currentPlan == null ? void 0 : currentPlan.name) || "SnakkaZ",
            " fellesskapet"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-400", children: "Støttenivå:" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: (currentPlan == null ? void 0 : currentPlan.name) || "Fellesskapsstøtte" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-400", children: "Status:" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: subscription.status === "trial" ? "Gratis tilgang" : "Aktiv støtte" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-400", children: "Fornyelse:" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: expiryDate })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-400", children: "Bidrag:" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium", children: [
              (currentPlan == null ? void 0 : currentPlan.price) || 0,
              " kr / måned"
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "destructive",
            className: "w-full",
            onClick: async () => {
              if (user) {
                await subscriptionService.cancelSubscription(user.id);
                await refreshSubscription();
                toast({
                  title: "Støtte avsluttet",
                  description: "Din støtte til fellesskapet er avsluttet."
                });
              }
            },
            children: "Avslutt støtte"
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-center text-green-500", children: [
        "Din støtte forblir aktiv til ",
        expiryDate,
        ". Takk for at du hjelper oss bygge et bedre fellesskap!"
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl font-bold tracking-tight text-green-100", children: "Støtt fellesskapet" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-green-400", children: "Valgfri støtte som hjelper oss bygge en bedre plattform for alle" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-6 md:grid-cols-2 lg:grid-cols-3", children: plans.map((plan) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Card,
      {
        className: `relative overflow-hidden transition-all border-green-500/20 hover:border-green-400/40 ${plan.highlighted ? "border-2 border-green-500 shadow-lg shadow-green-900/20" : ""}`,
        children: [
          plan.badge_text && /* @__PURE__ */ jsxRuntimeExports.jsx(
            Badge,
            {
              className: "absolute top-4 right-4 bg-green-600 text-xs font-semibold uppercase",
              children: plan.badge_text
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-green-200", children: plan.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-slate-400", children: plan.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-3xl font-bold text-green-300", children: [
                plan.price,
                " kr"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-green-400", children: [
                " / ",
                plan.interval
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: Object.entries(plan.features).map(([feature, enabled]) => {
            if (typeof enabled !== "boolean") return null;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center", children: [
              enabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4 mr-2 text-green-500" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4 mr-2 text-slate-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: !enabled ? "text-slate-600" : "text-slate-300", children: feature.split("_").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ") })
            ] }, feature);
          }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              className: "w-full bg-green-600 hover:bg-green-500 text-white",
              onClick: () => handleSelectPlan(plan),
              children: "Støtt med denne"
            }
          ) })
        ]
      },
      plan.id
    )) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-green-400 mb-4", children: "Vil du teste alle funksjonene først? Få gratis tilgang og se hva vi bygger sammen." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "outline",
          className: "border-green-600 text-green-400 hover:text-green-200 hover:bg-green-600/10",
          onClick: handleStartSupport,
          disabled: loading,
          children: [
            loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }) : null,
            "Få gratis tilgang"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: paymentOpen, onOpenChange: setPaymentOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Støtt fellesskapet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: selectedPlan ? `Støtt ${selectedPlan.name} med ${selectedPlan.price} kr per ${selectedPlan.interval}` : "" })
      ] }),
      selectedPlan && /* @__PURE__ */ jsxRuntimeExports.jsx(
        BitcoinPayment,
        {
          amount: selectedPlan.price,
          productId: selectedPlan.id,
          productType: selectedPlan.name,
          onSuccess: handleSupportSuccess,
          onError: handleSupportError
        }
      )
    ] }) })
  ] });
};
const SubscriptionPage = () => {
  const { isPremium, subscription } = useAuth();
  const [dbError, setDbError] = React.useState(false);
  React.useEffect(() => {
    const originalConsoleError = console.error;
    console.error = (...args) => {
      const errorMessage = args.join(" ");
      if (errorMessage.includes("PGRST200") && errorMessage.includes("subscription")) {
        setDbError(true);
      }
      originalConsoleError(...args);
    };
    return () => {
      console.error = originalConsoleError;
    };
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container py-10 max-w-6xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-bold tracking-tight text-cybergold-100", children: "Subscription Management" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-cybergold-400 mt-2", children: "Manage your subscription and access premium features" })
    ] }),
    dbError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-yellow-900/30 border border-yellow-800 rounded-md p-4 mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-5 w-5 text-yellow-500 mr-2" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-yellow-500 font-medium", children: "Database Setup Required" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-yellow-300/80 text-sm", children: [
        "The subscription tables are not properly set up in the database. Run ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "bg-black/30 px-1 py-0.5 rounded", children: "./fix-subscription-schema.sh" }),
        " to fix this issue."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          variant: "outline",
          className: "mt-3 border-yellow-800 bg-yellow-900/20 text-yellow-500 hover:bg-yellow-900/40",
          onClick: () => setDbError(false),
          children: "Dismiss"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { defaultValue: "subscription", className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "grid w-full max-w-md mx-auto grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "subscription", children: "Subscription" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "features", children: "Premium Features" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "subscription", className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SubscriptionTiers, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "features", className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-cyberdark-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center", children: [
            "Premium Features",
            isPremium ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 inline-flex items-center px-2 py-1 text-xs font-medium bg-cybergold-900/50 text-cybergold-400 rounded-full", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-3 w-3 mr-1" }),
              "Active"
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 inline-flex items-center px-2 py-1 text-xs font-medium bg-cyberdark-700 text-cybergold-600 rounded-full", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-3 w-3 mr-1" }),
              "Locked"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: isPremium ? "Enjoy all the premium features available with your subscription" : "Upgrade to premium to access these features" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "Extended Storage",
              description: "Store up to 50GB of files and media in your chats",
              featureKey: PremiumFeature.EXTENDED_STORAGE,
              unlocked: isPremium
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "End-to-End Encryption",
              description: "Enhanced security with end-to-end encryption for all your messages",
              featureKey: PremiumFeature.END_TO_END_ENCRYPTION,
              unlocked: isPremium
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "Premium Groups",
              description: "Create groups with up to 500 members and enhanced controls",
              featureKey: PremiumFeature.PREMIUM_GROUPS,
              unlocked: isPremium
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "Custom Email Domain",
              description: "Use your own email domain for Snakkaz communications",
              featureKey: PremiumFeature.CUSTOM_EMAIL,
              unlocked: isPremium
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "Priority Support",
              description: "Get priority customer support with 24/7 availability",
              featureKey: PremiumFeature.PRIORITY_SUPPORT,
              unlocked: isPremium
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "Custom Themes",
              description: "Access exclusive themes and customization options",
              featureKey: PremiumFeature.CUSTOM_THEMES,
              unlocked: isPremium
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            FeatureCard,
            {
              title: "API Access",
              description: "Access to the Snakkaz API for custom integrations",
              featureKey: PremiumFeature.API_ACCESS,
              unlocked: isPremium
            }
          ),
          !isPremium && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              className: "w-full bg-cybergold-600 hover:bg-cybergold-500 text-black",
              onClick: () => {
                const element = document.querySelector('[data-value="subscription"]');
                if (element instanceof HTMLElement) {
                  element.click();
                }
              },
              children: "Upgrade to Premium"
            }
          ) })
        ] })
      ] }) })
    ] })
  ] });
};
const FeatureCard = ({
  title,
  description,
  featureKey,
  unlocked
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-medium text-cybergold-200", children: title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-cybergold-400", children: description })
      ] }),
      unlocked ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-5 w-5 text-cybergold-500" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-5 w-5 text-cybergold-700" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "my-4 bg-cyberdark-700" })
  ] });
};
function CommunityEmailManager() {
  const { user, isPremium } = useAuth();
  const { toast } = useToast$1();
  const [emails, setEmails] = reactExports.useState([]);
  const [isLoadingEmails, setIsLoadingEmails] = reactExports.useState(false);
  const [newEmailUsername, setNewEmailUsername] = reactExports.useState("");
  const [newEmailPassword, setNewEmailPassword] = reactExports.useState("");
  const [newEmailQuota, setNewEmailQuota] = reactExports.useState(250);
  const [passwordStrengthLevel, setPasswordStrengthLevel] = reactExports.useState(0);
  const [newPasswordVisible, setNewPasswordVisible] = reactExports.useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = reactExports.useState(false);
  const [isCreatingEmail, setIsCreatingEmail] = reactExports.useState(false);
  const [isDeleting, setIsDeleting] = reactExports.useState(null);
  const [error, setError] = reactExports.useState(null);
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = reactExports.useState(false);
  const [resetUsername, setResetUsername] = reactExports.useState("");
  const [resetPassword, setResetPassword] = reactExports.useState("");
  const [isChangingPassword, setIsChangingPassword] = reactExports.useState(false);
  const [resetPasswordVisible, setResetPasswordVisible] = reactExports.useState(false);
  const [resetPasswordError, setResetPasswordError] = reactExports.useState(null);
  const [resetPasswordStrength, setResetPasswordStrength] = reactExports.useState(0);
  const strengthColors = ["bg-red-500", "bg-orange-500", "bg-yellow-500", "bg-green-500"];
  const strengthLabels = ["Svakt", "Middels", "Sterkt", "Svært sterkt"];
  reactExports.useEffect(() => {
    const fetchEmails = async () => {
      if (!user || !isPremium) return;
      setIsLoadingEmails(true);
      setError(null);
      try {
        const response = await fetch("/api/community/emails");
        const data = await response.json();
        if (data.success) {
          setEmails(data.emails || []);
        } else {
          setError(data.message || "Failed to load email accounts");
        }
      } catch (err) {
        setError("Could not connect to server");
        console.error("Error fetching emails:", err);
      } finally {
        setIsLoadingEmails(false);
      }
    };
    fetchEmails();
  }, [user, isPremium]);
  reactExports.useEffect(() => {
    if (newEmailPassword) {
      const strength = passwordStrength(newEmailPassword);
      setPasswordStrengthLevel(strength.id);
    } else {
      setPasswordStrengthLevel(0);
    }
  }, [newEmailPassword]);
  reactExports.useEffect(() => {
    if (resetPassword) {
      const strength = passwordStrength(resetPassword);
      setResetPasswordStrength(strength.id);
    } else {
      setResetPasswordStrength(0);
    }
  }, [resetPassword]);
  const handleCreateEmail = async (e) => {
    e.preventDefault();
    if (passwordStrengthLevel < 1) {
      toast({
        title: "Svakt passord",
        description: "Vennligst velg et sterkere passord",
        variant: "destructive"
      });
      return;
    }
    setIsCreatingEmail(true);
    setError(null);
    try {
      const response = await fetch("/api/community/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          username: newEmailUsername,
          password: newEmailPassword,
          quota: newEmailQuota
        })
      });
      const data = await response.json();
      if (data.success) {
        toast({
          title: "E-post opprettet",
          description: `${data.email} har blitt opprettet`,
          variant: "default"
        });
        setEmails((prev) => [...prev, data.email]);
        setNewEmailUsername("");
        setNewEmailPassword("");
        setIsCreateDialogOpen(false);
      } else {
        setError(data.message || "Kunne ikke opprette e-postkonto");
        toast({
          title: "Feil ved opprettelse",
          description: data.message || "Kunne ikke opprette e-postkonto",
          variant: "destructive"
        });
      }
    } catch (err) {
      setError("Kunne ikke koble til serveren");
      console.error("Error creating email:", err);
    } finally {
      setIsCreatingEmail(false);
    }
  };
  const handleDeleteEmail = async (username) => {
    if (!confirm(`Er du sikker på at du vil slette ${username}@snakkaz.com?`)) {
      return;
    }
    setIsDeleting(username);
    try {
      const response = await fetch(`/api/community/emails/${username}`, {
        method: "DELETE"
      });
      const data = await response.json();
      if (data.success) {
        toast({
          title: "E-post slettet",
          description: `${username}@snakkaz.com har blitt slettet`,
          variant: "default"
        });
        setEmails((prev) => prev.filter((email) => email.email_username !== username));
      } else {
        toast({
          title: "Feil ved sletting",
          description: data.message || "Kunne ikke slette e-postkonto",
          variant: "destructive"
        });
      }
    } catch (err) {
      console.error("Error deleting email:", err);
      toast({
        title: "Feil ved sletting",
        description: "Kunne ikke koble til serveren",
        variant: "destructive"
      });
    } finally {
      setIsDeleting(null);
    }
  };
  const handleResetPassword = async (username) => {
    setResetUsername(username);
    setResetPassword("");
    setResetPasswordError(null);
    setResetPasswordStrength(0);
    setIsResetPasswordDialogOpen(true);
  };
  const handleSubmitPasswordReset = async (e) => {
    e.preventDefault();
    if (resetPasswordStrength < 1) {
      toast({
        title: "Svakt passord",
        description: "Vennligst velg et sterkere passord",
        variant: "destructive"
      });
      return;
    }
    setIsChangingPassword(true);
    setResetPasswordError(null);
    try {
      const response = await fetch(`/api/community/emails/${resetUsername}/password`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          password: resetPassword
        })
      });
      const data = await response.json();
      if (data.success) {
        toast({
          title: "Passord endret",
          description: `Passordet for ${resetUsername}@snakkaz.com har blitt endret`,
          variant: "default"
        });
        setIsResetPasswordDialogOpen(false);
        setResetPassword("");
      } else {
        setResetPasswordError(data.message || "Kunne ikke endre passord");
        toast({
          title: "Feil ved passordendring",
          description: data.message || "Kunne ikke endre passord",
          variant: "destructive"
        });
      }
    } catch (err) {
      setResetPasswordError("Kunne ikke koble til serveren");
      console.error("Error changing password:", err);
      toast({
        title: "Feil ved passordendring",
        description: "Kunne ikke koble til serveren",
        variant: "destructive"
      });
    } finally {
      setIsChangingPassword(false);
    }
  };
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Kopiert",
      description: `${text} kopiert til utklippstavlen`,
      variant: "default"
    });
  };
  const isLoading = isLoadingEmails || !user;
  if (!isPremium && !isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "w-full max-w-2xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { children: "Fellesskap E-post" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Støtt felleskapet for å få din egen @snakkaz.com e-postadresse" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-8 space-y-4 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$1, { size: 64, className: "text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: "Få din egen @snakkaz.com e-postadresse" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Som en del av vårt fellesskap kan du opprette din egen e-postadresse og bruke den med hvilken som helst e-postklient. Dette bidrar til å støtte plattformen." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "default", size: "lg", children: "Støtt Felleskapet" })
      ] }) })
    ] });
  }
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { size: 24, className: "animate-spin" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 w-full max-w-3xl mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: isResetPasswordDialogOpen, onOpenChange: setIsResetPasswordDialogOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-[425px]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Endre passord" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogDescription, { children: [
          "Endre passord for ",
          resetUsername,
          "@snakkaz.com"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmitPasswordReset, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "reset-password", className: "text-right", children: "Nytt passord" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "reset-password",
                  type: resetPasswordVisible ? "text" : "password",
                  value: resetPassword,
                  onChange: (e) => setResetPassword(e.target.value),
                  placeholder: "********",
                  required: true,
                  minLength: 8
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  className: "absolute inset-y-0 right-0 pr-3 flex items-center",
                  onClick: () => setResetPasswordVisible(!resetPasswordVisible),
                  children: resetPasswordVisible ? "Skjul" : "Vis"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 flex gap-1", children: [0, 1, 2, 3].map((level) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: `h-1 flex-1 rounded ${level <= resetPasswordStrength ? strengthColors[resetPasswordStrength] : "bg-gray-200"}`
              },
              level
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-right mt-1", children: resetPassword ? strengthLabels[resetPasswordStrength] : "" })
          ] })
        ] }) }),
        resetPasswordError && /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", className: "mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { children: "Feil" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: resetPasswordError })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            type: "submit",
            disabled: isChangingPassword || !resetPassword,
            children: isChangingPassword ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "mr-2 h-4 w-4 animate-spin" }),
              "Endrer passord..."
            ] }) : "Endre passord"
          }
        ) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "flex flex-row items-start justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { children: "Fellesskap E-postadresser" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Administrer dine @snakkaz.com e-postadresser" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open: isCreateDialogOpen, onOpenChange: setIsCreateDialogOpen, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "mr-2 h-4 w-4" }),
            "Ny e-postadresse"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-[425px]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Opprett ny e-postadresse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Lag en ny @snakkaz.com e-postadresse som støtter vårt fellesskap" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateEmail, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 py-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 items-center gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "username", className: "text-right", children: "Brukernavn" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3 flex items-center", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Input,
                      {
                        id: "username",
                        value: newEmailUsername,
                        onChange: (e) => setNewEmailUsername(e.target.value.toLowerCase()),
                        placeholder: "brukernavn",
                        required: true,
                        autoComplete: "off",
                        pattern: "[a-zA-Z0-9._-]+",
                        title: "Kun bokstaver, tall, punktum, bindestrek og understrek er tillatt"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 text-muted-foreground", children: "@snakkaz.com" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 items-center gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "password", className: "text-right", children: "Passord" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Input,
                        {
                          id: "password",
                          type: newPasswordVisible ? "text" : "password",
                          value: newEmailPassword,
                          onChange: (e) => setNewEmailPassword(e.target.value),
                          placeholder: "********",
                          required: true,
                          minLength: 8
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          className: "absolute inset-y-0 right-0 pr-3 flex items-center",
                          onClick: () => setNewPasswordVisible(!newPasswordVisible),
                          children: newPasswordVisible ? "Skjul" : "Vis"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 flex gap-1", children: [0, 1, 2, 3].map((level) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        className: `h-1 flex-1 rounded ${level <= passwordStrengthLevel ? strengthColors[passwordStrengthLevel] : "bg-gray-200"}`
                      },
                      level
                    )) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-right mt-1", children: newEmailPassword ? strengthLabels[passwordStrengthLevel] : "" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 items-center gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "quota", className: "text-right", children: "Kvote" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Input,
                      {
                        id: "quota",
                        type: "number",
                        value: newEmailQuota,
                        onChange: (e) => setNewEmailQuota(parseInt(e.target.value) || 250),
                        min: 100,
                        max: 2e3
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "MB" })
                  ] })
                ] })
              ] }),
              error && /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", className: "mb-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { children: "Feil" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: error })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  type: "submit",
                  disabled: isCreatingEmail || !newEmailUsername || !newEmailPassword,
                  children: isCreatingEmail ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "mr-2 h-4 w-4 animate-spin" }),
                    "Oppretter..."
                  ] }) : "Opprett e-postadresse"
                }
              ) })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: isLoadingEmails ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { size: 24, className: "animate-spin" }) }) : error ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { variant: "destructive", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { children: "Feil" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { children: error })
      ] }) : emails.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$1, { className: "mx-auto h-12 w-12 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-2 text-lg font-semibold", children: "Ingen e-postadresser" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Du har ikke opprettet noen @snakkaz.com e-postadresser ennå." })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: emails.map((email) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg border p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-medium", children: email.email_address }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => copyToClipboard(email.email_address),
                className: "text-muted-foreground hover:text-foreground",
                title: "Kopier e-postadresse",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { size: 14 })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
            new Date(email.created_at).toLocaleDateString("nb-NO"),
            " • ",
            email.quota_mb,
            " MB kvote"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "outline",
              size: "sm",
              onClick: () => handleResetPassword(email.email_username),
              children: "Nytt passord"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "outline",
              size: "sm",
              asChild: true,
              children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "a",
                {
                  href: "https://webmail.snakkaz.com",
                  target: "_blank",
                  rel: "noopener noreferrer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$1, { className: "mr-1 h-4 w-4" }),
                    " Webmail",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "ml-1 h-3 w-3" })
                  ]
                }
              )
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "destructive",
              size: "sm",
              disabled: isDeleting === email.email_username,
              onClick: () => handleDeleteEmail(email.email_username),
              children: isDeleting === email.email_username ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" })
            }
          )
        ] })
      ] }) }, email.id)) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { children: "E-postinnstillinger" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Bruk disse innstillingene for å konfigurere din e-postklient" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium mb-2", children: "Innkommende e-post (IMAP)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Server:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono", children: "mail.snakkaz.com" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Port:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono", children: "993" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Sikkerhet:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono", children: "SSL/TLS" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium mb-2", children: "Utgående e-post (SMTP)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Server:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono", children: "mail.snakkaz.com" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Port:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono", children: "465" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Sikkerhet:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono", children: "SSL/TLS" })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium mb-2", children: "Webmail" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mb-3", children: "Du kan også få tilgang til din e-post gjennom webmail:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: "https://webmail.snakkaz.com",
              target: "_blank",
              rel: "noopener noreferrer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Mail$1, { className: "mr-2 h-4 w-4" }),
                "Åpne Webmail",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "ml-2 h-4 w-4" })
              ]
            }
          ) })
        ] })
      ] }) })
    ] })
  ] });
}
const SecurityBadge = ({
  securityLevel,
  connectionState,
  dataChannelState,
  usingServerFallback,
  size = "md",
  isPremium = false
  // Standard verdi
}) => {
  const isConnected = connectionState === "connected" && dataChannelState === "open";
  const fallback = usingServerFallback === true;
  const sizeClasses = {
    sm: "w-5 h-5",
    md: "w-6 h-6",
    lg: "w-7 h-7"
  };
  const iconSizes = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5"
  };
  let Icon = Shield;
  const colors = securityColors[securityLevel];
  let title = "";
  switch (securityLevel) {
    case "p2p_e2ee":
      if (fallback) {
        Icon = ShieldAlert;
        title = isPremium ? "Premium P2P Kryptering (Fallback)" : "P2P Kryptering (Fallback)";
      } else if (!isConnected && (connectionState || dataChannelState)) {
        Icon = ShieldAlert;
        title = isPremium ? "Premium P2P Kryptering (Kobler til...)" : "P2P Kryptering (Kobler til...)";
      } else {
        Icon = ShieldCheck;
        title = isPremium ? "256-bit Peer-to-Peer Kryptering" : "Peer-to-Peer End-to-End Kryptering";
      }
      break;
    case "server_e2ee":
      Icon = ShieldCheck;
      title = isPremium ? "256-bit Server Kryptering" : "Server End-to-End Kryptering";
      break;
    case "standard":
      Icon = Shield;
      title = isPremium ? "Forbedret Standard Kryptering" : "Standard Kryptering";
      break;
  }
  const premiumGlowClass = isPremium ? "shadow-lg shadow-cybergold-500/20" : "";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: cn(
        "flex items-center justify-center rounded-full transition-all duration-300",
        colors.bg,
        colors.glow,
        sizeClasses[size],
        isPremium && "border border-cybergold-500/40",
        premiumGlowClass
      ),
      title,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: cn(
        iconSizes[size],
        isPremium ? "text-cybergold-300" : colors.primary
      ) })
    }
  );
};
export {
  AppHeader as A,
  CommunityEmailManager as C,
  DeveloperTools as D,
  EnhancedFriendsList as E,
  FreeUserNavigation as F,
  MathCaptcha as M,
  PreviewBanner as P,
  SubscriptionPage as S,
  UnifiedNavigation as U,
  __vitePreload as _,
  MobileLayout as a,
  FriendsSearchSection as b,
  EnhancedFriendRequestHandler as c,
  UserAvatar as d,
  SecurityBadge as e,
  DynamicProfile$1 as f,
  DynamicSettings$1 as g,
  DynamicMail$1 as h,
  DynamicMemoryDashboard$1 as i
};
//# sourceMappingURL=components-ui-BmnsZTWe.js.map
