// SnakkaZ Debug Console Tools
window.SnakkazDebug = {
    // Check React context availability
    checkReact: function() {
        console.log('React availability check:');
        console.log('window.React:', typeof window.React);
        console.log('window.SafeReact:', typeof window.SafeReact);
        console.log('React.createContext:', typeof (window.React && window.React.createContext));
        
        if (window.SafeReact) {
            console.log('✅ SafeReact mock system loaded');
        } else {
            console.log('❌ SafeReact mock system not found');
        }
    },
    
    // Test vendor bundles
    testVendorBundles: function() {
        const vendorBundles = [
            'vendor-router-DRYHFKTT',
            'vendor-animation-BRHAymv3',
            'vendor-react-core-Cd05VJ5Y'
        ];
        
        vendorBundles.forEach(bundle => {
            const script = document.querySelector(`script[src*="${bundle}"]`);
            console.log(`${bundle}:`, script ? '✅ Loaded' : '❌ Not found');
        });
    },
    
    // Performance monitoring
    checkPerformance: function() {
        if (window.performance && window.performance.getEntriesByType) {
            const resources = window.performance.getEntriesByType('resource');
            const jsResources = resources.filter(r => r.name.endsWith('.js'));
            
            console.log('JavaScript Resource Loading Times:');
            jsResources.forEach(resource => {
                console.log(`${resource.name.split('/').pop()}: ${Math.round(resource.duration)}ms`);
            });
        }
    },
    
    // Check for errors
    errorCount: 0,
    logError: function(error) {
        this.errorCount++;
        console.error(`SnakkaZ Error #${this.errorCount}:`, error);
    },
    
    // Context debugging
    debugContext: function(contextName) {
        console.log(`Debugging context: ${contextName}`);
        // Add context-specific debugging logic
    }
};

// Auto-run basic checks
if (document.readyState === 'complete') {
    setTimeout(() => {
        console.log('🚀 SnakkaZ Debug Tools Loaded');
        window.SnakkazDebug.checkReact();
        window.SnakkazDebug.testVendorBundles();
    }, 1000);
} else {
    window.addEventListener('load', () => {
        setTimeout(() => {
            console.log('🚀 SnakkaZ Debug Tools Loaded');
            window.SnakkazDebug.checkReact();
            window.SnakkazDebug.testVendorBundles();
        }, 1000);
    });
}

// Error tracking
window.addEventListener('error', (event) => {
    window.SnakkazDebug.logError(event.error);
});

window.addEventListener('unhandledrejection', (event) => {
    window.SnakkazDebug.logError(event.reason);
});
