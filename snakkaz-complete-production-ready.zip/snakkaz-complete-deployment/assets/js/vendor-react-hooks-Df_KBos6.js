// Comprehensive React Mock System for Vendor Bundles
(function() {
    'use strict';
    
    // Safe React implementation
    const SafeReact = {
        Component: class Component {
            constructor(props) {
                this.props = props || {};
                this.state = {};
            }
            setState(updates) {
                if (typeof updates === 'function') {
                    updates = updates(this.state);
                }
                this.state = { ...this.state, ...updates };
            }
            render() {
                return null;
            }
        },
        
        createElement: function(type, props, ...children) {
            if (typeof type === 'string') {
                return {
                    type: type,
                    props: { ...props, children: children.length === 1 ? children[0] : children },
                    $$typeof: Symbol.for('react.element')
                };
            }
            if (typeof type === 'function') {
                try {
                    return type(props);
                } catch (e) {
                    console.warn('SafeReact: Component error caught', e);
                    return { type: 'div', props: { children: 'Component Error' } };
                }
            }
            return { type: 'div', props: { children: children } };
        },
        
        createContext: function(defaultValue) {
            const context = {
                Provider: function({ children, value }) {
                    return children;
                },
                Consumer: function({ children }) {
                    return typeof children === 'function' ? children(defaultValue) : children;
                },
                _currentValue: defaultValue,
                _context: true,
                displayName: 'Context'
            };
            return context;
        },
        
        forwardRef: function(render) {
            return function(props) {
                return render(props, { current: null });
            };
        },
        
        Fragment: function({ children }) {
            return children;
        },
        
        memo: function(component) {
            return component;
        },
        
        useCallback: function(callback, deps) {
            return callback;
        },
        
        useContext: function(context) {
            return context._currentValue || {};
        },
        
        useEffect: function(effect, deps) {
            try {
                if (typeof effect === 'function') {
                    const cleanup = effect();
                    if (typeof cleanup === 'function') {
                        // Store cleanup for potential later use
                        return cleanup;
                    }
                }
            } catch (e) {
                console.warn('SafeReact: useEffect error caught', e);
            }
        },
        
        useLayoutEffect: function(effect, deps) {
            return this.useEffect(effect, deps);
        },
        
        useMemo: function(factory, deps) {
            try {
                return typeof factory === 'function' ? factory() : factory;
            } catch (e) {
                console.warn('SafeReact: useMemo error caught', e);
                return null;
            }
        },
        
        useRef: function(initialValue) {
            return { current: initialValue };
        },
        
        useState: function(initialState) {
            const state = typeof initialState === 'function' ? initialState() : initialState;
            const setState = function(newState) {
                // In a real app, this would trigger re-render
                console.log('SafeReact: setState called with', newState);
            };
            return [state, setState];
        },
        
        useReducer: function(reducer, initialState) {
            const dispatch = function(action) {
                console.log('SafeReact: dispatch called with', action);
            };
            return [initialState, dispatch];
        },
        
        isValidElement: function(element) {
            return element && typeof element === 'object' && element.$$typeof === Symbol.for('react.element');
        },
        
        Children: {
            forEach: function(children, fn) {
                if (Array.isArray(children)) {
                    children.forEach(fn);
                } else if (children) {
                    fn(children, 0);
                }
            },
            map: function(children, fn) {
                if (Array.isArray(children)) {
                    return children.map(fn);
                } else if (children) {
                    return [fn(children, 0)];
                }
                return [];
            },
            count: function(children) {
                return Array.isArray(children) ? children.length : children ? 1 : 0;
            },
            only: function(children) {
                if (Array.isArray(children) && children.length === 1) {
                    return children[0];
                }
                return children;
            }
        }
    };
    
    // Ensure global React availability
    if (typeof window !== 'undefined') {
        window.React = window.React || SafeReact;
        window.SafeReact = SafeReact;
    }
    
    // For module systems
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = SafeReact;
    }
    
    // For AMD
    if (typeof define === 'function' && define.amd) {
        define(function() { return SafeReact; });
    }
})();

import { r as reactExports } from "./vendor-react-core-Cd05VJ5Y.js";
var scheduler = { exports: {} };
var scheduler_production_min = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(exports) {
  function f(a, b) {
    var c = a.length;
    a.push(b);
    a: for (; 0 < c; ) {
      var d = c - 1 >>> 1, e = a[d];
      if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
      else break a;
    }
  }
  function h(a) {
    return 0 === a.length ? null : a[0];
  }
  function k(a) {
    if (0 === a.length) return null;
    var b = a[0], c = a.pop();
    if (c !== b) {
      a[0] = c;
      a: for (var d = 0, e = a.length, w = e >>> 1; d < w; ) {
        var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
        if (0 > g(C, c)) n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
        else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
        else break a;
      }
    }
    return b;
  }
  function g(a, b) {
    var c = a.sortIndex - b.sortIndex;
    return 0 !== c ? c : a.id - b.id;
  }
  if ("object" === typeof performance && "function" === typeof performance.now) {
    var l = performance;
    exports.unstable_now = function() {
      return l.now();
    };
  } else {
    var p = Date, q = p.now();
    exports.unstable_now = function() {
      return p.now() - q;
    };
  }
  var r = [], t = [], u = 1, v = null, y = 3, z = false, A = false, B = false, D = "function" === typeof setTimeout ? setTimeout : null, E = "function" === typeof clearTimeout ? clearTimeout : null, F = "undefined" !== typeof setImmediate ? setImmediate : null;
  "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function G(a) {
    for (var b = h(t); null !== b; ) {
      if (null === b.callback) k(t);
      else if (b.startTime <= a) k(t), b.sortIndex = b.expirationTime, f(r, b);
      else break;
      b = h(t);
    }
  }
  function H(a) {
    B = false;
    G(a);
    if (!A) if (null !== h(r)) A = true, I(J);
    else {
      var b = h(t);
      null !== b && K(H, b.startTime - a);
    }
  }
  function J(a, b) {
    A = false;
    B && (B = false, E(L), L = -1);
    z = true;
    var c = y;
    try {
      G(b);
      for (v = h(r); null !== v && (!(v.expirationTime > b) || a && !M()); ) {
        var d = v.callback;
        if ("function" === typeof d) {
          v.callback = null;
          y = v.priorityLevel;
          var e = d(v.expirationTime <= b);
          b = exports.unstable_now();
          "function" === typeof e ? v.callback = e : v === h(r) && k(r);
          G(b);
        } else k(r);
        v = h(r);
      }
      if (null !== v) var w = true;
      else {
        var m = h(t);
        null !== m && K(H, m.startTime - b);
        w = false;
      }
      return w;
    } finally {
      v = null, y = c, z = false;
    }
  }
  var N = false, O = null, L = -1, P = 5, Q = -1;
  function M() {
    return exports.unstable_now() - Q < P ? false : true;
  }
  function R() {
    if (null !== O) {
      var a = exports.unstable_now();
      Q = a;
      var b = true;
      try {
        b = O(true, a);
      } finally {
        b ? S() : (N = false, O = null);
      }
    } else N = false;
  }
  var S;
  if ("function" === typeof F) S = function() {
    F(R);
  };
  else if ("undefined" !== typeof MessageChannel) {
    var T = new MessageChannel(), U = T.port2;
    T.port1.onmessage = R;
    S = function() {
      U.postMessage(null);
    };
  } else S = function() {
    D(R, 0);
  };
  function I(a) {
    O = a;
    N || (N = true, S());
  }
  function K(a, b) {
    L = D(function() {
      a(exports.unstable_now());
    }, b);
  }
  exports.unstable_IdlePriority = 5;
  exports.unstable_ImmediatePriority = 1;
  exports.unstable_LowPriority = 4;
  exports.unstable_NormalPriority = 3;
  exports.unstable_Profiling = null;
  exports.unstable_UserBlockingPriority = 2;
  exports.unstable_cancelCallback = function(a) {
    a.callback = null;
  };
  exports.unstable_continueExecution = function() {
    A || z || (A = true, I(J));
  };
  exports.unstable_forceFrameRate = function(a) {
    0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
  };
  exports.unstable_getCurrentPriorityLevel = function() {
    return y;
  };
  exports.unstable_getFirstCallbackNode = function() {
    return h(r);
  };
  exports.unstable_next = function(a) {
    switch (y) {
      case 1:
      case 2:
      case 3:
        var b = 3;
        break;
      default:
        b = y;
    }
    var c = y;
    y = b;
    try {
      return a();
    } finally {
      y = c;
    }
  };
  exports.unstable_pauseExecution = function() {
  };
  exports.unstable_requestPaint = function() {
  };
  exports.unstable_runWithPriority = function(a, b) {
    switch (a) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        a = 3;
    }
    var c = y;
    y = a;
    try {
      return b();
    } finally {
      y = c;
    }
  };
  exports.unstable_scheduleCallback = function(a, b, c) {
    var d = exports.unstable_now();
    "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
    switch (a) {
      case 1:
        var e = -1;
        break;
      case 2:
        e = 250;
        break;
      case 5:
        e = 1073741823;
        break;
      case 4:
        e = 1e4;
        break;
      default:
        e = 5e3;
    }
    e = c + e;
    a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
    c > d ? (a.sortIndex = c, f(t, a), null === h(r) && a === h(t) && (B ? (E(L), L = -1) : B = true, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = true, I(J)));
    return a;
  };
  exports.unstable_shouldYield = M;
  exports.unstable_wrapCallback = function(a) {
    var b = y;
    return function() {
      var c = y;
      y = b;
      try {
        return a.apply(this, arguments);
      } finally {
        y = c;
      }
    };
  };
})(scheduler_production_min);
{
  scheduler.exports = scheduler_production_min;
}
var schedulerExports = scheduler.exports;
var shim$1 = { exports: {} };
var useSyncExternalStoreShim_production = {};
/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var React = reactExports;
function is(x, y) {
  return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
}
var objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue;
function useSyncExternalStore$2(subscribe, getSnapshot) {
  var value = getSnapshot(), _useState = useState({ inst: { value, getSnapshot } }), inst = _useState[0].inst, forceUpdate = _useState[1];
  useLayoutEffect(
    function() {
      inst.value = value;
      inst.getSnapshot = getSnapshot;
      checkIfSnapshotChanged(inst) && forceUpdate({ inst });
    },
    [subscribe, value, getSnapshot]
  );
  useEffect(
    function() {
      checkIfSnapshotChanged(inst) && forceUpdate({ inst });
      return subscribe(function() {
        checkIfSnapshotChanged(inst) && forceUpdate({ inst });
      });
    },
    [subscribe]
  );
  useDebugValue(value);
  return value;
}
function checkIfSnapshotChanged(inst) {
  var latestGetSnapshot = inst.getSnapshot;
  inst = inst.value;
  try {
    var nextValue = latestGetSnapshot();
    return !objectIs(inst, nextValue);
  } catch (error) {
    return true;
  }
}
function useSyncExternalStore$1(subscribe, getSnapshot) {
  return getSnapshot();
}
var shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
useSyncExternalStoreShim_production.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
{
  shim$1.exports = useSyncExternalStoreShim_production;
}
var shimExports = shim$1.exports;
export {
  schedulerExports as a,
  shimExports as s
};
//# sourceMappingURL=vendor-react-hooks-Df_KBos6.js.map
