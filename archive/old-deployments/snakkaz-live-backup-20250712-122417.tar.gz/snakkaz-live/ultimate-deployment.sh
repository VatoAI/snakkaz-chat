#!/bin/bash

# SNAKKAZ ULTIMATE DEPLOYMENT SCRIPT
# Automatisk deployment og validering av emergency fixes

echo "🚀 SNAKKAZ ULTIMATE DEPLOYMENT"
echo "=============================="
echo "📅 $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to print status
print_status() {
    local status=$1
    local message=$2
    case $status in
        "success") echo "✅ $message" ;;
        "error") echo "❌ $message" ;;
        "info") echo "📋 $message" ;;
        "warning") echo "⚠️ $message" ;;
    esac
}

# Check prerequisites
print_status "info" "Checking prerequisites..."

if ! command_exists curl; then
    print_status "error" "curl is required but not installed"
    exit 1
fi

# Validate emergency fix files exist
required_files=(
    "ultimate-vendor-fix.js"
    "comprehensive-react-fix.js"
    "error-boundary-system.js"
    "recovery-validation.js"
    "index-production-ultimate.html"
    "production-validation-test.js"
)

for file in "${required_files[@]}"; do
    if [[ -f "$file" ]]; then
        print_status "success" "$file exists"
    else
        print_status "error" "$file is missing!"
        exit 1
    fi
done

# Backup current index.html
if [[ -f "index.html" ]]; then
    cp index.html "index.html.backup.$(date +%Y%m%d-%H%M%S)"
    print_status "info" "Backed up current index.html"
fi

# Deploy emergency fixes locally
print_status "info" "Deploying emergency fixes locally..."
cp index-production-ultimate.html index.html
print_status "success" "Emergency fixes deployed locally"

# Test local deployment
print_status "info" "Testing local deployment..."

# Check if local server is running
if curl -s -f http://localhost:8080/ >/dev/null; then
    print_status "success" "Local server is running on port 8080"
    
    # Test all fix files are accessible
    for file in "ultimate-vendor-fix.js" "comprehensive-react-fix.js" "error-boundary-system.js" "recovery-validation.js"; do
        if curl -s -f "http://localhost:8080/$file" >/dev/null; then
            print_status "success" "$file is accessible"
        else
            print_status "error" "$file is not accessible!"
        fi
    done
    
else
    print_status "warning" "Local server not running, starting..."
    # Start local server in background
    python3 -m http.server 8080 >/dev/null 2>&1 &
    SERVER_PID=$!
    sleep 3
    
    if curl -s -f http://localhost:8080/ >/dev/null; then
        print_status "success" "Local server started successfully"
    else
        print_status "error" "Failed to start local server"
        exit 1
    fi
fi

# Generate production deployment package
print_status "info" "Generating production deployment package..."

DEPLOY_DIR="snakkaz-production-deploy-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEPLOY_DIR"

# Copy all necessary files
cp ultimate-vendor-fix.js "$DEPLOY_DIR/"
cp comprehensive-react-fix.js "$DEPLOY_DIR/"
cp error-boundary-system.js "$DEPLOY_DIR/"
cp recovery-validation.js "$DEPLOY_DIR/"
cp index-production-ultimate.html "$DEPLOY_DIR/index.html"
cp production-validation-test.js "$DEPLOY_DIR/"

# Create FTP deployment script
cat > "$DEPLOY_DIR/deploy-to-production.lftp" << 'EOF'
set ftp:ssl-allow no
set ssl:verify-certificate no
open -u $USER,$PASS ftp.snakkaz.com
mirror --reverse --delete --verbose ./ /public_html/
bye
EOF

# Create deployment instructions
cat > "$DEPLOY_DIR/README-DEPLOYMENT.md" << 'EOF'
# SNAKKAZ Emergency Fixes - Production Deployment

## Files in this package:
- `ultimate-vendor-fix.js` - Critical vendor bundle fix
- `comprehensive-react-fix.js` - React hooks emergency implementation  
- `error-boundary-system.js` - Global error handling
- `recovery-validation.js` - System health monitoring
- `index.html` - Updated HTML with proper script loading order
- `production-validation-test.js` - Automated testing script

## Deployment Steps:

### Option 1: FTP Deployment (Recommended)
```bash
# Set your FTP credentials
export USER='your_ftp_username'
export PASS='your_ftp_password'

# Deploy using lftp
lftp -f deploy-to-production.lftp
```

### Option 2: Manual Upload
Upload all `.js` files and `index.html` to your web server root directory.

## Post-Deployment Validation:

1. Visit: https://www.snakkaz.com
2. Open browser developer console (F12)
3. Look for these success messages:
   - 🚀 ULTIMATE Vendor Bundle Fix initializing...
   - ✅ Pre-emptive React namespace created
   - ✅ Pre-created LayoutGroupContext globally available
   - ✅ ULTIMATE Vendor Bundle Fix: ALL SYSTEMS GO!

4. Verify NO errors containing:
   - "undefined has no properties"
   - "LayoutGroupContext"

## Emergency Rollback:
If issues occur, simply restore the previous `index.html` from backup.

Generated: $(date)
EOF

print_status "success" "Production deployment package created: $DEPLOY_DIR"

# Test production site (if accessible)
print_status "info" "Testing production site accessibility..."
if curl -s -f https://www.snakkaz.com/ >/dev/null; then
    print_status "success" "Production site is accessible"
    
    # Check if emergency fixes are already deployed
    if curl -s https://www.snakkaz.com/ultimate-vendor-fix.js | grep -q "ULTIMATE Vendor Bundle Fix"; then
        print_status "success" "Emergency fixes are already deployed to production!"
    else
        print_status "warning" "Emergency fixes are NOT yet deployed to production"
    fi
else
    print_status "warning" "Production site not accessible for testing"
fi

# Summary
echo ""
echo "📊 DEPLOYMENT SUMMARY"
echo "===================="
print_status "success" "Local deployment: COMPLETE"
print_status "success" "Local server: Running on http://localhost:8080"
print_status "success" "Production package: $DEPLOY_DIR"
print_status "info" "Next step: Deploy $DEPLOY_DIR to production server"

echo ""
echo "🎯 QUICK DEPLOY COMMANDS:"
echo "cd $DEPLOY_DIR"
echo "export USER='your_ftp_username'"
echo "export PASS='your_ftp_password'"
echo "lftp -f deploy-to-production.lftp"

echo ""
echo "🎉 Ready for BETA LAUNCH after production deployment!"
