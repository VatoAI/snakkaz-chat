#!/bin/bash
echo "🔍 Verifying deployment..."
echo ""

echo "Testing fix files availability:"
curl -s -o /dev/null -w "%{http_code} - ultimate-vendor-fix.js\n" https://www.snakkaz.com/ultimate-vendor-fix.js
curl -s -o /dev/null -w "%{http_code} - comprehensive-react-fix.js\n" https://www.snakkaz.com/comprehensive-react-fix.js
curl -s -o /dev/null -w "%{http_code} - error-boundary-system.js\n" https://www.snakkaz.com/error-boundary-system.js
curl -s -o /dev/null -w "%{http_code} - recovery-validation.js\n" https://www.snakkaz.com/recovery-validation.js

echo ""
echo "Testing main page:"
curl -s -o /dev/null -w "%{http_code} - Main Page\n" https://www.snakkaz.com/

echo ""
echo "✅ Verification complete"
echo "💡 Open browser console at https://www.snakkaz.com to check for fix messages"
