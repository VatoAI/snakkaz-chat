#!/bin/bash

# SNAKKAZ EMERGENCY DEPLOYMENT SCRIPT
# Deploys critical React fixes to production
# Usage: ./emergency-react-fix-deploy.sh

echo "🚀 SNAKKAZ Emergency React Fix Deployment"
echo "=========================================="

# Check if files exist
REQUIRED_FILES=(
    "ultimate-vendor-fix.js"
    "comprehensive-react-fix.js" 
    "error-boundary-system.js"
    "recovery-validation.js"
    "index-production-ultimate.html"
)

echo "📋 Checking required files..."
for file in "${REQUIRED_FILES[@]}"; do
    if [[ -f "$file" ]]; then
        echo "✅ $file - Found"
    else
        echo "❌ $file - Missing"
        exit 1
    fi
done

echo ""
echo "📦 Preparing deployment package..."

# Create temp deployment directory
DEPLOY_DIR="snakkaz-emergency-fix-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEPLOY_DIR"

# Copy files
cp ultimate-vendor-fix.js "$DEPLOY_DIR/"
cp comprehensive-react-fix.js "$DEPLOY_DIR/"
cp error-boundary-system.js "$DEPLOY_DIR/"
cp recovery-validation.js "$DEPLOY_DIR/"
cp index-production-ultimate.html "$DEPLOY_DIR/index.html"

echo "✅ Files prepared in $DEPLOY_DIR"

# Create FTP deployment script
cat > "$DEPLOY_DIR/deploy.lftp" << 'EOF'
set ssl:verify-certificate false
set ftp:ssl-force true
set ftp:ssl-protect-data true
set ftp:ssl-protect-list true

# Connect to server
open -u $USER,$PASS ftp.snakkaz.com

# Upload critical fix files
lcd .
cd public_html

# Upload JS fixes
put ultimate-vendor-fix.js
put comprehensive-react-fix.js
put error-boundary-system.js
put recovery-validation.js

# Backup current index.html
get index.html index-backup-$(date +%Y%m%d-%H%M%S).html

# Upload new index.html
put index.html

echo "🚀 Emergency fixes deployed successfully!"
quit
EOF

echo "📡 FTP script created"
echo ""
echo "🚨 MANUAL DEPLOYMENT REQUIRED:"
echo "1. Set your FTP credentials:"
echo "   export USER='your_ftp_username'"
echo "   export PASS='your_ftp_password'"
echo ""
echo "2. Run deployment:"
echo "   cd $DEPLOY_DIR"
echo "   lftp -f deploy.lftp"
echo ""
echo "3. Test the deployment:"
echo "   Visit: https://www.snakkaz.com"
echo "   Check browser console for fix messages"
echo ""

# Create verification script
cat > "$DEPLOY_DIR/verify.sh" << 'EOF'
#!/bin/bash
echo "🔍 Verifying deployment..."
echo ""

echo "Testing fix files availability:"
curl -s -o /dev/null -w "%{http_code} - ultimate-vendor-fix.js\n" https://www.snakkaz.com/ultimate-vendor-fix.js
curl -s -o /dev/null -w "%{http_code} - comprehensive-react-fix.js\n" https://www.snakkaz.com/comprehensive-react-fix.js
curl -s -o /dev/null -w "%{http_code} - error-boundary-system.js\n" https://www.snakkaz.com/error-boundary-system.js
curl -s -o /dev/null -w "%{http_code} - recovery-validation.js\n" https://www.snakkaz.com/recovery-validation.js

echo ""
echo "Testing main page:"
curl -s -o /dev/null -w "%{http_code} - Main Page\n" https://www.snakkaz.com/

echo ""
echo "✅ Verification complete"
echo "💡 Open browser console at https://www.snakkaz.com to check for fix messages"
EOF

chmod +x "$DEPLOY_DIR/verify.sh"

echo "📋 Emergency fix deployment package ready!"
echo "📁 Location: $DEPLOY_DIR"
echo ""
echo "🎯 Expected console messages after deployment:"
echo "   🚀 ULTIMATE Vendor Bundle Fix initializing..."
echo "   ✅ Pre-emptive React namespace created"
echo "   ✅ Pre-created LayoutGroupContext globally available"
echo "   ✅ ULTIMATE Vendor Bundle Fix: ALL SYSTEMS GO!"
echo ""
echo "🚨 This should eliminate the 'undefined has no properties' error!"
